/**********************************************
Shoes (underbars) support
***********************************************/

Shoes.prototype = new Component();
Shoes.prototype.constructor = Shoes;
//children components indexes 
Shoes.prototype.ARGUMENT = 0;

function Shoes(parentObject, scriptLevelModifier, Type){
 this.Locked = false;
 //when created, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject = parentObject;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.Type = Type;

 this.CreateTSpans('munder', 'munder');

 this.container = svgDocument.createElement('svg');

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 this.Shoe = new Shoe(this, 0, Type);
 this.container.appendChild(this.Shoe.GetContainer());

 //create children components 
 this.childrenObjects = new Array();
 this.appendChild(new Row(this), this.ARGUMENT, true);
 this.childrenObjects[this.ARGUMENT].appendChild(new EditableLabel(null), 0, true);

 this.MMLP_Content.appendChild(this.childrenObjects[this.ARGUMENT].MMLP_Preview);
 this.MMLP_Content.appendChild(this.Shoe.MMLP_Preview);
 this.TeX_Content.appendChild(this.Shoe.TeX_Preview);
 this.TeX_Content.appendChild(this.childrenObjects[this.ARGUMENT].TeX_Preview);
 this.TeX_Preview.appendChild(this.TeX_Content);

 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
 this.childrenObjects[this.ARGUMENT].container.setAttribute('y', 0);
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Shoes.prototype.UpdatePositions = function(){
 if(this.childrenObjects.length < 1) return;
 var argument_size = this.childrenObjects[this.ARGUMENT].GetSize();
 var argumentMidline = this.childrenObjects[this.ARGUMENT].GetMidlineY();

 var Width = Maximum(argument_size.x, MIN_DECO_WIDTH);
 this.Shoe.Width = Width;
 this.Shoe.UpdateComponent();
 var shoe_size = this.Shoe.GetSize();
 var Height = argument_size.y + shoe_size.y;

 this.Midline = argumentMidline;

 this.childrenObjects[this.ARGUMENT].container.setAttribute('y', 0);
 this.container.setAttribute ('width', this.Scale(Width));
 this.container.setAttribute ('height', this.Scale(Height));
 this.container.setAttribute('viewBox', '0 0 ' + Width + ' ' + Height);

 this.Shoe.container.setAttribute('y', argument_size.y);
 this.childrenObjects[this.ARGUMENT].container.setAttribute('x', (Width - argument_size.x)/2);
 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the Shoes as Presentational MathML ( <munder> )
//----------------------------------------------------
Shoes.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent + '<munder>\n';
  Result += this.childrenObjects[this.ARGUMENT].ExportPresentationalMathML(indent + '  ');
  Result += this.Shoe.ExportPresentationalMathML(indent + '  ');
  Result += indent + '</munder>\n';
  return Result;
}

//----------------------------------------------------
//    Export the Shoes as LaTeX
//----------------------------------------------------
Shoes.prototype.ExportLaTeX = function(){
  var Result = this.Shoe.ExportLaTeX() + ' ';
  Result += this.childrenObjects[this.ARGUMENT].ExportLaTeX();
  return Result;
}

//----------------------------------------------------
//    Export shoe component as SVG image
//----------------------------------------------------
Shoes.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += this.childrenObjects[0].ExportSVGNode(indent + '  ');
  Result += this.Shoe.ExportSVGNode(indent + '  ');
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Shoes.prototype.CreateInstance = function(){
  return new Shoes(null, this.ScriptLevelModifier, this.Type);
}