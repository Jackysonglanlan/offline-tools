/***********************************************
A Row is a grouping component that encloses one or more
components.
************************************************/

Row.prototype = new Component();
Row.prototype.constructor = Row;
Row.prototype.CURSOR_MARGIN_DIST = 1;

function Row(parentObject, scriptLevelModifier){
//Row
 this.CursorPosition = 0;
 this.Cursor = null;
 this.Focused = false;
 this.Midline = 0;
 this.Locked = false;
 this.childrenObjects = new Array();
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.Width = 0;
 this.Height = 0;
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);

 this.CreateTSpans('mrow', 'mrow');

 this.TeX_OpenBrace = MakeTSpan(true);
 this.TeX_OpenBrace.appendChild(document.createTextNode(' { '));
// this.TeX_OpenBrace.setAttribute('display', 'none');
 this.TeX_CloseBrace = MakeTSpan(true);
 this.TeX_CloseBrace.appendChild(document.createTextNode('} '));
// this.TeX_CloseBrace.setAttribute('display', 'none');
 this.TeX_Preview.appendChild(this.TeX_OpenBrace);
 this.TeX_Preview.appendChild(this.TeX_Content);
 this.TeX_Preview.appendChild(this.TeX_CloseBrace);

 //the object should remember its parent
 this.parentObject = parentObject;

 //the component is an intern svg
 this.container = svgDocument.createElement('svg');

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //set the mouse / key event handlers
 this.container.setAttribute('onkeypress', 'eq.eqKeyPress(evt)');
 this.container.setAttribute('onkeydown', 'eq.eqKeyDown(evt)');
 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Remove all children
//----------------------------------------------------
Row.prototype.Clear = function(){
  var child = this.childrenObjects.pop();
  while(child != null){
    eq.EqModified(this.hWnd, child, UndoStep.prototype.DELETECHILD, this.childrenObjects.length);
    this.container.removeChild(child.GetContainer());
    child = this.childrenObjects.pop();
  }
}

//----------------------------------------------------
//     Put all this row's children into an array and
//  destroy this row
//----------------------------------------------------
Row.prototype.Explode = function(){
  var Children = new Array();
  var child = this.childrenObjects.pop();
  while(child != null){
    eq.EqModified(this.hWnd, child, UndoStep.prototype.DELETECHILD, this.childrenObjects.length);
    this.container.removeChild(child.GetContainer());
    Children.unshift(child);
    child = this.childrenObjects.pop();
  }
  return Children;
}

//----------------------------------------------------
//     Insert all items in NewChildren into this row
//----------------------------------------------------
Row.prototype.InsertRange = function(NewChildren){
  for(var i = 0; i < NewChildren.length; i++){
    this.Insert(NewChildren[i]);
  }
}

//----------------------------------------------------
//     Insert a new component
//----------------------------------------------------
Row.prototype.Insert = function(NewComponent){
  if((this.CursorPosition < this.childrenObjects.length) && (this.childrenObjects[this.CursorPosition] instanceof EditableLabel)
      && (this.childrenObjects[this.CursorPosition].innerText.nodeValue.length == 0)){
    this.childrenObjects[this.CursorPosition].Insert(NewComponent, false);
    eq.Modified();
    return;
  }
  if((this.CursorPosition > 0) && (this.childrenObjects[this.CursorPosition-1] instanceof EditableLabel)
      && (this.childrenObjects[this.CursorPosition-1].innerText.nodeValue.length == 0)){
    this.childrenObjects[this.CursorPosition-1].Insert(NewComponent, false);
    eq.Modified();
    return;
  }
  if (this.IsLocked()) {
    this.parentObject.Insert(NewComponent, true);
    return false;
  }
  eq.EqModified(this.hWnd, NewComponent, UndoStep.prototype.INSERTCHILD, this.CursorPosition);
  this.childrenObjects.splice(this.CursorPosition, 0, NewComponent);

  this.container.appendChild(NewComponent.GetContainer());
  NewComponent.parentObject = this;
  this.CursorPosition++;
  this.UpdatePositions();
  if (NewComponent instanceof StaticLabel){
   eq.setFocusTo(this);
  }
  this.InsertTSpanFor(NewComponent);
  if(this.childrenObjects.length == 1 && ((this.childrenObjects[0] instanceof EditableLabel) || (this.childrenObjects[0] instanceof StaticLabel))){
    this.TeX_OpenBrace.setAttribute('display', 'none');
    this.TeX_CloseBrace.setAttribute('display', 'none');
  }
  else{
    this.TeX_OpenBrace.setAttribute('display', 'inline');
    this.TeX_CloseBrace.setAttribute('display', 'inline');
  }
  eq.Modified();
  this.UpdateCursor();
  return false;
}

//----------------------------------------------------
//     Key Pressed Event
//----------------------------------------------------
Row.prototype.KeyPress = function(evt){
  switch(evt.charCode){
    case 8: // BackSpace
      if(this.IsLocked()){
        return;
      }
      if(this.CursorPosition > 0){
        if ((this.childrenObjects[this.CursorPosition-1] instanceof EditableLabel) && 
        (this.childrenObjects[this.CursorPosition-1].innerText.length > 1)){
          this.childrenObjects[this.CursorPosition-1].EnterFromEnd();
          this.childrenObjects[this.CursorPosition-1].KeyPress(evt);
          return;
        }
        if(this.childrenObjects[this.CursorPosition-1] instanceof Prime){
          var Content = this.childrenObjects[this.CursorPosition-1].childrenObjects[0].Explode();
          var LastInsertedChild = Content[Content.length - 1];
          this.DeleteChild(this.childrenObjects[this.CursorPosition-1]);
          this.InsertRange(Content);
          this.SetCursorAfter(LastInsertedChild);
          this.UpdateCursor();
          return;
        }
        eq.EqModified(this.hWnd, this.childrenObjects[this.CursorPosition-1], UndoStep.prototype.DELETECHILD, this.CursorPosition-1);
        this.MMLP_Content.removeChild(this.childrenObjects[this.CursorPosition-1].MMLP_Preview);
        this.TeX_Content.removeChild(this.childrenObjects[this.CursorPosition-1].TeX_Preview);
        this.container.removeChild(this.childrenObjects[this.CursorPosition-1].GetContainer());
        this.childrenObjects.splice(this.CursorPosition-1, 1);
        this.CursorPosition--;
        this.UpdatePositions();
        this.UpdateCursor();
      }
      else {
        if (this.parentObject instanceof EqRoot){
          this.parentObject.MergeBack(this);
        }
        else{
          if(this.parentObject.IsLocked()){
            return;
          }
          if((this.parentObject instanceof Root) || (this.parentObject instanceof Sqrt) ||
              (this.parentObject instanceof Triplet) || (this.parentObject instanceof Fenced)){
            var FirstChild = this.childrenObjects[0];
            var NewParent = this.parentObject.parentObject;
            NewParent.InsertRange(this.Explode());
            NewParent.DeleteChild(this.parentObject);
            NewParent.SetCursorBefore(FirstChild);
            eq.Modified();
            return;
          }
          else{
            this.parentObject.SetCursorBefore(this);
            this.parentObject.KeyPress(evt);
            return;
          }
        }
      }
      if(this.childrenObjects.length == 0){
        if(this.parentObject instanceof EqRoot){
          this.parentObject.DeleteChild(this);
          eq.Modified();
          return;
        }
        var ReplacerText = new EditableLabel(null);
        eq.setFocusTo(ReplacerText);
        this.appendChild(ReplacerText);
        ReplacerText.UpdatePositions();
      }
      eq.Modified();
      break;
    case 13: // Enter
      if(this.parentObject instanceof EqRoot){
        var NewRowChildren = new Array();
        for (var i = this.childrenObjects.length - 1; i >= this.CursorPosition ; i--){
          NewRowChildren.unshift(this.childrenObjects[i]);
          this.container.removeChild(this.childrenObjects[i].GetContainer());
          eq.EqModified(this.hWnd, this.childrenObjects[i], UndoStep.prototype.DELETECHILD, i);
        }
        this.childrenObjects.splice(this.CursorPosition, this.childrenObjects.length - this.CursorPosition);
        if(this.childrenObjects.length == 0){
          var ReplacerText = new EditableLabel(null);
          this.appendChild(ReplacerText);
          ReplacerText.UpdatePositions();
        }
        this.UpdatePositions();
        this.parentObject.NewRowAfter(this, NewRowChildren);
      }
      break;
    default:
      if (IsAlNum(evt.charCode)){
        txt = new EditableLabel(null);
        this.Insert(txt);
        eq.setFocusTo(txt);
        txt.KeyPress(evt);
      }
      break; 
  }
}

//----------------------------------------------------
//     Key Down Event
//----------------------------------------------------
Row.prototype.KeyDown = function(evt){
  switch (evt.keyCode){
    case 127: // delete; replace the selected component with an empty EditableLabel
      if(this.IsLocked()){
        return;
      }
      if(this.CursorPosition < this.childrenObjects.length){
        if ((this.childrenObjects[this.CursorPosition] instanceof EditableLabel) && 
            (this.childrenObjects[this.CursorPosition].innerText.length > 1)){
          this.childrenObjects[this.CursorPosition].EnterFromBegin();
          //EnterFromBegin results in FocusGained, who sets cursor after!
          this.childrenObjects[this.CursorPosition-1].KeyDown(evt);
          return;
        }
        if (this.childrenObjects[this.CursorPosition] instanceof Prime){
          this.childrenObjects[this.CursorPosition].childrenObjects[0].EnterFromBegin();
          eq.getFocusedElement().KeyDown(evt);
          return;
        }
        eq.EqModified(this.hWnd, this.childrenObjects[this.CursorPosition], UndoStep.prototype.DELETECHILD, this.CursorPosition);
        this.MMLP_Content.removeChild(this.childrenObjects[this.CursorPosition].MMLP_Preview);
        this.TeX_Content.removeChild(this.childrenObjects[this.CursorPosition].TeX_Preview);
        this.container.removeChild(this.childrenObjects[this.CursorPosition].GetContainer());
        this.childrenObjects.splice(this.CursorPosition, 1);
        this.UpdatePositions();
        eq.Modified();
      }
      else{
        if (this.parentObject instanceof EqRoot){
          this.parentObject.MergeForward(this);
          eq.Modified();
        }
        else if (this.parentObject instanceof Prime){
              var LastChild = this.childrenObjects[this.childrenObjects.length - 1];
              var NewParent = this.parentObject.parentObject;
              NewParent.InsertRange(this.Explode());
              NewParent.DeleteChild(this.parentObject);
              NewParent.SetCursorAfter(LastChild);
              eq.Modified();
              return;
        }
        else{
          this.parentObject.SetCursorAfter(this);
          this.parentObject.KeyDown(evt);
          return;
        }
      }
      if(this.childrenObjects.length == 0){
        if(this.parentObject instanceof EqRoot){
          this.parentObject.DeleteChild(this);
          eq.Modified();
          return;
        }
        var ReplacerText = new EditableLabel(null);
        this.appendChild(ReplacerText);
        ReplacerText.UpdatePositions();
        eq.setFocusTo(ReplacerText);
        eq.Modified();
      }
      break;
    case 33:  // pageUp; select the previous sibling
      this.parentObject.focusPreviousSibling(this);
      break;
    case 34:  // pageDown; select the next sibling
      this.parentObject.focusNextSibling(this);
      break;
    case 35:  // end; select the first child
        if(this.childrenObjects[0] != null){
          eq.setFocusTo(this.childrenObjects[0]);
        }
      break;
    case 36:  // home; select the parent
        if(this.parentObject != null){
          eq.setFocusTo(this.parentObject);
        }
      break;
    case 37:  // <- (left arrow)
      if (this.CursorPosition > 0) {
        if(this.childrenObjects[this.CursorPosition-1].EnterFromEnd){
          this.childrenObjects[this.CursorPosition-1].EnterFromEnd();
        }
        else{
          this.CursorPosition--;
          this.UpdateCursor();
        }
      }
      else{
        this.parentObject.SetCursorBefore(this);
      }
      break;
    case 39:  // -> (right arrow)
      if (this.CursorPosition < this.childrenObjects.length){ 
        if(this.childrenObjects[this.CursorPosition].EnterFromBegin){
          this.childrenObjects[this.CursorPosition].EnterFromBegin();
        }
        else{
          this.CursorPosition++;
          this.UpdateCursor();
        }
       }
      else{
        this.parentObject.SetCursorAfter(this);
      }
      break;
    case 38:  // up; select the previous EditableLabel
        eq.StartLeafSearch(this);
        if(this.childrenObjects.length > 0){
  //        eq.EnterFromBegin(this.getRightmostLeaf(this.childrenObjects[0]));
          this.getRightmostLeaf(this.childrenObjects[0]).EnterFromBegin();
        }
        else{
  //        eq.EnterFromBegin(this.parentObject.getPreviousLeaf(this));
          this.parentObject.getPreviousLeaf(this).EnterFromBegin();
        }
      break;
    case 40:  // down; select the next EditableLabel
        eq.StartLeafSearch(this);
        if(this.childrenObjects.length > 0){
  //        eq.EnterFromBegin(this.getLeftmostLeaf(this.childrenObjects[0]));
          this.getLeftmostLeaf(this.childrenObjects[0]).EnterFromBegin();
        }
        else{
  //        eq.EnterFromBegin(this.parentObject.getFollowingLeaf(this));
          this.parentObject.getFollowingLeaf(this).EnterFromBegin();
        }
      break;
    default:
      if (this.parentObject != null){
        this.parentObject.KeyDown(evt);
      }
      break;
  }
}

//----------------------------------------------------
//     Set Focus
//----------------------------------------------------
Row.prototype.FocusGained = function() {
 this.Focused = true;
// if(this.childrenObjects.length == 1){
   this.frame.setAttribute('class', 'idle');
// }
// else{
//   this.frame.setAttribute('class', 'focused');
// }
 this.Cursor = eq.GiveCursorTo(this);
 if (this.Cursor != null){
  this.container.appendChild(this.Cursor);
  this.UpdateCursor();
 }
}

//----------------------------------------------------
//     Mouse click
//----------------------------------------------------
Row.prototype.MouseClick = function(evt) {
  if(this.childrenObjects.length < 1) return;
  this.CursorPosition = this.GetClickedComponent(ScreenToClient(this.container, evt));
  this.UpdateCursor();
}

//----------------------------------------------------
//     Get the char index of the clicked char
//----------------------------------------------------
Row.prototype.GetClickedComponent = function(point){
  var i = 0;
  while((i < this.childrenObjects.length) &&
      (parseFloat(this.childrenObjects[i].container.getAttribute('x')) +
      parseFloat(this.childrenObjects[i].container.getAttribute('width')) < point.x)){
   i++;
  }
  if(i == this.childrenObjects.length){
    return i;
  }
  if((point.x - parseFloat(this.childrenObjects[i].container.getAttribute('x'))) > 
    (parseFloat(this.childrenObjects[i].container.getAttribute('width'))/2)){
    i++;
  }
  return i;
}

//----------------------------------------------------
//     Update Cursor Position   
//----------------------------------------------------
Row.prototype.UpdateCursor = function(evt) {
 if(! this.Cursor){
   return;
 }
 if(this.childrenObjects.length == 0){
   this.Cursor.setAttribute('x', parseFloat(this.container.getAttribute('width')/2));
   return;
 }
 var cursor_offset;
 if (this.CursorPosition > 0){
  if (this.CursorPosition < this.childrenObjects.length ){
   cursor_offset = (parseFloat(this.childrenObjects[this.CursorPosition - 1].container.getAttribute('x')) +
      parseFloat(this.childrenObjects[this.CursorPosition - 1].container.getAttribute('width')) +
      parseFloat(this.childrenObjects[this.CursorPosition].container.getAttribute('x')))/2;
  }
  else {
    if(! this.childrenObjects[this.CursorPosition-1]){
      return;
    }
    cursor_offset = parseFloat(this.childrenObjects[this.CursorPosition-1].container.getAttribute('x')) +
      parseFloat(this.childrenObjects[this.CursorPosition - 1].container.getAttribute('width'));
    cursor_offset -= this.CURSOR_MARGIN_DIST;
  }
 }
 else{
   cursor_offset = parseFloat(this.childrenObjects[this.CursorPosition].container.getAttribute('x'));
   cursor_offset += this.CURSOR_MARGIN_DIST;
 }
 cursor_offset -= parseFloat(this.Cursor.getAttribute('width')/2);
 this.Cursor.setAttribute('x', cursor_offset);
}

//----------------------------------------------------
//     Place the cursor before the argument child
//----------------------------------------------------
Row.prototype.SetCursorBefore = function(child) {
  var i;
  for(i = 0; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      eq.setFocusTo(this);
      this.CursorPosition = i;
      this.UpdateCursor();
    }
  }
}

//----------------------------------------------------
//     Place the cursor after the argument child
//----------------------------------------------------
Row.prototype.SetCursorAfter = function(child, KeepFocus) {
  var i;
/*  if(this.parentObject){
    this.parentObject.SetCursorAfter(this, true);
  }*/
  for(i = 0; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      if(KeepFocus){
        this.CursorPosition = i+1;
        return;
      }
      eq.setFocusTo(this);
      this.CursorPosition = i+1;
      this.UpdateCursor();
    }
  }
}

//----------------------------------------------------
//     Enter this row from the end
//----------------------------------------------------
Row.prototype.EnterFromEnd = function(){
  eq.setFocusTo(this);
  this.CursorPosition = this.childrenObjects.length;
  this.UpdateCursor();
}

//----------------------------------------------------
//     Enter this row from the begining
//----------------------------------------------------
Row.prototype.EnterFromBegin = function(){
  eq.setFocusTo(this);
  this.CursorPosition = 0;
  this.UpdateCursor();
}

//----------------------------------------------------
//     Loose Cursor    
//----------------------------------------------------
Row.prototype.LooseCursor = function(evt) {
 if (this.Cursor != null){
  this.container.removeChild(this.Cursor);
  this.Cursor = null;
 }
}

//----------------------------------------------------
//     Loose Focus
//----------------------------------------------------
Row.prototype.FocusLost = function() {
 this.Focused = false;
 this.frame.setAttribute('class', 'idle');
}

//***************************************************

//----------------------------------------------------
//    Update component layout
//----------------------------------------------------
Row.prototype.UpdatePositions = function(){
 var RM = 0;
 var MaxWidth = DEFAULT_TEXTELEMENT_WIDTH;
 var COMPONENT_SPACING = 0;
 var SINGLE_MARGIN = MARGIN;
 var count = this.childrenObjects.length;
// var margin = (count == 1) ? SINGLE_MARGIN : 0;
var margin = 0;
 var cell_tops = new Array(count); //above midline
 this.Midline = 0;
 // Compute the global midline
 for (var i = 0; i < count; i++){
  cell_tops[i] = this.childrenObjects[i].GetMidlineY();
  if (this.Midline < cell_tops[i]) this.Midline = cell_tops[i];
 }
 var offset = RM + margin;
 var height = 0;
 // Set the position of each component
 for (var i = 0; i < count; i++){
  var childY = this.Midline-cell_tops[i];
  this.childrenObjects[i].GetContainer().setAttribute('x', offset);
  this.childrenObjects[i].GetContainer().setAttribute('y', this.Midline-cell_tops[i] + RM);
  var child_size = this.childrenObjects[i].GetSize();
  offset += (child_size.x + COMPONENT_SPACING);
  if(offset > MaxWidth){
    MaxWidth = offset;
  }

  if (height < (childY + child_size.y + RM)) height = childY + child_size.y + RM;
 }
 offset = MaxWidth;
 offset -= COMPONENT_SPACING;
 offset += margin;
 offset += RM;
 height += RM;
 this.Midline += RM;
// if((this.Width != offset) || (this.Height != height)){
   this.Width = offset;
   this.Height = height;
   this.container.setAttribute ('width', this.Scale(offset));
   this.container.setAttribute ('height', this.Scale(height));
   this.container.setAttribute('viewBox', '0 0 ' + (offset) + ' ' + (height));
   if(this.parentObject){
    this.parentObject.UpdatePositions();
   }
// }
 delete cell_tops;
}

//----------------------------------------------------
//    Export the row as Presentational MathML ( <mrow> )
//----------------------------------------------------
Row.prototype.ExportPresentationalMathML = function(indent){
  if(this.childrenObjects.length == 1 && ((this.childrenObjects[0] instanceof EditableLabel) || (this.childrenObjects[0] instanceof StaticLabel))){
    return this.childrenObjects[0].ExportPresentationalMathML(indent);
  }

  var Result = indent + '<mrow>\n';
  for(var i = 0; i < this.childrenObjects.length; i++){
    Result += this.childrenObjects[i].ExportPresentationalMathML(indent + '  ');
  }
  Result += indent + '</mrow>\n';
  return Result;
}

//----------------------------------------------------
//    Export the row as LaTeX
//----------------------------------------------------
Row.prototype.ExportLaTeX = function(){
  if(this.childrenObjects.length == 1 && ((this.childrenObjects[0] instanceof EditableLabel) || (this.childrenObjects[0] instanceof StaticLabel))){
    return this.childrenObjects[0].ExportLaTeX();
  }
  var Result = ' { ';
  for(var i = 0; i < this.childrenObjects.length; i++){
    Result += this.childrenObjects[i].ExportLaTeX() + ' ';
  }
  Result += '} ';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Row.prototype.CreateInstance = function(){
  return new Row(null, this.ScriptLevelModifier);
}

//----------------------------------------------------
//    Delete a child component
//----------------------------------------------------
Row.prototype.DeleteChild = function(child){
  if((this.childrenObjects.length == 1)){
    var EmptyLabel = new EditableLabel(null);
    this.ReplaceChildWith(this.childrenObjects[0], EmptyLabel);
    this.childrenObjects[0].UpdatePositions();
    eq.setFocusTo(this.childrenObjects[0]);
    this.TeX_OpenBrace.setAttribute('display', 'none');
    this.TeX_CloseBrace.setAttribute('display', 'none');
    eq.Modified();
    return;
  }
  var i;
  for(i = 0; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      this.SetCursorBefore(child);
      this.MMLP_Content.removeChild(child.MMLP_Preview);
      this.TeX_Content.removeChild(child.TeX_Preview);
      this.container.removeChild(child.GetContainer());
      this.childrenObjects.splice(i, 1);
      this.UpdatePositions();
      eq.EqModified(this.hWnd, child, UndoStep.prototype.DELETECHILD, i);
      if((this.childrenObjects.length == 1) &&
          ((this.childrenObjects[0] instanceof EditableLabel) || (this.childrenObjects[0] instanceof StaticLabel))){
        this.TeX_OpenBrace.setAttribute('display', 'none');
        this.TeX_CloseBrace.setAttribute('display', 'none');
      }
      else{
        this.TeX_OpenBrace.setAttribute('display', 'inline');
        this.TeX_CloseBrace.setAttribute('display', 'inline');
      }
      eq.Modified();
      return;
    }
  }
}