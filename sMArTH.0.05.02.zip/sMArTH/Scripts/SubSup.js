/**********************************************
Subscript and Superscript support
***********************************************/

SubSup.prototype = new Component();
SubSup.prototype.constructor = SubSup;
//children components indexes 
SubSup.prototype.BASE = 0;
SubSup.prototype.SUP = 1;
SubSup.prototype.SUB = 2;
SubSup.prototype.PRESUP = 3;
SubSup.prototype.PRESUB = 4;

function SubSup(parentObject, scriptLevelModifier, Type){
 this.Midline = 0;
 this.Locked = false;
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject     = parentObject;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.Type = Type;

 this.container = svgDocument.createElement('svg');

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');
 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //create children components 
 this.childrenObjects = new Array();
 // Type encodes the position of the sub/super scripts:
 // 1. The least signifficant bit specifies if a superscript exists;
 // 2. The next bit specifies if a subscript exists.
 if(this.Type % 2 == 1){
  this.childrenObjects[this.SUP] = new Row(this, 1);
  this.childrenObjects[this.SUP].appendChild(new EditableLabel(null), 0, true);
  this.container.appendChild(this.childrenObjects[this.SUP].GetContainer());
 }
 if((this.Type >> 1) % 2 == 1){
  this.childrenObjects[this.SUB] = new Row(this, 1);
  this.childrenObjects[this.SUB].appendChild(new EditableLabel(null), 0, true);
  this.container.appendChild(this.childrenObjects[this.SUB].GetContainer());
 }
 // 3. The next bit specifies if a pre-superscript exists;
 // 4. The next bit specifies if a pre-subscript exists.
 if((this.Type >>2) % 2 == 1){
  this.childrenObjects[this.PRESUP] = new Row(this, 1);
  this.childrenObjects[this.PRESUP].appendChild(new EditableLabel(null), 0, true);
  this.container.appendChild(this.childrenObjects[this.PRESUP].GetContainer());
 }
 if((this.Type >> 3) % 2 == 1){
  this.childrenObjects[this.PRESUB] = new Row(this, 1);
  this.childrenObjects[this.PRESUB].appendChild(new EditableLabel(null), 0, true);
  this.container.appendChild(this.childrenObjects[this.PRESUB].GetContainer());
 }

 this.childrenObjects[this.BASE] = new Row(this);
 this.childrenObjects[this.BASE].appendChild(new EditableLabel(null), 0, true);
 this.container.appendChild(this.childrenObjects[this.BASE].GetContainer());

 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');

 this.InsertTSpans();
 this.TeX_Preview.appendChild(this.TeX_Content);
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
SubSup.prototype.UpdatePositions = function(){
 if(! this.childrenObjects[this.BASE]) return;
 //obtain the size of each child element
 var base_size = this.childrenObjects[this.BASE].GetSize();
 
 var sup_size = (this.Type % 2) ? this.childrenObjects[this.SUP].GetSize() : svgDocument.documentElement.createSVGPoint();
 var sub_size = ((this.Type >> 1) % 2) ? this.childrenObjects[this.SUB].GetSize() : svgDocument.documentElement.createSVGPoint();

 var presup_size = ((this.Type >> 2)% 2) ? this.childrenObjects[this.PRESUP].GetSize() : svgDocument.documentElement.createSVGPoint();
 var presub_size = ((this.Type >> 3) % 2) ? this.childrenObjects[this.PRESUB].GetSize() : svgDocument.documentElement.createSVGPoint();
 
 var Width = 2*MARGIN + base_size.x + Maximum(sup_size.x, sub_size.x) + Maximum(presup_size.x, presub_size.x);
 var Height = Maximum(base_size.y / 3, Maximum(sup_size.y, presup_size.y)) + (base_size.y / 3)
     + Maximum(base_size.y / 3, Maximum(sub_size.y, presub_size.y));

 //obtain the position of each child element
 var baseX = MARGIN + Maximum(presup_size.x, presub_size.x);
 var baseY = Maximum(Maximum(sup_size.y, presup_size.y) - base_size.y / 3, 0);

 var supX = baseX + base_size.x;
 var supY = baseY + base_size.y/3 - sup_size.y;
 var subX = baseX + base_size.x;
 var subY = baseY + 2*base_size.y/3;

 var presupX = baseX - presup_size.x;
 var presupY = baseY + base_size.y/3 - presup_size.y;
 var presubX = baseX - presub_size.x;
 var presubY = baseY + 2*base_size.y/3;

 //resize and organize the container
 this.container.setAttribute ('width', this.Scale(Width));
 this.container.setAttribute ('height', this.Scale(Height));
 this.container.setAttribute('viewBox', '0 0 ' + Width + ' ' + Height);

 if(this.Type % 2){
  this.childrenObjects[this.SUP].container.setAttribute('x', supX);
  this.childrenObjects[this.SUP].container.setAttribute('y', supY);
 }
 if((this.Type >> 1) % 2){
  this.childrenObjects[this.SUB].container.setAttribute('x', subX);
  this.childrenObjects[this.SUB].container.setAttribute('y', subY);
 }
 if((this.Type >> 2) % 2){
  this.childrenObjects[this.PRESUP].container.setAttribute('x', presupX);
  this.childrenObjects[this.PRESUP].container.setAttribute('y', presupY);
 }
 if((this.Type >> 3) % 2){
  this.childrenObjects[this.PRESUB].container.setAttribute('x', presubX);
  this.childrenObjects[this.PRESUB].container.setAttribute('y', presubY);
 }

 this.Midline = baseY + this.childrenObjects[this.BASE].GetMidlineY();

 this.childrenObjects[this.BASE].container.setAttribute('x', baseX);
 this.childrenObjects[this.BASE].container.setAttribute('y', baseY);

 //update parent
 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the SubSup as Presentational MathML (<msup>, <msub>, <msubsup> or <mmultiscripts>
//----------------------------------------------------
SubSup.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent;
  if(this.Type < 3){
    if(this.Type == 1){
      // Sup
      Result += '<msup>\n';
      Result += this.childrenObjects[this.BASE].ExportPresentationalMathML(indent + '  ');
      Result += this.childrenObjects[this.SUP].ExportPresentationalMathML(indent + '  ');
      Result += indent + '</msup>\n';
    }
    else if(this.Type == 2){
      // Sub
      Result += '<msub>\n';
      Result += this.childrenObjects[this.BASE].ExportPresentationalMathML(indent + '  ');
      Result += this.childrenObjects[this.SUB].ExportPresentationalMathML(indent + '  ');
      Result += indent + '</msub>\n';
    }
    else if(this.Type == 3){
      // SubSup
      Result += '<msubsup>\n';
      Result += this.childrenObjects[this.BASE].ExportPresentationalMathML(indent + '  ');
      Result += this.childrenObjects[this.SUB].ExportPresentationalMathML(indent + '  ');
      Result += this.childrenObjects[this.SUP].ExportPresentationalMathML(indent + '  ');
      Result += indent + '</msubsup>\n';
    }
  }
  else{
    // Multiscripts
    Result += '<mmultiscripts>\n';
    Result += this.childrenObjects[this.BASE].ExportPresentationalMathML(indent + '  ');
    if((this.Type % 2) && ((this.Type >> 1) %2)){
      if((this.Type >> 1) % 2){
        Result += this.childrenObjects[this.SUB].ExportPresentationalMathML(indent + '  ');
      }
      else{
        Result += indent + '<none/>\n';
      }
      if(this.Type % 2){
        Result += this.childrenObjects[this.SUP].ExportPresentationalMathML(indent + '  ');
      }
      else{
        Result += indent + '<none/>\n';
      }
    }
    Result += indent + '<mprescripts/>\n';
    if((this.Type >> 3) % 2){
      Result += this.childrenObjects[this.PRESUB].ExportPresentationalMathML(indent + '  ');
    }
    else{
      Result += indent + '<none/>\n';
    }
    if((this.Type >> 2) % 2){
      Result += this.childrenObjects[this.PRESUP].ExportPresentationalMathML(indent + '  ');
    }
    else{
      Result += indent + '<none/>\n';
    }
    Result += indent + '</mmultiscripts>\n';
  }
  return Result;
}

//----------------------------------------------------
//    Add the preview tspans
//----------------------------------------------------
SubSup.prototype.InsertTSpans = function(){
  if(this.Type <= 3){
    if(this.Type == 1){
      // Sup
      this.CreateTSpans('msup', 'msup');
      this.MMLP_Content.appendChild(this.childrenObjects[this.BASE].MMLP_Preview);
      this.MMLP_Content.appendChild(this.childrenObjects[this.SUP].MMLP_Preview);

      this.TeX_Content.appendChild(this.childrenObjects[this.BASE].TeX_Preview);
      TeXTspan = MakeTSpan(true);
      TeXTspan.appendChild(document.createTextNode('^'));
      this.TeX_Content.appendChild(TeXTspan);
      this.TeX_Content.appendChild(this.childrenObjects[this.SUP].TeX_Preview);
    }
    else if(this.Type == 2){
      // Sub
      this.CreateTSpans('msub', 'msub');
      this.MMLP_Content.appendChild(this.childrenObjects[this.BASE].MMLP_Preview);
      this.MMLP_Content.appendChild(this.childrenObjects[this.SUB].MMLP_Preview);

      this.TeX_Content.appendChild(this.childrenObjects[this.BASE].TeX_Preview);
      TeXTspan = MakeTSpan(true);
      TeXTspan.appendChild(document.createTextNode('_'));
      this.TeX_Content.appendChild(TeXTspan);
      this.TeX_Content.appendChild(this.childrenObjects[this.SUB].TeX_Preview);
    }
    else if(this.Type == 3){
      // SubSup
      this.CreateTSpans('msubsup', 'msubsup');
      this.MMLP_Content.appendChild(this.childrenObjects[this.BASE].MMLP_Preview);
      this.MMLP_Content.appendChild(this.childrenObjects[this.SUB].MMLP_Preview);
      this.MMLP_Content.appendChild(this.childrenObjects[this.SUP].MMLP_Preview);

      this.TeX_Content.appendChild(this.childrenObjects[this.BASE].TeX_Preview);
      TeXTspan = MakeTSpan(true);
      TeXTspan.appendChild(document.createTextNode('_'));
      this.TeX_Content.appendChild(TeXTspan);
      this.TeX_Content.appendChild(this.childrenObjects[this.SUB].TeX_Preview);
      TeXTspan = MakeTSpan(true);
      TeXTspan.appendChild(document.createTextNode('^'));
      this.TeX_Content.appendChild(TeXTspan);
      this.TeX_Content.appendChild(this.childrenObjects[this.SUP].TeX_Preview);
    }
  }
  else{
    // Multiscripts

    // Insert MathML preview tspans
    this.CreateTSpans('mmultiscripts', 'mmultiscripts');
      this.MMLP_Content.appendChild(this.childrenObjects[this.BASE].MMLP_Preview);
    if((this.Type % 2) && ((this.Type >> 1) %2)){
      if((this.Type >> 1) % 2){
        this.MMLP_Content.appendChild(this.childrenObjects[this.SUB].MMLP_Preview);
      }
      else{
        var none = MakeTSpan();
        none.appendChild(svgDocument.createTextNode('<none/>'));
        this.MMLP_Content.appendChild(none);
      }
      if(this.Type % 2){
        this.MMLP_Content.appendChild(this.childrenObjects[this.SUP].MMLP_Preview);
      }
      else{
        var none = MakeTSpan();
        none.appendChild(svgDocument.createTextNode('<none/>'));
        this.MMLP_Content.appendChild(none);
      }
    }
    var mprescripts = MakeTSpan();
    mprescripts.appendChild(svgDocument.createTextNode('<mprescripts/>'));
    this.MMLP_Content.appendChild(mprescripts);
    if((this.Type >> 3) % 2){
      this.MMLP_Content.appendChild(this.childrenObjects[this.PRESUB].MMLP_Preview);
    }
    else{
      var none = MakeTSpan();
      none.appendChild(svgDocument.createTextNode('<none/>'));
      this.MMLP_Content.appendChild(none);
    }
    if((this.Type >> 2) % 2){
      this.MMLP_Content.appendChild(this.childrenObjects[this.PRESUP].MMLP_Preview);
    }
    else{
      var none = MakeTSpan();
      none.appendChild(svgDocument.createTextNode('<none/>'));
      this.MMLP_Content.appendChild(none);
    }

    // Insert LaTeX preview tspans
    if(this.childrenObjects[this.PRESUB]){
      TeXTspan = MakeTSpan(true);
      TeXTspan.appendChild(document.createTextNode(' _'));
      this.TeX_Content.appendChild(TeXTspan);
      this.TeX_Content.appendChild(this.childrenObjects[this.PRESUB].TeX_Preview);
    }
    if(this.childrenObjects[this.PRESUP]){
      TeXTspan = MakeTSpan(true);
      TeXTspan.appendChild(document.createTextNode('^'));
      this.TeX_Content.appendChild(TeXTspan);
      this.TeX_Content.appendChild(this.childrenObjects[this.PRESUP].TeX_Preview);
    }
    this.TeX_Content.appendChild(this.childrenObjects[this.BASE].TeX_Preview);
    if(this.childrenObjects[this.SUB]){
      TeXTspan = MakeTSpan(true);
      TeXTspan.appendChild(document.createTextNode('_'));
      this.TeX_Content.appendChild(TeXTspan);
      this.TeX_Content.appendChild(this.childrenObjects[this.SUB].TeX_Preview);
    }
    if(this.childrenObjects[this.SUP]){
      TeXTspan = MakeTSpan(true);
      TeXTspan.appendChild(document.createTextNode('^'));
      this.TeX_Content.appendChild(TeXTspan);
      this.TeX_Content.appendChild(this.childrenObjects[this.SUP].TeX_Preview);
    }
  }
}

//----------------------------------------------------
//    Export the SubSup as LaTeX
//----------------------------------------------------
SubSup.prototype.ExportLaTeX = function(){
  var Result = '';
  if(this.childrenObjects[this.PRESUB]){
    Result += '_' + this.childrenObjects[this.PRESUB].ExportLaTeX();
  }
  if(this.childrenObjects[this.PRESUP]){
    Result += '^' + this.childrenObjects[this.PRESUP].ExportLaTeX();
  }
  Result += this.childrenObjects[this.BASE].ExportLaTeX();
  if(this.childrenObjects[this.SUB]){
    Result += '_' + this.childrenObjects[this.SUB].ExportLaTeX();
  }
  if(this.childrenObjects[this.SUP]){
    Result += '^' + this.childrenObjects[this.SUP].ExportLaTeX();
  }
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
SubSup.prototype.CreateInstance = function(){
  return new SubSup(null, this.ScriptLevelModifier, this.Type);
}
