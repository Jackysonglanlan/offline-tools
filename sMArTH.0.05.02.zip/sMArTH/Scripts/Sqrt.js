/**********************************************
Sqrt
***********************************************/

Sqrt.prototype = new Component();
Sqrt.prototype.constructor = Sqrt;
//children components indexes 
Sqrt.prototype.BASE = 0;

function Sqrt(parentObject, scriptLevelModifier){
  this.Midline = 0;
  this.Locked = false;
  this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);

  //when creted, this component notifies the component manager
  this.hWnd = eq.registerWindow(this);
  //the object should remember its parent
  this.parentObject = parentObject;

  this.CreateTSpans('msqrt', 'msqrt');

  this.TeX_Preview = MakeTSpan(true);
  this.TeX_Content = MakeTSpan(true);
  var TeXTspan = MakeTSpan(true);
  TeXTspan.appendChild(document.createTextNode('\\sqrt \n'));
  this.TeX_Preview.appendChild(TeXTspan);
  this.TeX_Preview.appendChild(this.TeX_Content);

  this.container = svgDocument.createElement('svg');

  //create the component outer frame
  this.frame = svgDocument.createElement('rect');
  this.frame.setAttribute('width', '100%');
  this.frame.setAttribute('height', '100%');

  //set the component status to idle
  this.frame.setAttribute('class', 'idle');

  //insert the frame in the component
  this.container.appendChild(this.frame);

  //Draw the symbol
  this.rootSymbol = svgDocument.createElement('path');
  this.rootSymbol.setAttribute('class', 'mathSymbolLine');

  //insert the root symbol in the component
  this.container.appendChild(this.rootSymbol);

  //create children components 
  this.childrenObjects = new Array();
  this.appendChild(new Row(this), this.BASE, true);
  this.InsertTSpanFor(this.childrenObjects[this.BASE], this.childrenObjects[this.BASE].MMLP_Preview);
  this.childrenObjects[this.BASE].appendChild(new EditableLabel(null), 0, true);

  this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Sqrt.prototype.UpdatePositions = function(){
  if(!this.childrenObjects[this.BASE]){
    return;
  }
  var base_size = this.childrenObjects[this.BASE].GetSize();
  var rootSymbolHeight = base_size.y + MARGIN;
  var tailLeftHeight = Minimum(rootSymbolHeight/3, ROOT_TAIL_HEIGHT);
  var tailRightWidth = Minimum(rootSymbolHeight/3, ROOT_TAIL_RIGHT_WIDTH);
  var tailLeftWidth  = Minimum(rootSymbolHeight/6, ROOT_TAIL_LEFT_WIDTH);
  var tailCenterX = MARGIN + tailLeftWidth;
  var rootSymbolY = LINEWIDTH;
  var rootSymbolX = MARGIN;
  var Width = tailCenterX + tailRightWidth + MARGIN + base_size.x;
  var Height = rootSymbolY + rootSymbolHeight;
  var baseX = Width - base_size.x;
  var baseY = Height - base_size.y;

  this.container.setAttribute ('width', this.Scale(Width));
  this.container.setAttribute ('height', this.Scale(Height));
  this.container.setAttribute('viewBox', '0 0 ' + Width + ' ' + Height);

  var rootSymbolPath = "M " + (rootSymbolX-1) + " " + (Height - tailLeftHeight + 1) + " L " + 
    rootSymbolX + " " + (Height - tailLeftHeight) + " " +
    tailCenterX + " " + Height + " " +
    (tailCenterX + tailRightWidth) + " " + (rootSymbolY - LINEWIDTH/2) + " " +
    (Width) + " " + (rootSymbolY - LINEWIDTH/2);
  this.rootSymbol.setAttribute('d', rootSymbolPath);

  this.Midline = baseY + this.childrenObjects[this.BASE].GetMidlineY();

  this.childrenObjects[this.BASE].container.setAttribute('x', baseX);
  this.childrenObjects[this.BASE].container.setAttribute('y', baseY);
  if(this.parentObject != null){
    this.parentObject.UpdatePositions();
  }
}

//----------------------------------------------------
//    Export the Sqrt as Presentational MathML ( <msqrt> )
//----------------------------------------------------
Sqrt.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent + '<msqrt>\n';
  Result += this.childrenObjects[this.BASE].ExportPresentationalMathML(indent + '  ');
  return Result + indent + '</msqrt>\n';
}

//----------------------------------------------------
//    Export the Sqrt as LaTeX
//----------------------------------------------------
Sqrt.prototype.ExportLaTeX = function(){
  var Result = '\\sqrt ';
  Result += this.childrenObjects[this.BASE].ExportLaTeX();
  return Result;
}

//----------------------------------------------------
//    Export sqrt as SVG image
//----------------------------------------------------
Sqrt.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += indent + '  ' + printNode(this.rootSymbol) + '\n';
  Result += this.childrenObjects[this.BASE].ExportSVGNode(indent + '  ');
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Sqrt.prototype.CreateInstance = function(){
  return new Sqrt(null, this.ScriptLevelModifier);
}
