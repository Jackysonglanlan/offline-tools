/***********************************************
 EQContainer

 - the container for the equation components
 - manages component focus 
************************************************/

var MARGIN = 2;
var CELLSPACING = 5;
var DEFAULT_TEXTELEMENT_WIDTH = 6;
var DEFAULT_TEXTELEMENT_HEIGHT = 25;

var DEFAULT_ELEMENT_WIDTH = 6;
var DEFAULT_ELEMENT_HEIGHT = 25;

var ROW_SPACING = 10;
var ROW_OFFSET = 10;

//var SCRIPTSIZEMULTIPLIER = 1.4142;
var SCRIPTSIZEMULTIPLIER = 1.25;
var FONTSIZE = 14;

var ROOT_TAIL_LEFT_WIDTH  = 4;
var ROOT_TAIL_RIGHT_WIDTH = 7;
var ROOT_TAIL_HEIGHT = 42;

var BEVELLED_FRACTION_DX = 10;
var BEVELLED_FRACTION_DY = 6;

var SCROLLBAR_WIDTH = 15;
var SCROLLBAR_MIN_LENGTH = 5;

var SCROLL_DELTA = 20;

var WORK_AREA_WIDTH = 660;
var WORK_AREA_HEIGHT = 644;

var TOOLBAR_AREA_HEIGHT = 646;

var PREVIEW_AREA_HEIGHT = 496;
var PREVIEW_AREA_WIDTH = 240;

var XML_INDENT = 10;

var LINEWIDTH = 1;

var PREVIEW_TSPAN_DY = 12;
var PREVIEW_TSPAN_X = 5;

var FENCE_WIDTH = 5;
var MIN_DECO_WIDTH = 15;
var DECO_HEIGHT = 5;

var DEFAULT_STATUS_MESSAGE = "";
//----------------------------------------------------
//     EQContainer Constructor
//----------------------------------------------------
function EQContainer(){
 this.FocusedElement = null; 
 this.hWndList = new Object();
 this.nextFreeHwnd = 0;
 this.CursorKeeper = null;
 //create cursor
 this.Cursor = svgDocument.getElementById('cursor');
 svgDocument.getElementById('eqcontainer').removeChild(this.Cursor);
 this.StatusMessage = DEFAULT_STATUS_MESSAGE;
 this.DisplayedStatusBarText = svgDocument.getElementById('StatusBar').childNodes.item(0);
 this.Save = new Object();
 this.Save['MMLP'] = false;
 this.Save['LaTeX'] = false;
 this.Save['SVG'] = false;
 this.IsSaved = false;
 this.IsUpToDate = false;
 this.UndoSequenceIndex = 0;
 this.UndoVector = new Array();
 this.UndoPointer = -1;
}

//----------------------------------------------------
//     Make the root equation container
//----------------------------------------------------
EQContainer.prototype.makeRootElement = function(){
 this.eqRoot = new EqRoot(svgDocument.getElementById('eqcontainer'));
 this.FocusedElement = this.eqRoot;
}

//----------------------------------------------------
//     Return the object identified by hWnd
//----------------------------------------------------
EQContainer.prototype.GetElementByHwnd = function(hWnd){
 return this.hWndList[hWnd];
}

//----------------------------------------------------
//     Get the next undo step index in the current sequence
//----------------------------------------------------
EQContainer.prototype.NextUndoStepIndex = function(){
  return this.UndoSequenceIndex++;
}

//----------------------------------------------------
//     Reset the undo step index, marking a new sequence
//----------------------------------------------------
EQContainer.prototype.BeginUndoSequence = function(){
  this.UndoSequenceIndex = 0;
}

//----------------------------------------------------
//     Update Undo list on modification
//----------------------------------------------------
EQContainer.prototype.EqModified = function(SourceHwnd, Argument, Operation, Location, SecondArgument){
  var Modification = new UndoStep(SourceHwnd, Argument, Operation, Location, SecondArgument);
  ++this.UndoPointer;
  this.UndoVector.splice(this.UndoPointer, this.UndoVector.length - this.UndoPointer);
  this.UndoVector[this.UndoPointer] = Modification;
}

//----------------------------------------------------
//     Undo a step
//----------------------------------------------------
EQContainer.prototype.Undo = function(){
  var CurrentSequenceIndex = this.UndoVector[this.UndoPointer].SeqIndex;
  while((this.UndoPointer > 1) && (this.UndoVector[this.UndoPointer].SeqIndex == CurrentSequenceIndex)){
    this.UndoVector[this.UndoPointer--].undo();
    CurrentSequenceIndex--;
  }
}

//----------------------------------------------------
//     Redo a step
//----------------------------------------------------
EQContainer.prototype.Redo = function(){
  if(this.UndoPointer >= this.UndoVector.length - 1){
    return;
  }
  var CurrentSequenceIndex = this.UndoVector[this.UndoPointer+1].SeqIndex;
  while((this.UndoPointer < this.UndoVector.length - 1) && (this.UndoVector[this.UndoPointer+1].SeqIndex == CurrentSequenceIndex)){
    this.UndoPointer++;
    this.UndoVector[this.UndoPointer].redo();
    CurrentSequenceIndex++;
  }
}

//----------------------------------------------------
//     Return the root equation container
//----------------------------------------------------
EQContainer.prototype.getRootElement = function(){
 return this.eqRoot;
}

//----------------------------------------------------
//     Register Window
//----------------------------------------------------
EQContainer.prototype.registerWindow = function(windowObject){
 this.hWndList[this.nextFreeHwnd] = windowObject;
 return this.nextFreeHwnd++;
}

//----------------------------------------------------
//     Set tooltip status message
//----------------------------------------------------
EQContainer.prototype.SetToolTipStatus = function(message){
 this.DisplayedStatusBarText.nodeValue = message;
}

//----------------------------------------------------
//     Set tooltip status message
//----------------------------------------------------
EQContainer.prototype.SetCrtActionStatus = function(message){
 this.StatusMessage = message;
 this.DisplayedStatusBarText.nodeValue = message;
}

//----------------------------------------------------
//     Set tooltip status message
//----------------------------------------------------
EQContainer.prototype.RestoreStatus = function(){
 this.DisplayedStatusBarText.nodeValue = this.StatusMessage;
}

//----------------------------------------------------
//     Start looking for an editable label
//----------------------------------------------------
EQContainer.prototype.StartLeafSearch = function(Component){
 this.TreeParseCount = 0;
 this.SearchInitializer = Component;
}

//----------------------------------------------------
//     Check if this is an infinite search for an editable label
//----------------------------------------------------
EQContainer.prototype.ContinueLeafSearch = function(Component){
  if(this.SearchInitializer == Component){
    if(this.TreeParseCount == 2){
      return false;
    }
    this.TreeParseCount++;
  }
  return true;
}

//----------------------------------------------------
//     Stop looking for an label
//----------------------------------------------------
EQContainer.prototype.StopLeafSearch = function(){
 this.SearchInitializer = null;
 this.TreeParseCount = 0;
}

//----------------------------------------------------
//     Remove focus from an inner element
//----------------------------------------------------
EQContainer.prototype.Unfocus = function(){
 if(this.FocusedElement){
  this.FocusedElement.FocusLost();
 }
 this.FocusedElement = this.eqRoot;
 if(this.CursorKeeper != null){
  this.CursorKeeper.LooseCursor();
  this.CursorKeeper = null;
  this.hideCursor();
 }
}

//----------------------------------------------------
//     Sets focus to an inner element
//----------------------------------------------------
EQContainer.prototype.setFocusTo = function(element){
 if(this.FocusedElement){
  this.FocusedElement.FocusLost();
 }
 this.FocusedElement = element;
 this.FocusedElement.FocusGained();
 return true;
}

//----------------------------------------------------
//     Set the cursor to an inner element
//----------------------------------------------------
EQContainer.prototype.GiveCursorTo = function(editlabel){
 if (this.CursorKeeper != null){
  this.CursorKeeper.LooseCursor();
 }
 else {
  this.showCursor();
 }
 if (editlabel == null){
  this.hideCursor();
 } 

 this.CursorKeeper = editlabel;
 return this.Cursor; 
}
//*********** Cursor Display Functions  ***************
//----------------------------------------------------
//     Set the cursor to an inner element
//----------------------------------------------------
EQContainer.prototype.showCursor = function(){
 this.Cursor.setAttribute('display', 'inline');
}
//----------------------------------------------------
//     Set the cursor to an inner element
//----------------------------------------------------
EQContainer.prototype.hideCursor = function(){
 this.Cursor.setAttribute('display', 'none');
}
//******************************************************
//----------------------------------------------------
//     Retrieve the focused element
//----------------------------------------------------
EQContainer.prototype.getFocusedElement = function(){
 return this.FocusedElement;
}

//----------------------------------------------------
//     Prev
//----------------------------------------------------
EQContainer.prototype.getPrev = function(element){
}
//----------------------------------------------------
//     Next
//----------------------------------------------------
EQContainer.prototype.getNext = function(element){
}

//********   EVENTS   ************************//
//----------------------------------------------------
//    Mouse Click Event
//----------------------------------------------------
EQContainer.prototype.eqMouseClick = function(evt, hWnd){
 evt.stopPropagation();
 object = this.hWndList[hWnd];
 if(object != this.FocusedElement){
  this.setFocusTo(object);
 }
 object.MouseClick(evt);
}

//----------------------------------------------------
//    Mouse Over Event
//----------------------------------------------------
EQContainer.prototype.eqMouseOver = function(evt, hWnd){
//alert(1);
 evt.stopPropagation();
 object = this.hWndList[hWnd];
 if(object != null){
  object.MouseOver(evt);
 }
}

//----------------------------------------------------
//    Mouse Out Event
//----------------------------------------------------
EQContainer.prototype.eqMouseOut = function(evt, hWnd){
 evt.stopPropagation();
 object = this.hWndList[hWnd];
 if(object != null){
  object.MouseOut(evt);
 }
}

//----------------------------------------------------
//    Mouse Move Event
//----------------------------------------------------
EQContainer.prototype.eqMouseMove = function(evt){
 if(this.Dragging){
// alert(11);
   this.Dragging.MouseMove(evt);
 }
}

//----------------------------------------------------
//    Mouse Up Event
//----------------------------------------------------
EQContainer.prototype.eqMouseUp = function(evt){
 if(this.Dragging){
   this.Dragging.MouseUp(evt);
 }
}

//----------------------------------------------------
//     Key Press Event
//----------------------------------------------------
EQContainer.prototype.eqKeyPress = function(evt){
  eq.BeginUndoSequence();
 if(evt.ctrlKey){
  if(evt.charCode == 11){
    // ctrl + k => Copy
    Copy();
    evt.preventDefault();
    evt.stopPropagation();
  }
  else if(evt.charCode == 24){
    // ctrl + x => Cut
    Cut();
    evt.preventDefault();
    evt.stopPropagation();
  }
  else if(evt.charCode == 22){
    // ctrl + v => Paste
    Paste();
    evt.preventDefault();
    evt.stopPropagation();
  }
  else if(evt.charCode == 20){
    // ctrl + t => Save
    Save();
    evt.preventDefault();
    evt.stopPropagation();
  }
  else if(evt.charCode == 26){
    // ctrl + z => Undo
    Undo();
    evt.preventDefault();
    evt.stopPropagation();
  }
  else if(evt.charCode == 25){
    // ctrl + y => Redo
    Redo();
    evt.preventDefault();
    evt.stopPropagation();
  }
  return;
 }
 evt.preventDefault();
 if (this.FocusedElement.WantAllChars()) {
   this.FocusedElement.KeyPress(evt);
   evt.stopPropagation();
   return true;
 }
 if (this.PreTranslateMessage(evt)){
 //the app filtrates the keybord inputs in order to execute the accelerators
   evt.stopPropagation();
   return false;
 }
 if (this.FocusedElement){
   this.FocusedElement.KeyPress(evt);
   evt.stopPropagation();
 }
 return true;
}

//----------------------------------------------------
//     Key Down Event
//----------------------------------------------------
EQContainer.prototype.eqKeyDown = function(evt){
  eq.BeginUndoSequence();
 evt.preventDefault();
 if (this.FocusedElement.WantAllChars()) {
   this.FocusedElement.KeyDown(evt);
   evt.stopPropagation();
   return true;
 }
 if (this.PreTranslateMessage(evt)){
 //the app filtrates the keybord inputs in order to execute the accelerators
   evt.stopPropagation();
   return false;
 }
 if (this.FocusedElement){
   this.FocusedElement.KeyDown(evt);
   evt.stopPropagation();
 }
 return true;
}

//----------------------------------------------------
//     Key Up Event
//----------------------------------------------------
EQContainer.prototype.eqKeyUp = function(evt){
 evt.preventDefault();
 evt.stopPropagation();
}

//----------------------------------------------------
//     Key Event Preprocessor
//----------------------------------------------------
EQContainer.prototype.PreTranslateMessage = function(evt){
 if(evt.charCode == 0){
//   Code = evt.keyCode;
   Code = -1;
 }
 else{
   Code = evt.charCode;
 }
 if (this.getAccelerator(Code) == true){
    return true;
 }
 return false;
}

//----------------------------------------------------
//     Get Toolbar Accelerator
//----------------------------------------------------
EQContainer.prototype.getAccelerator = function(charCode){
  switch(charCode){
  case 32:  //   space
    // Insert a thin space
    newstatic('&ThinSpace;', 0, false, StaticLabel.prototype.MTEXT);
    return true;
  case 43:  //     +
    newstatic('&plus;');
    return true;
  case 45:  //     -
    newstatic('&minus;');
    return true;
  case 42:  //     *
    newstatic('&sdot;');
    return true;
  case 47:  //     /
//    newstatic('&#x02215;');
    newstatic('/');
    return true;
  case 37:  //     %
    newstatic('%');
    return true;
  case 60:  //     <
    newstatic('&lt;');
    return true;
  case 62:  //     >
    newstatic('&gt;');
    return true;
  case 61:  //     =
    newstatic('&equals;');
    return true;

  case 40:  //     (
    if(this.getFocusedElement() instanceof EditableLabel){
      return false;
    }
    newfenced('(' , ')');
    return true;
  case 41:  //     )
    return true; 
  case 91:  //     [
    newfenced('[' , ']');
    return true;
  case 93:  //     ]
    return true;
  case 123:  //     {
    newfenced('{' , '}');
    return true;
  case 125:  //     }
    return true;
  case 38:  //     &
    newstatic('&');
    return true;
  case 124: //     |
    newstatic('|');
    return true;
  case 126: //     ~
    newstatic('&sim;');
    return true;
  case 94:  //     ^
    newstatic('^');
    return true;
  case 33:  //     !
    newstatic('!');
    return true;
  case 46:  //     .
    //newstatic('.');
    return false;
  case 44:  //     ,
    newstatic(',');
    return true;
  case 39:  //     '
    newprime('&prime;');
    return true;
  case 34:  //     "
    newprime('&Prime;');
    return true;
  case 95:  //     _
    newstatic('_', 0, false, StaticLabel.prototype.MTEXT);
    return true;
  case 92:  //     \
    newstatic('\\');
    return true;
  case 63:  //     ?
    newstatic('?');
    return true;
  case 58:  //     :
    newstatic(':');
    return true;
  case 96:  //     `
    newstatic('`');
    return true;
 }
 return false;
}

//----------------------------------------------------
//     File modified Event
//----------------------------------------------------
EQContainer.prototype.Modified = function(){
  if((this.IsSaved == true) && (this.IsUpToDate == true)){
    document.getElementById('modified').setAttribute('display', 'inline');
    this.IsUpToDate = false;
  }
  if(window.MMLPPreViewScroller){
    var MMLPPreviewViewBox = document.getElementById('mmlpFileArea').getAttribute('viewBox');
    var MMLPPreviewViewRect = svgDocument.documentElement.createSVGRect();
    var viewBoxParams = MMLPPreviewViewBox.split(/\s*,\s*|\s+/);
    MMLPPreviewViewRect.x = parseFloat(viewBoxParams[0]);
    MMLPPreviewViewRect.y = parseFloat(viewBoxParams[1]);
    MMLPPreviewViewRect.width = parseFloat(viewBoxParams[2]);
    MMLPPreviewViewRect.height = parseFloat(viewBoxParams[3]);
    var MMLPPreviewBBox = document.getElementById('mmlpFileArea').getBBox();
    MMLPPreViewScroller.UpdateScrollbars(MMLPPreviewBBox, MMLPPreviewViewRect)

    var LaTeXPreviewViewBox = document.getElementById('latexFileArea').getAttribute('viewBox');
    var LaTeXPreviewViewRect = svgDocument.documentElement.createSVGRect();
    var viewBoxParams = LaTeXPreviewViewBox.split(/\s*,\s*|\s+/);
    LaTeXPreviewViewRect.x = parseFloat(viewBoxParams[0]);
    LaTeXPreviewViewRect.y = parseFloat(viewBoxParams[1]);
    LaTeXPreviewViewRect.width = parseFloat(viewBoxParams[2]);
    LaTeXPreviewViewRect.height = parseFloat(viewBoxParams[3]);
    var LaTeXPreviewBBox = document.getElementById('latexFileArea').getBBox();
    LaTeXPreViewScroller.UpdateScrollbars(LaTeXPreviewBBox, LaTeXPreviewViewRect)
  }
}