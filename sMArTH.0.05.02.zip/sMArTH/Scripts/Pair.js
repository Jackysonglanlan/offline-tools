/**********************************************
Pair Operator
***********************************************/

Pair.prototype = new Component();
Pair.prototype.constructor = Pair;
//children components indexes 
Pair.prototype.LEFT = 1;
Pair.prototype.RIGHT = 0;

function Pair(parentObject, scriptLevelModifier, FunctionCategory){
  //when creted, this component notifies the component manager
  this.hWnd = eq.registerWindow(this);
  //the object should remember its parent
  this.parentObject     = parentObject;
  this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
  this.FunctionCategory = FunctionCategory;
  this.container = svgDocument.createElement('svg');
  this.Midline = 0;
  this.Locked = false;

  this.CreateTSpans();
  this.TeX_Preview.appendChild(this.TeX_Content);

  //create the component outer frame
  this.frame = svgDocument.createElement('rect');
  this.frame.setAttribute('width', '100%');
  this.frame.setAttribute('height', '100%');

  //set the component status to idle
  this.frame.setAttribute('class', 'idle');

  //insert the frame in the component
  this.container.appendChild(this.frame);

  //create children components 
  this.childrenObjects = new Array();

  this.appendChild(new Row(this), this.RIGHT, true);
  this.childrenObjects[this.RIGHT].appendChild(new EditableLabel(null), 0, true);
  this.childrenObjects[this.RIGHT].Locked = false;

  this.appendChild(new Row(this), this.LEFT, true);
  this.childrenObjects[this.LEFT].appendChild(new EditableLabel(null), 0, true);
  this.childrenObjects[this.LEFT].Locked = true;

  this.AppendTSpanFor(this.childrenObjects[this.LEFT]);
  this.AppendTSpanFor(this.childrenObjects[this.RIGHT]);

  this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Pair.prototype.UpdatePositions = function(){
 if(this.childrenObjects.length < 2) return;
 // Compute children's boundingboxes
 var left_size  = this.childrenObjects[this.LEFT].GetSize();
 var right_size = this.childrenObjects[this.RIGHT].GetSize();

 // Compute children's midline positions
 var LeftMidline = this.childrenObjects[this.LEFT].GetMidlineY();
 var RightMidline = this.childrenObjects[this.RIGHT].GetMidlineY();

 // Compute global midline
 this.Midline = Maximum(LeftMidline, RightMidline);

 var width = left_size.x + right_size.x;
 var height = Maximum(left_size.y + this.Midline - LeftMidline, right_size.y + this.Midline - RightMidline);

 this.container.setAttribute('width', this.Scale(width));
 this.container.setAttribute('height', this.Scale(height));
 this.container.setAttribute('viewBox', '0 0 ' + width + ' ' + height);

 this.childrenObjects[this.LEFT].container.setAttribute('x', 0);
 this.childrenObjects[this.RIGHT].container.setAttribute('x', left_size.x);

 this.childrenObjects[this.LEFT].container.setAttribute('y', this.Midline - LeftMidline);
 this.childrenObjects[this.RIGHT].container.setAttribute('y', this.Midline - RightMidline);

 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the pair as Presentational MathML
//----------------------------------------------------
Pair.prototype.ExportPresentationalMathML = function(indent){
  var Result = this.childrenObjects[this.LEFT].ExportPresentationalMathML(indent + '  ');
  Result += this.childrenObjects[this.RIGHT].ExportPresentationalMathML(indent + '  ');
  return Result;
}

//----------------------------------------------------
//    Export the pair as Content MathML
//----------------------------------------------------
Pair.prototype.ExportContentMathML = function(){
  var Result = '';
  if(this.FunctionCategory == 'trig'){
    Result += '<apply>\n';
    Result += '<' + this.childrenObjects[this.LEFT].innerText.nodeValue + '/>\n';
    Result += this.childrenObjects[this.RIGHT].ExportContentMathML();
  }
  else if(this.FunctionCategory == 'calculus'){
  }
  else if(this.FunctionCategory == 'limit'){
  }
  else{
    Result = '<component_cmml>\n';
    if(this.childrenObjects){
      for(var i = 0; i < this.childrenObjects.length; i++){
        if(this.childrenObjects[i]){
          Result += this.childrenObjects[i].ExportContentMathML();
        }
      }
    }
    Result += '</component_cmml>\n';
  }
  return Result;
}

//----------------------------------------------------
//    Export the pair as LaTeX
//----------------------------------------------------
Pair.prototype.ExportLaTeX = function(){
  var Result = this.childrenObjects[this.LEFT].ExportLaTeX() + ' ';
  Result += this.childrenObjects[this.RIGHT].ExportLaTeX();
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Pair.prototype.CreateInstance = function(){
  return new Pair(null, this.ScriptLevelModifier, this.FunctionCategory);
}
