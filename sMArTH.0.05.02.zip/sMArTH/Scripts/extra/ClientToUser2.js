/*-----------------------------------------
|  Adapted from Kevin Lindsey's ViewBox.svg
| http://www.kevlindev.com/gui/utilities/viewbox/index.htm
-------------------------------------------*/

var svgns = "http://www.w3.org/2000/svg";
var svgRoot;
var viewBox;

function clinit(evt) {
    if ( window.svgDocument == null )
        svgDocument = evt.target.ownerDocument;
    svgRoot         = svgDocument.documentElement;
    viewBox         = new ViewBox(svgRoot);
}

function show_coords(parent, e) {
    var CTM    = getTransformToElement(parent);
    var iCTM   = CTM.inverse();
    var trans  = svgRoot.getCurrentTranslate();
    var scale  = svgRoot.getCurrentScale();
    var m      = viewBox.getTM();
    var p1     = svgRoot.createSVGPoint();
    var p2, p3;
    m = m.scale( 1/scale );
    m = m.translate(-trans.x, -trans.y);
    p1.x = e.clientX;
    p1.y = e.clientY;
    p2 = p1.matrixTransform(m);
    p3 = p2.matrixTransform(iCTM);
    return p3;
}

/*****
*
*   getTransformToElement
*
*****/
function getTransformToElement(node) {
    // Compute x/y positioning
    // Initialize our node's Current Transformation Matrix
    var CTM = svgDocument.documentElement.createSVGMatrix();
    // Take the element's viewbox in account
    var v = node.getAttribute('viewBox');
    var params = v.split(/\s*,\s*|\s+/);
    var vx      = parseFloat( params[0] );
    var vy      = parseFloat( params[1] );
    var vwidth  = parseFloat( params[2] );
    var vheight = parseFloat( params[3] );
    var width   = parseFloat( node.getAttribute('width'));
    var height  = parseFloat( node.getAttribute('height'));
    var scaleMatrix = svgDocument.documentElement.createSVGMatrix();
    scaleMatrix.a = width / vwidth;
    scaleMatrix.d = width / vwidth;
    CTM = scaleMatrix.multiply(CTM);
    // Add this node's x/y position
    var bx = node.getAttribute('x') ? parseFloat(node.getAttribute('x')) : 0;
    var by = node.getAttribute('y') ? parseFloat(node.getAttribute('y')) : 0;
    CTM = CTM.translate(bx, by);
    // Multiply the CTM with the element's CTM
    CTM = node.getCTM().multiply(CTM);
    // Work our way bacwards through the ancestor nodes stopping at the
    // SVG Document
    while ( ( node = node.parentNode ) != svgDocument ) {
        // Take the element's viewbox in account
        var v = node.getAttribute('viewBox');
        if(v){
          var params = v.split(/\s*,\s*|\s+/);
//          var vx      = parseFloat( params[0] );
//          var vy      = parseFloat( params[1] );
          var vwidth  = parseFloat( params[2] );
//          var vheight = parseFloat( params[3] );
          var width   = parseFloat( node.getAttribute('width'));
//          var height  = parseFloat( node.getAttribute('height'));
          if(width){
            CTM = CTM.scale(width / vwidth);
          }
        }
        // Add this node's x/y position
        var x = node.getAttribute('x') ? parseFloat(node.getAttribute('x')) : 0;
        var y = node.getAttribute('y') ? parseFloat(node.getAttribute('y')) : 0;
        CTM = CTM.translate(x, y);
        // Multiply the new CTM with what we've accumulated so far
        CTM = node.getCTM().multiply(CTM);
        // Take the element's viewbox in account
    }
    return CTM;
}
