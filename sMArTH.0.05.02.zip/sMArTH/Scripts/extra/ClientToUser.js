/*-----------------------------------------
|  Slightly inspired from Kevin Lindsey's ViewBox.svg
| http://www.kevlindev.com/gui/utilities/viewbox/index.htm
-------------------------------------------*/

var svgns = "http://www.w3.org/2000/svg";
var svgRoot;
var viewBox;

function clinit(evt) {
    if ( window.svgDocument == null )
        svgDocument = evt.target.ownerDocument;
    svgRoot         = svgDocument.documentElement;
    viewBox         = new ViewBox(svgRoot);
}

function ScreenToClient(parent, e) {
    var trans  = svgRoot.getCurrentTranslate();
    var scale  = svgRoot.getCurrentScale();
    var m      = viewBox.getTM();
    var p1     = svgRoot.createSVGPoint();
    var p2, p3;
    m = m.scale( 1/scale );
    m = m.translate(-trans.x, -trans.y);
    p1.x = e.clientX;
    p1.y = e.clientY;
    p2 = p1.matrixTransform(m);
    p3 = Transform2Parent(parent, p2);
    return p3;
}

function ClientToScreen(Node, Point){
  if(Node == null){
    return Point;
  }
  if(Node == svgDocument.getElementById('eqcontainer')){
    return Point;
  }
  Point = Point.matrixTransform(Node.getCTM());
  var v = Node.getAttribute('viewBox');
  if(v){
    var params = v.split(/\s*,\s*|\s+/);
    var vx  = parseFloat( params[0] );
    var vy  = parseFloat( params[1] );
    var vwidth  = parseFloat( params[2] );
    var width   = parseFloat( Node.getAttribute('width'));
    Point.x -= vx;
    Point.y -= vy;
    if(width && (vwidth != 0)){
      Point.x = Point.x * (width / vwidth);
      Point.y = Point.y * (width / vwidth);
    }
  }
  var x = Node.getAttribute('x') ? parseFloat(Node.getAttribute('x')) : 0;
  var y = Node.getAttribute('y') ? parseFloat(Node.getAttribute('y')) : 0;
  Point.x += x;
  Point.y += y;
  return ClientToScreen(Node.parentNode, Point);
}

function Transform2Parent(node, point){
  if(node == svgDocument){
    return point;
  }
  point = Transform2Parent(node.parentNode, point);
  var x = node.getAttribute('x') ? parseFloat(node.getAttribute('x')) : 0;
  var y = node.getAttribute('y') ? parseFloat(node.getAttribute('y')) : 0;
  point.x -= x;
  point.y -= y;
  var v = node.getAttribute('viewBox');
  if(v){
    var params = v.split(/\s*,\s*|\s+/);
    var vx  = parseFloat( params[0] );
    var vy  = parseFloat( params[1] );
    var vwidth  = parseFloat( params[2] );
    var width   = parseFloat( node.getAttribute('width'));
    point.x += vx;
    point.y += vy;
    if(width){
      point.x = point.x * (vwidth / width);
      point.y = point.y * (vwidth / width);
    }
  }
  point = point.matrixTransform(node.getCTM().inverse());
  return point;
}