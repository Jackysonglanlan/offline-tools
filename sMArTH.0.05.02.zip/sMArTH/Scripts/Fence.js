/**********************************************
Fence
Fence types:
( [ { < | || |_ |~
***********************************************/

Fence.prototype = new Component();
Fence.prototype.constructor = Fence;
//children components indexes 
Fence.prototype.FENCE = 0;

function Fence(parentObject, Type){
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject = parentObject;
 this.Height = 0;
 this.Type = Type;
 this.Locked = true;

 this.container = svgDocument.createElement('svg'); 

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //create children components 
 this.childrenObjects = new Array();
 // Make the fence path
 this.childrenObjects.push(svgDocument.createElement('path'));
 this.childrenObjects[0].setAttribute('class', 'mathSymbolLine');

 //insert the fence path in the component
 this.container.appendChild(this.childrenObjects[0]);

 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Fence.prototype.UpdateComponent = function(){
 switch(this.Type){
  case '(':
    Width = FENCE_WIDTH + LINEWIDTH/2;
    this.childrenObjects[0].setAttribute('d', this.GetLeftParenthesisPath(this.Height));
    break;
  case ')':
    Width = FENCE_WIDTH + LINEWIDTH/2;
    this.childrenObjects[0].setAttribute('d', this.GetRightParenthesisPath(this.Height));
    break;
  case '{':
    Width = FENCE_WIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetLeftBracePath(this.Height));
    break;
  case '}':
    Width = FENCE_WIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetRightBracePath(this.Height));
    break;
  case '[':
    Width = FENCE_WIDTH + LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetLeftBracketPath(this.Height));
    break;
  case ']':
    Width = FENCE_WIDTH + LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetRightBracketPath(this.Height));
    break;
  case '&langle;':
  case '<':
  case '&lt;':
    Width = FENCE_WIDTH + LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetLeftAnglePath(this.Height));
    break;
  case '&rangle;':
  case '>':
  case '&gt;':
    Width = FENCE_WIDTH + LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetRightAnglePath(this.Height));
    break;
  case '||':
  case '&DoubleVerticalBar;':
    Width = MARGIN + LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetNormPath(this.Height));
    break;
  case '|':
  case '&verbar;':
    Width = LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetAbsPath(this.Height));
    break;
  case '&lfloor;':
    Width = FENCE_WIDTH + LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetLeftFloorPath(this.Height));
    break;
  case '&rfloor;':
    Width = FENCE_WIDTH + LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetRightFloorPath(this.Height));
    break;
  case '&lceil;':
    Width = FENCE_WIDTH + LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetLeftCeilPath(this.Height));
    break;
  case '&rceil;':
    Width = FENCE_WIDTH + LINEWIDTH;
    this.childrenObjects[0].setAttribute('d', this.GetRightCeilPath(this.Height));
    break;
  default :
    alert('altceva');
 }

 this.container.setAttribute('width', Width);
 this.container.setAttribute ('height', this.Height);
}

Fence.prototype.UpdatePositions = function(){
 this.UpdateComponent();
 this.parentObject.UpdatePositions();
}
Fence.prototype.GetLeftParenthesisPath = function(height){
/*var m = "M " + (FENCE_WIDTH+LINEWIDTH/2) + " " + (LINEWIDTH/2) + " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 0 " + (- FENCE_WIDTH) + " " + (FENCE_WIDTH);
m += " V " + (height - FENCE_WIDTH - LINEWIDTH/2);
m += " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 0 " + (FENCE_WIDTH) + " " + (FENCE_WIDTH);
*/
m = "M " + (FENCE_WIDTH+LINEWIDTH/2) + " " + (LINEWIDTH/2) + " C " + (-(FENCE_WIDTH)/3+LINEWIDTH/2) + " " + (LINEWIDTH/2) + " " + (-(FENCE_WIDTH)/3+LINEWIDTH/2) + " " + (height-LINEWIDTH/2) + " " + (FENCE_WIDTH+LINEWIDTH/2) + " " + (height-LINEWIDTH/2);
return m;
}

Fence.prototype.GetRightParenthesisPath = function(height){
/*var m = "M " + 0 + " " + (LINEWIDTH/2) + " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 1 " + (FENCE_WIDTH) + " " + (FENCE_WIDTH);
m += " V " + (height - FENCE_WIDTH - LINEWIDTH/2);
m += " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 1 " + (-FENCE_WIDTH) + " " + (FENCE_WIDTH);*/

m = "M 0 " + (LINEWIDTH/2) + " C " + (4*FENCE_WIDTH/3) + " " + (LINEWIDTH/2) + " " + (4*FENCE_WIDTH/3) + " " + (height-LINEWIDTH/2) + " 0 " + (height-LINEWIDTH/2);
return m;
}

Fence.prototype.GetLeftBracePath = function(height){
/*m = "M " + (2*FENCE_WIDTH) + " " + (LINEWIDTH/2) + " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 0 " + (- FENCE_WIDTH) + " " + (FENCE_WIDTH);
m += " V " + (height/2 - FENCE_WIDTH);
m += " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 1 " + (-FENCE_WIDTH) + " " + (FENCE_WIDTH);
m += " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 1 " + (FENCE_WIDTH) + " " + (FENCE_WIDTH);
m += " V " + (height - FENCE_WIDTH - LINEWIDTH/2);
m += " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 0 " + (FENCE_WIDTH) + " " + (FENCE_WIDTH);*/
var m = "M " + (FENCE_WIDTH) + " " + (LINEWIDTH/2) + " a " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2) + " 0 0 0 " + (- FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2);
m += " V " + (height/2 - FENCE_WIDTH/2);
m += " a " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2) + " 0 0 1 " + (-FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2);
m += " a " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2) + " 0 0 1 " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2);
m += " V " + (height - FENCE_WIDTH/2 - LINEWIDTH/2);
m += " a " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2) + " 0 0 0 " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2);
return m;
}

Fence.prototype.GetRightBracePath = function(height){
/*m = "M " + 0 + " " + (LINEWIDTH/2) + " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 1 " + ( FENCE_WIDTH) + " " + (FENCE_WIDTH);
m += " V " + (height/2 - FENCE_WIDTH);
m += " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 0 " + (FENCE_WIDTH) + " " + (FENCE_WIDTH);
m += " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 0 " + (-FENCE_WIDTH) + " " + (FENCE_WIDTH);
m += " V " + (height - FENCE_WIDTH - LINEWIDTH/2);
m += " a " + FENCE_WIDTH + " " + FENCE_WIDTH + " 0 0 1 " + (-FENCE_WIDTH) + " " + (FENCE_WIDTH);*/
var m = "M " + 0 + " " + (LINEWIDTH/2) + " a " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2) + " 0 0 1 " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2);
m += " V " + (height/2 - (FENCE_WIDTH/2));
m += " a " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2) + " 0 0 0 " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2);
m += " a " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2) + " 0 0 0 " + (-FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2);
m += " V " + (height - FENCE_WIDTH/2 - LINEWIDTH/2);
m += " a " + (FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2) + " 0 0 1 " + (-FENCE_WIDTH/2) + " " + (FENCE_WIDTH/2);
return m;
}

Fence.prototype.GetLeftBracketPath = function(height){
var m = "M " + (FENCE_WIDTH+LINEWIDTH/2) + " 0 L " + (LINEWIDTH/2) + " 0 " + (LINEWIDTH/2) + " " + height + " " + (FENCE_WIDTH+LINEWIDTH/2) + " " + height;
return m;
}

Fence.prototype.GetRightBracketPath = function(height){
var m = "M " + (LINEWIDTH/2) + " 0 L " + (FENCE_WIDTH+LINEWIDTH/2) + " 0 " + (FENCE_WIDTH+LINEWIDTH/2) + " " + height + " " + (LINEWIDTH/2) + " " + height;
return m;
}

Fence.prototype.GetLeftAnglePath = function(height){
var m = "M " + (FENCE_WIDTH+LINEWIDTH/2) + " 0 L " + (LINEWIDTH/2) + " " + (height/2) + " " + (FENCE_WIDTH+LINEWIDTH/2) + " " + height;
return m;
}

Fence.prototype.GetRightAnglePath = function(height){
var m = "M " + (LINEWIDTH/2) + " 0 L " + (FENCE_WIDTH+LINEWIDTH/2) + " " + (height/2) + " " + (LINEWIDTH/2) + " " + height;
return m;
}

Fence.prototype.GetLeftCeilPath = function(height){
var m = "M " + (FENCE_WIDTH+LINEWIDTH/2) + " 0 L " + (LINEWIDTH/2) + " 0 " + (LINEWIDTH/2) + " " + height;
return m;
}

Fence.prototype.GetRightCeilPath = function(height){
var m = "M " + (LINEWIDTH/2) + " 0 L " + (FENCE_WIDTH+LINEWIDTH/2) + " 0 " + (FENCE_WIDTH+LINEWIDTH/2) + " " + height;
return m;
}

Fence.prototype.GetLeftFloorPath = function(height){
var m = "M " + (LINEWIDTH/2) + " 0 L " + (LINEWIDTH/2) + " " + height + " " + (FENCE_WIDTH+LINEWIDTH/2) + " " + height;
return m;
}

Fence.prototype.GetRightFloorPath = function(height){
var m = "M " + (FENCE_WIDTH+LINEWIDTH/2) + " 0 L " + (FENCE_WIDTH+LINEWIDTH/2) + " " + height + " " + (LINEWIDTH/2) + " " + height;
return m;
}

Fence.prototype.GetAbsPath = function(height){
var m = "M " + (LINEWIDTH/2) + " 0 L " + (LINEWIDTH/2) + " " + this.Height;
return m;
}

Fence.prototype.GetNormPath = function(height){
var m = "M " + (LINEWIDTH/2) + " 0 L " + (LINEWIDTH/2) + " " + height + " M " + (MARGIN+LINEWIDTH/2) + " 0 L " + (MARGIN+LINEWIDTH/2) + " " + height;
return m;
}

//----------------------------------------------------
//    Export fence as SVG image
//----------------------------------------------------
Fence.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += indent + '  ' + printNode(this.childrenObjects[0]) + '\n';
  Result += indent + '</svg>\n';
  return Result;
}