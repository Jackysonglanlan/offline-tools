/**********************************************
Fenced
Supported fence types:
( [ { < | || |_ |~
***********************************************/

Fenced.prototype = new Component();
Fenced.prototype.constructor = Fenced;
//children components indexes 
Fenced.prototype.ARGUMENT = 0;

function Fenced(parentObject, scriptLevelModifier, open, close, separators){
 this.Midline = 0;
 this.Locked = false;
 this.childrenObjects = new Array();
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject = parentObject;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.openType = (open ? open : '(');
 this.closeType = (close ? close : ')');
 this.separators = (separators ? separators : ',');

 this.CreateTSpans('mfenced open="' + this.openType + '" close="' + this.closeType + '"', 'mfenced');

 this.TeX_Open = MakeTSpan(true);
 this.TeX_Open.appendChild(document.createTextNode('\\left' + GetLaTeX(this.openType) + ' '));
 this.TeX_Preview.appendChild(this.TeX_Open);
 this.TeX_Preview.appendChild(this.TeX_Content);
 this.TeX_Close = MakeTSpan(true);
 this.TeX_Close.appendChild(document.createTextNode('\\right' + GetLaTeX(this.closeType) + ' '));
 this.TeX_Preview.appendChild(this.TeX_Close);

 this.container = svgDocument.createElement('svg'); 

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 // Make the fences
 this.open = new Fence(this, this.openType, 0);
 this.container.appendChild(this.open.GetContainer());
 this.close = new Fence(this, this.closeType, 0);
 this.container.appendChild(this.close.GetContainer());

 //create children components
 this.appendChild(new Row(this), this.ARGUMENT, true);
 this.AppendTSpanFor(this.childrenObjects[this.ARGUMENT]);
 this.childrenObjects[this.ARGUMENT].appendChild(new EditableLabel(null), 0, true);

 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Fenced.prototype.UpdatePositions = function(){
 if(this.childrenObjects.length < 1) return;

 var argument_size = this.childrenObjects[this.ARGUMENT].GetSize();
 var argumentMidline = this.childrenObjects[this.ARGUMENT].GetMidlineY();

 var Height = 2* Maximum(argumentMidline, argument_size.y - argumentMidline);
 this.open.Height = Height;
 this.close.Height = Height;
 this.open.UpdateComponent();
 this.close.UpdateComponent();
 var LeftFenceWidth = parseFloat(this.open.container.getAttribute('width'));
 var RightFenceWidth = parseFloat(this.close.container.getAttribute('width'));

 this.open.container.setAttribute('x', 0);
 this.close.container.setAttribute('x', 2*MARGIN + argument_size.x + LeftFenceWidth);
 var Width = 2*MARGIN + argument_size.x + RightFenceWidth + LeftFenceWidth;

 this.Midline = Height / 2;

 this.container.setAttribute ('width', this.Scale(Width));
 this.container.setAttribute ('height', this.Scale(Height));
 this.container.setAttribute('viewBox', '0 0 ' + Width + ' ' + Height);

 this.childrenObjects[this.ARGUMENT].container.setAttribute('x', MARGIN + LeftFenceWidth);
 this.childrenObjects[this.ARGUMENT].container.setAttribute('y', Height/2 - argumentMidline);
 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the expresion as Presentational MathML ( <mfenced> )
//----------------------------------------------------
Fenced.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent + '<mfenced open="' + this.openType + '" close="' + this.closeType + '">\n';
  for(var i = 0; i < this.childrenObjects.length; i++){
    Result += this.childrenObjects[i].ExportPresentationalMathML(indent + '  ');
  }
  Result += indent + '</mfenced>\n';
  return Result;
}

//----------------------------------------------------
//    Export the expression as LaTeX
//----------------------------------------------------
Fenced.prototype.ExportLaTeX = function(){
  var Result = '\\left' + GetLaTeX(this.openType) + ' ';
  Result += this.childrenObjects[this.ARGUMENT].ExportLaTeX();
  Result += ' \\right' + GetLaTeX(this.closeType);
  return Result;
}

//----------------------------------------------------
//    Export fenced component as SVG image
//----------------------------------------------------
Fenced.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += this.open.ExportSVGNode(indent + '  ');
  Result += this.childrenObjects[0].ExportSVGNode(indent + '  ');
  Result += this.close.ExportSVGNode(indent + '  ');
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Fenced.prototype.CreateInstance = function(){
  return new Fenced(null, this.ScriptLevelModifier, this.openType, this.closeType, this.separators);
}
