/**********************************************
Fraction
***********************************************/

Fraction.prototype = new Component();
Fraction.prototype.constructor = Fraction;
//children components indexes 
Fraction.prototype.NUMERATOR = 0;
Fraction.prototype.DENOMINATOR = 1;

function Fraction(parentObject, scriptLevelModifier, bevelled){
 this.Midline = 0;
 this.Locked = false;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.Bevelled = (bevelled ? bevelled : false);

 // When created, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 // The object should remember its parent
 this.parentObject = parentObject;

 this.CreateTSpans('mfrac' + (this.Bevelled ? ' bevelled="true"' : ''), 'mfrac');

 var TeXTspan = MakeTSpan(true);
 TeXTspan.appendChild(document.createTextNode('\\frac \n'));
 this.TeX_Preview.appendChild(TeXTspan);
 this.TeX_Preview.appendChild(this.TeX_Content);

 this.container = svgDocument.createElement('svg');

 // Create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 // Set the component status to idle
 this.frame.setAttribute('class', 'idle');

 // Insert the frame in the component
 this.container.appendChild(this.frame);

 this.fractionLine = svgDocument.createElement('line');
 this.fractionLine.setAttribute('class', 'fractionline');

 //insert the fraction line in the component
 this.container.appendChild(this.fractionLine);

 //create children components 
 this.childrenObjects = new Array();
 this.appendChild(new Row(this), this.NUMERATOR, true);
 this.InsertTSpanFor(this.childrenObjects[this.NUMERATOR]);
 this.childrenObjects[this.NUMERATOR].appendChild(new EditableLabel(null), 0, true);

 this.appendChild(new Row(this), this.DENOMINATOR, true);
 this.InsertTSpanFor(this.childrenObjects[this.DENOMINATOR]);
 this.childrenObjects[this.DENOMINATOR].appendChild(new EditableLabel(null), 0, true);

 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Fraction.prototype.UpdatePositions = function(){
 if(this.childrenObjects.length < 2) return;
 var denominator_size = this.childrenObjects[this.DENOMINATOR].GetSize();
 var numerator_size   = this.childrenObjects[this.NUMERATOR].GetSize();
 if (this.Bevelled == true){
   var width = numerator_size.x + denominator_size.x + BEVELLED_FRACTION_DX;
   width += 2*MARGIN;

   var numerator_top = this.childrenObjects[this.NUMERATOR].GetMidlineY();
   var denominator_top = this.childrenObjects[this.DENOMINATOR].GetMidlineY();
   var numerator_y = (numerator_top > (denominator_top - BEVELLED_FRACTION_DY) ) ? 0 : (denominator_top - BEVELLED_FRACTION_DY - numerator_top);
   var denominator_y = numerator_y + numerator_top + BEVELLED_FRACTION_DY - denominator_top;

   var height = ((denominator_y + denominator_size.y) > (numerator_size.y + numerator_y)) ? 
    (denominator_y + denominator_size.y) : (numerator_size.y + numerator_y);
   //height += BEVELLED_FRACTION_DY;

   this.container.setAttribute('viewBox', '0 0 ' + width + ' ' + height);
   this.container.setAttribute ('width', this.Scale(width));
   this.container.setAttribute ('height', this.Scale(height));

   this.fractionLine.setAttribute('x1', MARGIN + numerator_size.x);
   this.fractionLine.setAttribute('x2', MARGIN + numerator_size.x + BEVELLED_FRACTION_DX);
   this.fractionLine.setAttribute('y1', height);
   this.fractionLine.setAttribute('y2', 0);

   this.childrenObjects[this.NUMERATOR].container.setAttribute('x', 0);
   this.childrenObjects[this.NUMERATOR].container.setAttribute('y', numerator_y);
   this.childrenObjects[this.DENOMINATOR].container.setAttribute('x', 2*MARGIN + numerator_size.x + BEVELLED_FRACTION_DX);
   this.childrenObjects[this.DENOMINATOR].container.setAttribute('y', denominator_y);

   this.Midline = numerator_y + numerator_top + BEVELLED_FRACTION_DY / 2;
 }
 else {
   var width = (denominator_size.x > numerator_size.x) ? denominator_size.x : numerator_size.x;
   width += 2*MARGIN;
   var height = denominator_size.y + numerator_size.y + 2*MARGIN;

   this.container.setAttribute('viewBox', '0 0 ' + width + ' ' + height);
   this.container.setAttribute ('width', this.Scale(width));
   this.container.setAttribute ('height', this.Scale(height));

   this.fractionLine.setAttribute('x1', MARGIN);
   this.fractionLine.setAttribute('x2', width - MARGIN);
   this.fractionLine.setAttribute('y1', numerator_size.y + MARGIN);
   this.fractionLine.setAttribute('y2', numerator_size.y + MARGIN);
  
   this.childrenObjects[this.NUMERATOR].container.setAttribute('x', (width - numerator_size.x) / 2);
   this.childrenObjects[this.NUMERATOR].container.setAttribute('y', 0);
   this.childrenObjects[this.DENOMINATOR].container.setAttribute('x', (width - denominator_size.x) / 2);
   this.childrenObjects[this.DENOMINATOR].container.setAttribute('y', height - denominator_size.y);
   
   this.Midline = numerator_size.y + MARGIN;
 }
 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the Fraction as Presentational MathML (<mfrac>)
//----------------------------------------------------
Fraction.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent + '<mfrac';
  if (this.Bevelled == true){
    Result += ' bevelled="true"';
  }
  Result += '>\n';
  Result += this.childrenObjects[this.NUMERATOR].ExportPresentationalMathML(indent + '  ');
  Result += this.childrenObjects[this.DENOMINATOR].ExportPresentationalMathML(indent + '  ');
  return Result + indent + '</mfrac>\n';
}

//----------------------------------------------------
//    Export the expression as LaTeX
//----------------------------------------------------
Fraction.prototype.ExportLaTeX = function(){
  var Result = '\\frac ';
  Result += this.childrenObjects[this.NUMERATOR].ExportLaTeX() + ' ';
  Result += this.childrenObjects[this.DENOMINATOR].ExportLaTeX();
  return Result;
}

//----------------------------------------------------
//    Export fraction as SVG image
//----------------------------------------------------
Fraction.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += indent + '  ' + printNode(this.fractionLine) + '\n';
  Result += this.childrenObjects[this.NUMERATOR].ExportSVGNode(indent + '  ');
  Result += this.childrenObjects[this.DENOMINATOR].ExportSVGNode(indent + '  ');
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Fraction.prototype.CreateInstance = function(){
  return new Fraction(null, this.ScriptLevelModifier, this.Bevelled);
}