/**********************************************
Matrix
***********************************************/

Matrix.prototype = new Component();
Matrix.prototype.constructor = Matrix;

function Matrix(parentObject, scriptLevelModifier, rows, cols){
 this.Locked = false;
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject     = parentObject;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.Rows = rows;
 this.Cols = cols

 this.CreateTSpans('mtable', 'mtable');
 
 this.TeX_OpenBrace = MakeTSpan();
 var beginArray = ' \\begin{array}{';
 for(var i = 0; i < this.Cols; i++){
   beginArray += 'c';
 }
 beginArray += '}\n';
 this.TeX_OpenBrace.appendChild(document.createTextNode(beginArray));
 this.TeX_CloseBrace = MakeTSpan();
 this.TeX_CloseBrace.appendChild(document.createTextNode('\\end{array}\n'));
 this.TeX_Preview.appendChild(this.TeX_OpenBrace);
 this.TeX_Preview.appendChild(this.TeX_Content);
 this.TeX_Preview.appendChild(this.TeX_CloseBrace);

 this.container = svgDocument.createElement('svg');

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //create children components 
 //insert each cell
 //transform the 2D matrix into an 1D vector,
 //   for easier navigation
 //Access: M[i][j] -> M[i*this.Cols + j];
 // Also generate tspans for preview
 this.childrenObjects = new Array();
 for (var i = 0; i < this.Rows; i++){
  var rowtspan = MakeTSpan();
  var rowtspanStartTag = MakeTSpan();
  rowtspanStartTag.appendChild(svgDocument.createTextNode('<mtr>'));
  rowtspan.appendChild(rowtspanStartTag);
  var rowtspanContentTag = MakeTSpan();
  rowtspan.appendChild(rowtspanContentTag);
  this.MMLP_Content.appendChild(rowtspan);
  if(i > 0){
    var TeXRowTSpan = MakeTSpan(true);
    TeXRowTSpan.appendChild(svgDocument.createTextNode(' \\\\'));
    this.TeX_Content.appendChild(TeXRowTSpan);
  }
  var TeXNewRow = MakeTSpan();
  TeXNewRow.appendChild(svgDocument.createTextNode(' '));
  this.TeX_Content.appendChild(TeXNewRow);

  for (var j = 0; j < this.Cols; j++){
    this.appendChild(new Row(this), (i*this.Cols + j), true);
    this.childrenObjects[this.childrenObjects.length - 1].appendChild(new EditableLabel(null));
    var tdtspan = MakeTSpan();
    var tdtspanStartTag = MakeTSpan();
    tdtspanStartTag.appendChild(svgDocument.createTextNode('<mtd>'));
    tdtspan.appendChild(tdtspanStartTag);
    var tdtspanContentTag = MakeTSpan();
    tdtspan.appendChild(tdtspanContentTag);
    rowtspanContentTag.appendChild(tdtspan);
    tdtspanContentTag.appendChild(this.childrenObjects[this.childrenObjects.length - 1].MMLP_Preview);
    var tdtspanEndTag = MakeTSpan();
    tdtspanEndTag.appendChild(svgDocument.createTextNode('</mtd>'));
    tdtspan.appendChild(tdtspanEndTag);
    if(j > 0){
      var TeXCellDelimTSpan = MakeTSpan(true);
      TeXCellDelimTSpan.appendChild(svgDocument.createTextNode(' & '));
      this.TeX_Content.appendChild(TeXCellDelimTSpan);
    }
    this.TeX_Content.appendChild(this.childrenObjects[this.childrenObjects.length - 1].TeX_Preview);
  }
  var rowtspanEndTag = MakeTSpan();
  rowtspanEndTag.appendChild(svgDocument.createTextNode('</mtr>'));
  rowtspan.appendChild(rowtspanEndTag);
 }

 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');

 //arrange the children in the container 
 this.UpdatePositions();

 //insert the component into the parent dom tree
 if(parentObject != null){
  this.parentObject.appendChild(this);
 }
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Matrix.prototype.UpdatePositions = function(){
 if(this.childrenObjects.length < this.Cols * this.Rows) return;
 // Keep 2 arrays of max sizes for each row / col
 var row_midlines = new Array(this.Rows); //midline position in each row
 var cell_tops = new Array(this.Cols * this.Rows); //above midline
 var row_size = new Array(this.Rows); //row height
 var col_size = new Array(this.Cols); //col width
 var size;
 //obtain the size of each child element
 var Height = 0;
 for(var i = 0; i < this.Cols; i++){
  col_size[i] = 0;
 }
 for (var i = 0; i < this.Rows; i++){
  size = this.childrenObjects[i * this.Cols].GetSize();
  row_size[i] = 0;
  col_size[0] = Maximum(col_size[0], size.x);
  this.Midline = this.childrenObjects[i * this.Cols].GetMidlineY();
  row_midlines[i] = this.Midline;
  cell_tops[i * this.Cols] = this.Midline;

  for (var j = 1; j < this.Cols; j++){
    size = this.childrenObjects[i * this.Cols + j].GetSize();
    this.Midline = this.childrenObjects[i * this.Cols + j].GetMidlineY();
    col_size[j] = Maximum(col_size[j], size.x);
    row_midlines[i] = Maximum(row_midlines[i], this.Midline);
    cell_tops[i * this.Cols + j] = this.Midline;
  }
  for (var j = 0; j < this.Cols; j++){
    row_size[i] = Maximum(row_size[i], this.childrenObjects[i * this.Cols + j].GetSize().y - cell_tops[i * this.Cols + j] + row_midlines[i]);
  }

  Height += parseFloat(row_size[i]);
 }

 var Width = 0;
 for (var j = 0; j < this.Cols; j++){
  Width += col_size[j];
 }

 //insert margins 
 Height += (this.Rows - 1) * CELLSPACING;
 Width += (this.Cols - 1) * CELLSPACING + 2 * MARGIN;

 this.Midline = Height / 2;
 //resize and organize the container
 this.container.setAttribute ('width', this.Scale(Width));
 this.container.setAttribute ('height', this.Scale(Height));
 this.container.setAttribute('viewBox', '0 0 ' + Width + ' ' + Height);

  var row_offset = 0;
  for (var i = 0; i < this.Rows; i++){
    var col_offset = MARGIN;
    for (var j = 0; j < this.Cols; j++){
      cellX = col_offset + (col_size[j] - this.childrenObjects[i * this.Cols + j].GetSize().x) / 2;
      col_offset += col_size[j] + CELLSPACING;
      cellY = row_offset + row_midlines[i] - cell_tops[i * this.Cols + j];

      this.childrenObjects[i * this.Cols + j].container.setAttribute('x', cellX);
      this.childrenObjects[i * this.Cols + j].container.setAttribute('y', cellY);      
    }
    row_offset += row_size[i] + CELLSPACING;
  }

 //update parent
 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the matrix as Presentational MathML ( <mtable> )
//----------------------------------------------------
Matrix.prototype.ExportPresentationalMathML = function(indent){
  if(this.childrenObjects.length == 1){
    return this.childrenObjects[0].ExportPresentationalMathML(indent);
  }

  var Result = indent + '<mtable>\n';
  for (var i = 0; i < this.Rows; i++){
    Result += indent + '  ' + '<mtr>\n';
     for (var j = 0; j < this.Cols; j++){
        Result += indent + '    ' + '<mtd>\n';
        Result += this.childrenObjects[i * this.Cols + j].ExportPresentationalMathML(indent + '      ');
        Result += indent + '    ' + '</mtd>\n';
      }
    Result += indent + '  ' + '</mtr>\n';
  }
  Result += indent + '</mtable>\n';
  return Result;
}

//----------------------------------------------------
//    Export the Matrix as LaTeX
//----------------------------------------------------
Matrix.prototype.ExportLaTeX = function(){
  var Result = '\n\\begin{array}{';
  for(var i = 0; i < this.Cols; i++){
    Result += 'c';
  }
  Result += '}\n';
  for(var i = 0; i < this.Rows; i++){
    for(var j = 0; j < this.Cols; j++){
      Result += this.childrenObjects[i*this.Cols + j].ExportLaTeX();
      if(j < this.Cols - 1){
        Result += ' & ';
      }
      else if(i < this.Rows - 1){
        Result += ' \\\\\n';
      }
      else{
        Result += '\n';
      }
    }
  }
  Result += '\\end{array}';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Matrix.prototype.CreateInstance = function(){
  return new Matrix(null, this.ScriptLevelModifier, this.Rows, this.Cols);
}

//----------------------------------------------------
//    Delete a child component
//    ComponentBase OVERRIDE
//----------------------------------------------------
Matrix.prototype.DeleteChild = function(child){
  var i;
  for(i = 0; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      var row = new Row();
      row.Insert(new EditableLabel(null));
      this.ReplaceChildWith(this.childrenObjects[i], row);
      row.parentObject = this;

      row.TeX_OpenBrace.setAttribute('display', 'inline');
      row.TeX_CloseBrace.setAttribute('display', 'inline');
      row.childrenObjects[0].UpdatePositions();
      eq.setFocusTo(row.childrenObjects[0]);
      eq.Modified();
      return;
    }   
  }
}

//----------------------------------------------------
//     Replace one of the children components with
//    a new child component
//    Return true if succeded (the replaced component
//    exists, false otherwise
//----------------------------------------------------
Matrix.prototype.ReplaceChildWith = function(replaced, newChild, SkipUndo){
 for (var i = 0; i < this.Rows; i++){
  for (var j = 0; j < this.Cols; j++){
    if(this.childrenObjects[i * this.Cols + j] == replaced){
      if (!SkipUndo){
        eq.EqModified(this.hWnd, replaced, UndoStep.prototype.REPLACEMATRIXCELL, i * this.Cols + j, newChild);
      }
      this.container.replaceChild(newChild.container, replaced.container);
      this.childrenObjects[i * this.Cols + j] = newChild;
      newChild.parentObject = this;
      this.MMLP_Content.childNodes.item(i).childNodes.item(1).childNodes.item(j).childNodes.item(1).replaceChild(newChild.MMLP_Preview, replaced.MMLP_Preview);
      this.TeX_Content.replaceChild(newChild.TeX_Preview, replaced.TeX_Preview);
  
      eq.Modified();
      return true;
     }
   }
 }
 return false;
}
