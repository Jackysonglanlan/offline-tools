/**********************************************
Overscript and Underscript support
***********************************************/

OverUnder.prototype = new Component();
OverUnder.prototype.constructor = OverUnder;
//children components indexes 
OverUnder.prototype.BASE = 0;
OverUnder.prototype.OVER = 1;
OverUnder.prototype.UNDER = 2;

function OverUnder(parentObject, scriptLevelModifier, Type){
 this.Midline = 0;
 this.Locked = false;
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject     = parentObject;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.Type = Type;

 this.container = svgDocument.createElement('svg');

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //create children components
 this.childrenObjects = new Array();

 // Type encodes the position of the over/under scripts:
 // 1. The least signifficant bit specifies if a overscript exists;
 // 2. The next bit specifies if a underscript exists.

 if((this.Type >> 1) % 2 == 1){
  this.childrenObjects[this.UNDER] = new Row(this, 1);
  this.childrenObjects[this.UNDER].appendChild(new EditableLabel(null), 0, true);
  this.container.appendChild(this.childrenObjects[this.UNDER].GetContainer());
 }
 if(this.Type % 2 == 1){
  this.childrenObjects[this.OVER] = new Row(this, 1);
  this.childrenObjects[this.OVER].appendChild(new EditableLabel(null), 0, true);
  this.container.appendChild(this.childrenObjects[this.OVER].GetContainer());
 }

  this.childrenObjects[this.BASE] = new Row(this, 0);
  this.childrenObjects[this.BASE].appendChild(new EditableLabel(null), 0, true);
  this.container.appendChild(this.childrenObjects[this.BASE].GetContainer());
  
  this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');

  if(this.Type == 1){
    // Over
    this.CreateTSpans('mover', 'mover');
    this.MMLP_Content.appendChild(this.childrenObjects[this.BASE].MMLP_Preview);
    this.MMLP_Content.appendChild(this.childrenObjects[this.OVER].MMLP_Preview);

    this.TeX_Content.appendChild(this.childrenObjects[this.BASE].TeX_Preview);
    TeXTspan = MakeTSpan(true);
    TeXTspan.appendChild(document.createTextNode('^'));
    this.TeX_Content.appendChild(TeXTspan);
    this.TeX_Content.appendChild(this.childrenObjects[this.OVER].TeX_Preview);
  }
  else if(this.Type == 2){
    // Under
    this.CreateTSpans('munder', 'munder');
    this.MMLP_Content.appendChild(this.childrenObjects[this.BASE].MMLP_Preview);
    this.MMLP_Content.appendChild(this.childrenObjects[this.UNDER].MMLP_Preview);

    this.TeX_Content.appendChild(this.childrenObjects[this.BASE].TeX_Preview);
    TeXTspan = MakeTSpan(true);
    TeXTspan.appendChild(document.createTextNode('_'));
    this.TeX_Content.appendChild(TeXTspan);
    this.TeX_Content.appendChild(this.childrenObjects[this.UNDER].TeX_Preview);
  }
  else if(this.Type == 3){
    // UnderOver
    this.CreateTSpans('munderover', 'munderover');
    this.MMLP_Content.appendChild(this.childrenObjects[this.BASE].MMLP_Preview);
    this.MMLP_Content.appendChild(this.childrenObjects[this.UNDER].MMLP_Preview);
    this.MMLP_Content.appendChild(this.childrenObjects[this.OVER].MMLP_Preview);

    this.TeX_Content.appendChild(this.childrenObjects[this.BASE].TeX_Preview);
    TeXTspan = MakeTSpan(true);
    TeXTspan.appendChild(document.createTextNode('_'));
    this.TeX_Content.appendChild(TeXTspan);
    this.TeX_Content.appendChild(this.childrenObjects[this.UNDER].TeX_Preview);
    TeXTspan = MakeTSpan(true);
    TeXTspan.appendChild(document.createTextNode('^'));
    this.TeX_Content.appendChild(TeXTspan);
    this.TeX_Content.appendChild(this.childrenObjects[this.OVER].TeX_Preview);
  }
  this.TeX_Preview.appendChild(this.TeX_Content);
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
OverUnder.prototype.UpdatePositions = function(){
 if(! this.childrenObjects[this.BASE]) return;
 //obtain the size of each child element
 var base_size = this.childrenObjects[this.BASE].GetSize();

 var over_size = (this.Type % 2) ? this.childrenObjects[this.OVER].GetSize() : svgDocument.documentElement.createSVGPoint();


 var under_size = ((this.Type >> 1) % 2) ? this.childrenObjects[this.UNDER].GetSize() : svgDocument.documentElement.createSVGPoint();

 var Width = Maximum(base_size.x, Maximum(over_size.x, under_size.x));
 var Height = base_size.y + over_size.y + under_size.y;

 //obtain the position of each child element
 var baseX = (Width -  base_size.x)/2;
 var baseY = over_size.y;

 var overX = (Width - over_size.x)/2;
 var overY = 0;
 var underX = (Width - under_size.x)/2;
 var underY = baseY + base_size.y;

 this.Midline = baseY + this.childrenObjects[this.BASE].GetMidlineY();

 //resize and organize the container
 this.container.setAttribute ('width', this.Scale(Width));
 this.container.setAttribute ('height', this.Scale(Height));
 this.container.setAttribute('viewBox', '0 0 ' + Width + ' ' + Height);

 if(this.Type % 2){
  this.childrenObjects[this.OVER].container.setAttribute('x', overX);
  this.childrenObjects[this.OVER].container.setAttribute('y', overY);
 }
 if((this.Type >> 1) % 2){
  this.childrenObjects[this.UNDER].container.setAttribute('x', underX);
  this.childrenObjects[this.UNDER].container.setAttribute('y', underY);
 }

 this.childrenObjects[this.BASE].container.setAttribute('x', baseX);
 this.childrenObjects[this.BASE].container.setAttribute('y', baseY);

 //update parent
 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the OverUnder as Presentational MathML
//----------------------------------------------------
OverUnder.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent;
  if(this.Type == 1){
    // Over
    Result += '<mover>\n';
    Result += this.childrenObjects[this.BASE].ExportPresentationalMathML(indent + '  ');
    Result += this.childrenObjects[this.OVER].ExportPresentationalMathML(indent + '  ');
    Result += indent + '</mover>\n';
  }
  else if(this.Type == 2){
    // Under
    Result += '<munder>\n';
    Result += this.childrenObjects[this.BASE].ExportPresentationalMathML(indent + '  ');
    Result += this.childrenObjects[this.UNDER].ExportPresentationalMathML(indent + '  ');
    Result += indent + '</munder>\n';
  }
  else if(this.Type == 3){
    // Over + Under
    Result += '<munderover>\n';
    Result += this.childrenObjects[this.BASE].ExportPresentationalMathML(indent + '  ');
    Result += this.childrenObjects[this.UNDER].ExportPresentationalMathML(indent + '  ');
    Result += this.childrenObjects[this.OVER].ExportPresentationalMathML(indent + '  ');
    Result += indent + '</munderover>\n';
  }
  return Result;
}

//----------------------------------------------------
//    Export the OverUnder as LaTeX
//----------------------------------------------------
OverUnder.prototype.ExportLaTeX = function(){
  var Result = this.childrenObjects[this.BASE].ExportLaTeX();
  if(this.childrenObjects[this.UNDER]){
    Result += '_' + this.childrenObjects[this.UNDER].ExportLaTeX();
  }
  if(this.childrenObjects[this.OVER]){
    Result += '^' + this.childrenObjects[this.OVER].ExportLaTeX();
  }
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
OverUnder.prototype.CreateInstance = function(){
  return new OverUnder(null, this.ScriptLevelModifier, this.Type);
}