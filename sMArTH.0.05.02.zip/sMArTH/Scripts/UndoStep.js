/***********************************************
 UndoStep
 
 - the container for the equation components
 - manages component focus 
************************************************/

UndoStep.prototype.INSERTCHAR = 1;
UndoStep.prototype.DELETECHAR = 2;
UndoStep.prototype.MODIFYTEXT = 3;
UndoStep.prototype.INSERTCHILD = 4;
UndoStep.prototype.DELETECHILD = 5;
UndoStep.prototype.REPLACECHILD = 6;
UndoStep.prototype.REPLACEMATRIXCELL = 7;
UndoStep.prototype.INSERTROOTCHILD = 8;
UndoStep.prototype.DELETEROOTCHILD = 9;

function UndoStep(ParentHWnd, Argument, Operation, Location, SecondArgument){
  this.ParentHWnd = ParentHWnd;
  this.Argument = Argument;
  this.Operation = Operation;
  this.Location = Location;
  this.SecondArgument = SecondArgument;
  this.SeqIndex = eq.NextUndoStepIndex();
}

UndoStep.prototype.undo = function(){
  var Parent = eq.GetElementByHwnd(this.ParentHWnd);
  switch(this.Operation){
    case this.INSERTCHAR:
      Parent.CursorPosition = this.Location;
      Parent.DeleteCharAt(this.Location);
      Parent.TextChanged();
      eq.setFocusTo(Parent);
      break;
    case this.DELETECHAR:
      Parent.CursorPosition = this.Location;
      Parent.InsertCharAt(this.Argument, this.Location);
      Parent.TextChanged();
      eq.setFocusTo(Parent);
      break;
    case this.MODIFYTEXT:
      Parent.CursorPosition = this.Location;
      Parent.innerText.nodeValue = this.Argument;
      Parent.TextChanged();
      eq.setFocusTo(Parent);
      break;
    case this.INSERTCHILD:
      Parent.MMLP_Content.removeChild(this.Argument.MMLP_Preview);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview);
      Parent.container.removeChild(this.Argument.GetContainer());
      Parent.childrenObjects.splice(this.Location, 1);
      Parent.CursorPosition = this.Location;
      Parent.UpdatePositions();
      eq.Modified();
      eq.setFocusTo(Parent);
      break;
    case this.DELETECHILD:
      Parent.CursorPosition = this.Location;
      Parent.childrenObjects.splice(Parent.CursorPosition, 0, this.Argument);
      Parent.container.appendChild(this.Argument.GetContainer());
      this.Argument.parentObject = Parent;
      Parent.CursorPosition++;
      Parent.UpdatePositions();
      Parent.InsertTSpanFor(this.Argument);
      eq.Modified();
      Parent.UpdateCursor();
      eq.setFocusTo(Parent);
      break;
    case this.REPLACEMATRIXCELL:
      Parent.container.replaceChild(this.Argument.container, this.SecondArgument.container);
      Parent.childrenObjects[this.Location] = this.Argument;
      this.Argument.parentObject = Parent;
      var i = Math.floor(this.Location / Parent.Cols);
      var j = this.Location % Parent.Cols;
      Parent.MMLP_Content.childNodes.item(i).childNodes.item(1).childNodes.item(j).childNodes.item(1).replaceChild(this.Argument.MMLP_Preview, this.SecondArgument.MMLP_Preview);
      Parent.TeX_Content.replaceChild(this.Argument.TeX_Preview, this.SecondArgument.TeX_Preview);
      Parent.UpdatePositions();
      eq.Modified();
      eq.setFocusTo(Parent);
      break;
    case this.DELETEROOTCHILD:
      Parent.CursorPosition = this.Location;
      Parent.childrenObjects.splice(Parent.CursorPosition, 0, this.Argument);
      Parent.container.appendChild(this.Argument.GetContainer());
      this.Argument.parentObject = Parent;
      Parent.CursorPosition++;
      Parent.UpdatePositions();
      Parent.InsertTSpanFor(this.Argument);
      eq.Modified();
      Parent.UpdateCursor();
      eq.setFocusTo(Parent);
      break;
    case this.INSERTROOTCHILD:
      Parent.MMLP_Content.removeChild(this.Argument.MMLP_Preview);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview.previousSibling);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview.previousSibling);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview.nextSibling);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview);
      Parent.container.removeChild(this.Argument.GetContainer());
      Parent.childrenObjects.splice(this.Location, 1);
      Parent.CursorPosition = this.Location;
      Parent.UpdatePositions();
      eq.Modified();
      eq.setFocusTo(Parent);
      break;
  }
}

UndoStep.prototype.redo = function(){
  var Parent = eq.GetElementByHwnd(this.ParentHWnd);
  switch(this.Operation){
    case this.INSERTCHAR:
      Parent.CursorPosition = this.Location+1;
      Parent.InsertCharAt(this.Argument, this.Location);
      Parent.TextChanged();
      eq.setFocusTo(Parent);
      break;
    case this.DELETECHAR:
      Parent.CursorPosition = this.Location;
      Parent.DeleteCharAt(this.Location);
      Parent.TextChanged();
      eq.setFocusTo(Parent);
      break;
    case this.MODIFYTEXT:
      Parent.CursorPosition = this.Location;
      Parent.innerText.nodeValue = this.SecondArgument;
      Parent.TextChanged();
      eq.setFocusTo(Parent);
      break;
    case this.INSERTCHILD:
      Parent.CursorPosition = this.Location;
      Parent.childrenObjects.splice(Parent.CursorPosition, 0, this.Argument);
      Parent.container.appendChild(this.Argument.GetContainer());
      this.Argument.parentObject = Parent;
      Parent.CursorPosition++;
      Parent.UpdatePositions();
      Parent.InsertTSpanFor(this.Argument);
      eq.Modified();
      Parent.UpdateCursor();
      eq.setFocusTo(Parent);
      break;
    case this.DELETECHILD:
      Parent.MMLP_Content.removeChild(this.Argument.MMLP_Preview);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview);
      Parent.container.removeChild(this.Argument.GetContainer());
      Parent.childrenObjects.splice(this.Location, 1);
      Parent.CursorPosition = this.Location;
      Parent.UpdatePositions();
      eq.Modified();
      eq.setFocusTo(Parent);
      break;
    case this.REPLACEMATRIXCELL:
      Parent.container.replaceChild(this.SecondArgument.container, this.Argument.container);
      Parent.childrenObjects[this.Location] = this.SecondArgument;
      this.SecondArgument.parentObject = Parent;
      var i = Math.floor(this.Location / Parent.Cols);
      var j = this.Location % Parent.Cols;
      Parent.MMLP_Content.childNodes.item(i).childNodes.item(1).childNodes.item(j).childNodes.item(1).replaceChild(this.SecondArgument.MMLP_Preview, this.Argument.MMLP_Preview);
      Parent.TeX_Content.replaceChild(this.SecondArgument.TeX_Preview, this.Argument.TeX_Preview);
      Parent.UpdatePositions();
      eq.Modified();
      eq.setFocusTo(Parent);
      break;
    case this.DELETEROOTCHILD:
      Parent.MMLP_Content.removeChild(this.Argument.MMLP_Preview);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview.previousSibling);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview.previousSibling);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview.nextSibling);
      Parent.TeX_Content.removeChild(this.Argument.TeX_Preview);
      Parent.container.removeChild(this.Argument.GetContainer());
      Parent.childrenObjects.splice(this.Location, 1);
      Parent.CursorPosition = this.Location;
      Parent.UpdatePositions();
      eq.Modified();
      eq.setFocusTo(Parent);
      break;
    case this.INSERTROOTCHILD:
      Parent.CursorPosition = this.Location;
      Parent.childrenObjects.splice(Parent.CursorPosition, 0, this.Argument);
      Parent.container.appendChild(this.Argument.GetContainer());
      this.Argument.parentObject = Parent;
      Parent.CursorPosition++;
      Parent.UpdatePositions();
      Parent.InsertTSpanFor(this.Argument);
      eq.Modified();
      Parent.UpdateCursor();
      eq.setFocusTo(Parent);
      break;
  }
}