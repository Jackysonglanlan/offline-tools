/**********************************************
Binary Operator
***********************************************/

Triplet.prototype = new Component();
Triplet.prototype.constructor = Triplet;
//children components indexes 
Triplet.prototype.LEFT = 2;
Triplet.prototype.MIDDLE = 0;
Triplet.prototype.RIGHT = 1;

function Triplet(parentObject, scriptLevelModifier){
  //when creted, this component notifies the component manager
  this.hWnd = eq.registerWindow(this);
  //the object should remember its parent
  this.parentObject     = parentObject;
  this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
  this.Midline = 0;
  this.Locked = false;

  this.CreateTSpans();
  this.TeX_Preview.appendChild(this.TeX_Content);

  this.container = svgDocument.createElement('svg');

  //create the component outer frame
  this.frame = svgDocument.createElement('rect');
  this.frame.setAttribute('width', '100%');
  this.frame.setAttribute('height', '100%');

  //set the component status to idle
  this.frame.setAttribute('class', 'idle');

  //insert the frame in the component
  this.container.appendChild(this.frame);

  //create children components 
  this.childrenObjects = new Array();

  this.appendChild(new Row(this), this.MIDDLE, true);
  this.appendChild(new Row(this), this.RIGHT, true);
  this.appendChild(new Row(this), this.LEFT, true);
  this.childrenObjects[this.RIGHT].appendChild(new EditableLabel(null), 0, true);
  this.childrenObjects[this.LEFT].appendChild(new EditableLabel(null), 0, true);
  this.childrenObjects[this.MIDDLE].appendChild(new EditableLabel(null), 0, true);

  this.AppendTSpanFor(this.childrenObjects[this.LEFT]);
  this.AppendTSpanFor(this.childrenObjects[this.MIDDLE]);
  this.AppendTSpanFor(this.childrenObjects[this.RIGHT]);

  this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Triplet.prototype.UpdatePositions = function(){
 if(this.childrenObjects.length < 3) return;
 // Compute children's boundingboxes
 var left_size  = this.childrenObjects[this.LEFT].GetSize();
 var middle_size = this.childrenObjects[this.MIDDLE].GetSize();
 var right_size = this.childrenObjects[this.RIGHT].GetSize();

 // Compute children's midline positions
 var LeftMidline = this.childrenObjects[this.LEFT].GetMidlineY();
 var MiddleMidline = this.childrenObjects[this.MIDDLE].GetMidlineY();
 var RightMidline = this.childrenObjects[this.RIGHT].GetMidlineY();

 // Compute global midline
 this.Midline = Maximum(Maximum(LeftMidline, MiddleMidline), RightMidline);

 var width = left_size.x + middle_size.x + right_size.x;
 var height = Maximum(Maximum(left_size.y + this.Midline - LeftMidline, middle_size.y + this.Midline - MiddleMidline),
    right_size.y + this.Midline - RightMidline);

 this.container.setAttribute('width', this.Scale(width));
 this.container.setAttribute('height', this.Scale(height));
 this.container.setAttribute('viewBox', '0 0 ' + width + ' ' + height);

 this.childrenObjects[this.LEFT].container.setAttribute('x', 0);
 this.childrenObjects[this.MIDDLE].container.setAttribute('x', left_size.x);
 this.childrenObjects[this.RIGHT].container.setAttribute('x', left_size.x + middle_size.x);

 this.childrenObjects[this.LEFT].container.setAttribute('y', this.Midline - LeftMidline);
 this.childrenObjects[this.MIDDLE].container.setAttribute('y', this.Midline - MiddleMidline);
 this.childrenObjects[this.RIGHT].container.setAttribute('y', this.Midline - RightMidline);

 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the Triplet as Presentational MathML
//----------------------------------------------------
Triplet.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent + '<mrow>\n';
  Result += this.childrenObjects[this.LEFT].ExportPresentationalMathML(indent + '  ');
  Result += this.childrenObjects[this.MIDDLE].ExportPresentationalMathML(indent + '  ');
  Result += this.childrenObjects[this.RIGHT].ExportPresentationalMathML(indent + '  ');
  Result += indent + '</mrow>\n';
  return Result;
}

//----------------------------------------------------
//    Export the Triplet as LaTeX
//----------------------------------------------------
Triplet.prototype.ExportLaTeX = function(){
  var Result = this.childrenObjects[this.LEFT].ExportLaTeX();
  Result += this.childrenObjects[this.MIDDLE].ExportLaTeX();
  Result += this.childrenObjects[this.RIGHT].ExportLaTeX();
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Triplet.prototype.CreateInstance = function(){
  return new Triplet(null, this.ScriptLevelModifier);
}