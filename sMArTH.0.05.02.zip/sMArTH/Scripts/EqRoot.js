/***********************************************
Equation root
************************************************/

EqRoot.prototype = new Component();
EqRoot.prototype.constructor = EqRoot;

function EqRoot(parentSVGElement){
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);

 //the object should remember its parent
 this.parentSVGElement = parentSVGElement;

 this.CreateTSpans('math', 'math');

 this.TeX_Preview = MakeTSpan();
 var TeXTspan = MakeTSpan();
 TeXTspan.appendChild(document.createTextNode('\\documentstyle{article}'));
 this.TeX_Preview.appendChild(TeXTspan);
 TeXTspan = MakeTSpan();
 TeXTspan.appendChild(document.createTextNode('\\begin{document}'));
 this.TeX_Preview.appendChild(TeXTspan);
 this.TeX_Content = MakeTSpan();
 this.TeX_Preview.appendChild(this.TeX_Content);
 TeXTspan = MakeTSpan();
 TeXTspan.appendChild(document.createTextNode('\\end{document}'));
 this.TeX_Preview.appendChild(TeXTspan);

 this.childrenObjects = new Array();

 this.container = parentSVGElement;
 var row = new Row();
 row.Insert(new EditableLabel(null));
 row.InsertTSpanFor(row.childrenObjects[0]);
 this.appendChild(row);
 this.InsertTSpanFor(row);
 row.childrenObjects[0].UpdatePositions();
}

//----------------------------------------------------
//     Set Focus
//----------------------------------------------------
EqRoot.prototype.FocusGained = function() {
 eq.GiveCursorTo(null);
}

//----------------------------------------------------
//     Place the cursor before the argument child
//----------------------------------------------------
EqRoot.prototype.SetCursorBefore = function(child) {
  var i;
  for(i = 1; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      this.childrenObjects[i-1].EnterFromEnd();
    }
  }
}

//----------------------------------------------------
//     Place the cursor after the argument child
//----------------------------------------------------
EqRoot.prototype.SetCursorAfter = function(child) {
  var i;
  for(i = 0; i < this.childrenObjects.length - 1; i++){
    if(this.childrenObjects[i] == child){
      this.childrenObjects[i+1].EnterFromBegin();
    }
  }
}

//----------------------------------------------------
//     Loose Focus
//----------------------------------------------------
EqRoot.prototype.FocusLost = function() {
}

//----------------------------------------------------
//     Replace one of the children components with
//    a new child component
//----------------------------------------------------
EqRoot.prototype.ReplaceChildWith = function(replaced, newChild){
  for(var i = 0; i <  this.childrenObjects.length; i++){
    var obj = this.childrenObjects[i];
    if(obj == replaced){
      eq.EqModified(this.hWnd, replaced, UndoStep.prototype.DELETEROOTCHILD, i);
      eq.EqModified(this.hWnd, newChild, UndoStep.prototype.INSERTROOTCHILD, i);
      this.parentSVGElement.replaceChild(newChild.container, replaced.container);
      this.childrenObjects.splice(i, 1, newChild);
      this.MMLP_Content.replaceChild(newChild.MMLP_Preview, replaced.MMLP_Preview);
      this.TeX_Content.replaceChild(newChild.TeX_Preview, replaced.TeX_Preview);
      return true;
    }
  }
}

//----------------------------------------------------
//     Insert a new component
//----------------------------------------------------
EqRoot.prototype.Insert = function(NewComponent){
  var ComponentArray = new Array();
  ComponentArray.push(NewComponent);
  this.NewRowAfter(this.childrenObjects[this.childrenObjects.length-1], ComponentArray);
}

//----------------------------------------------------
//     Delete one of the child components
//----------------------------------------------------
EqRoot.prototype.DeleteChild = function(child){
  if(this.childrenObjects.length == 1){
    var row = new Row();
    row.Insert(new EditableLabel(null));
    this.ReplaceChildWith(this.childrenObjects[0], row);
    row.parentObject = this;
    row.childrenObjects[0].UpdatePositions();
    eq.setFocusTo(row.childrenObjects[0]);
    this.UpdatePositions();
    return;
  }
  var i;
  for(i = 0; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      eq.EqModified(this.hWnd, child, UndoStep.prototype.DELETEROOTCHILD, i);
      this.MMLP_Content.removeChild(child.MMLP_Preview);
      this.TeX_Content.removeChild(child.TeX_Preview.previousSibling);
      this.TeX_Content.removeChild(child.TeX_Preview.previousSibling);
      this.TeX_Content.removeChild(child.TeX_Preview.nextSibling);
      this.TeX_Content.removeChild(child.TeX_Preview);
      this.container.removeChild(child.GetContainer());
      this.childrenObjects.splice(i, 1);
      if(i < this.childrenObjects.length){
        this.childrenObjects[i].EnterFromBegin();
      }
      else{
        this.childrenObjects[i-1].EnterFromBegin();
      }
      this.UpdatePositions();
      return;
    }
  }
}

//----------------------------------------------------
//     Insert a new row after the given component
//----------------------------------------------------
EqRoot.prototype.NewRowAfter = function(child, transferredChildren){
  var i;
  for(i = 0; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      var row = new Row();
      if (transferredChildren && transferredChildren.length > 0){
        for (var j = 0; j < transferredChildren.length; j++){
          row.Insert(transferredChildren[j]);
        }
      }
      else {
        row.Insert(new EditableLabel(null));
      }
      eq.EqModified(this.hWnd, row, UndoStep.prototype.INSERTROOTCHILD, i+1);
      this.childrenObjects.splice(i+1, 0, row);
      this.container.appendChild(row.GetContainer());
      row.parentObject = this;
      row.childrenObjects[0].EnterFromBegin();
      row.childrenObjects[0].UpdatePositions();

      this.InsertTSpanFor(row);
      return;
    }
  }
}

//----------------------------------------------------
//     Merga two rows when pressing Backspace
//----------------------------------------------------
EqRoot.prototype.MergeBack = function(Child){
  var i;
  for(i = 1; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == Child){
      this.childrenObjects[i-1].EnterFromEnd();
      for(var j = 0; j < Child.childrenObjects.length; j++){
        this.childrenObjects[i-1].appendChild(Child.childrenObjects[j]);
        this.childrenObjects[i-1].InsertTSpanFor(Child.childrenObjects[j]);
      }
      eq.EqModified(this.hWnd, Child, UndoStep.prototype.DELETEROOTCHILD, i);
      this.childrenObjects.splice(i, 1);
      this.container.removeChild(Child.GetContainer());
      this.UpdatePositions();
      this.MMLP_Content.removeChild(Child.MMLP_Preview);
      this.TeX_Content.removeChild(Child.TeX_Preview.previousSibling);
      this.TeX_Content.removeChild(Child.TeX_Preview.previousSibling);
      this.TeX_Content.removeChild(Child.TeX_Preview.nextSibling);
      this.TeX_Content.removeChild(Child.TeX_Preview);
      return;
    }
  }
}

//----------------------------------------------------
//     Merga two rows when pressing Delete
//----------------------------------------------------
EqRoot.prototype.MergeForward = function(Child){
  var i;
  for(i = 0; i < this.childrenObjects.length - 1; i++){
    if(this.childrenObjects[i] == Child){
      for(var j = 0; j < this.childrenObjects[i+1].childrenObjects.length; j++){
        Child.appendChild(this.childrenObjects[i+1].childrenObjects[j]);
        Child.InsertTSpanFor(this.childrenObjects[i+1].childrenObjects[j]);
      }
      eq.EqModified(this.hWnd, this.childrenObjects[i+1], UndoStep.prototype.DELETEROOTCHILD, i+1);
      this.container.removeChild(this.childrenObjects[i+1].GetContainer());
      this.MMLP_Content.removeChild(this.childrenObjects[i+1].MMLP_Preview);
      this.TeX_Content.removeChild(this.childrenObjects[i+1].TeX_Preview.previousSibling);
      this.TeX_Content.removeChild(this.childrenObjects[i+1].TeX_Preview.previousSibling);
      this.TeX_Content.removeChild(this.childrenObjects[i+1].TeX_Preview.nextSibling);
      this.TeX_Content.removeChild(this.childrenObjects[i+1].TeX_Preview);
      this.childrenObjects.splice(i+1, 1);
      this.UpdatePositions();
      return;
    }
  }
}

//----------------------------------------------------
//     Key Down Event
//----------------------------------------------------
EqRoot.prototype.KeyDown = function(evt){
 switch (evt.keyCode){
  case 33:  // pageUp; select the previous sibling
    this.focusPreviousSibling(null);
    break;
  case 34:  // pageDown; select the next sibling
    this.focusNextSibling(null);
    break;
  case 35:  // end; select the first child
      if(this.childrenObjects[0] != null){
        eq.setFocusTo(this.childrenObjects[0]);
      }
    break;
  case 38:  // up; select the previous EditableLabel
      if(this.childrenObjects.length > 0){
        eq.setFocusTo(this.getRightmostLeaf(this.childrenObjects[0]));
      }
    break;
  case 40:  // down; select the next EditableLabel
      if(this.childrenObjects.length > 0){
        eq.setFocusTo(this.getLeftmostLeaf(this.childrenObjects[0]));
      }
    break;
  default:
    break;
 }
}

//----------------------------------------------------
//    Return the previous EditableLabel.
//  Used by the down key event handler.
//  Navigates through brother nodes
//----------------------------------------------------
EqRoot.prototype.getPreviousLeaf = function(child){
  for(var i = 1; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      return this.childrenObjects[i-1].getRightmostLeaf();
    }
  }
  if(this.childrenObjects.length > 0){
    return this.childrenObjects[this.childrenObjects.length - 1].getRightmostLeaf();
  }
}

//----------------------------------------------------
//    Return the next EditableLabel.
//  Used by the up key event handler.
//  Navigates through brother nodes
//----------------------------------------------------
EqRoot.prototype.getFollowingLeaf = function(child){
  for(var i = 0; i < this.childrenObjects.length-1; i++){
    if(this.childrenObjects[i] == child){
      return this.childrenObjects[i+1].getLeftmostLeaf();
    }
  }
  if(this.childrenObjects.length > 0){
    return this.childrenObjects[0].getLeftmostLeaf();
  }
}

//----------------------------------------------------
//    Update component layout
//----------------------------------------------------
EqRoot.prototype.UpdatePositions = function(){
  var yPosition = MARGIN;
  for(var i = 0; i <  this.childrenObjects.length; i++){
    var obj = this.childrenObjects[i];
    obj.container.setAttribute('y', yPosition);
    obj.container.setAttribute('x', ROW_OFFSET);
    yPosition += parseFloat(obj.container.getAttribute('height')) + ROW_SPACING;
  }

  var viewBox = this.container.getAttribute('viewBox');
  var viewBoxParams = viewBox.split(/\s*,\s*|\s+/);
  var viewRect = svgDocument.documentElement.createSVGRect();
  viewRect.x = parseFloat(viewBoxParams[0]);
  viewRect.y = parseFloat(viewBoxParams[1]);
  viewRect.width = parseFloat(viewBoxParams[2]);
  viewRect.height = parseFloat(viewBoxParams[3]);
  var bbox = this.container.getBBox();
  bbox.width += ROW_OFFSET;
  bbox.height += ROW_OFFSET;

  scroller.UpdateScrollbars(bbox, viewRect);
}

//----------------------------------------------------
//    Export the equation as Presentational MathML ( <math> )
//----------------------------------------------------
EqRoot.prototype.ExportPresentationalMathML = function(){
  var Result = '<?xml version="1.0" encoding="UTF-8"?>\n';
  Result += '<!DOCTYPE math PUBLIC "-//W3C//DTD MathML 2.0//EN" ';
  Result += '"http://www.w3.org/TR/MathML2/dtd/mathml2.dtd">\n';
  Result += '<math xmlns="http://www.w3.org/1998/Math/MathML" xmlns:xlink="http://www.w3.org/1999/xlink">\n';

  for(var i = 0; i < this.childrenObjects.length; i++){
    if(i > 0){
      Result += '  <mtext>&NewLine;</mtext>\n';
    }
    Result += this.childrenObjects[i].ExportPresentationalMathML('  ');
  }
  Result += '</math>';
  return Result;
}

//----------------------------------------------------
//    Export the equation as Content MathML
//----------------------------------------------------
EqRoot.prototype.ExportContentMathML = function(){
  var Result = '<?xml version="1.0" encoding="UTF-8"?>\n';
  Result += '<!DOCTYPE math PUBLIC "-//W3C//DTD MathML 2.0//EN" ';
  Result += '"http://www.w3.org/TR/MathML2/dtd/mathml2.dtd">\n';
  Result = '<math xmlns="http://www.w3.org/1998/Math/MathML" xmlns:xlink="http://www.w3.org/1999/xlink">\n';
  for(var i = 0; i < this.childrenObjects.length; i++){
    Result += '<mrow>\n' + this.childrenObjects[i].ExportContentMathML() + '</mrow>\n';
  }
  Result += '</math>';
  return Result;
}

//----------------------------------------------------
//    Export the equation as LaTeX
//----------------------------------------------------
EqRoot.prototype.ExportLaTeX = function(){
  var Result = '\\documentstyle{article}\n\\begin{document}';
  for(var i = 0; i < this.childrenObjects.length; i++){
    Result += '\n\\[\n' + this.childrenObjects[i].ExportLaTeX() + '\n\\]';
  }
  Result += '\n\\end{document}';
  return Result;
}

//----------------------------------------------------
//    Export equation as SVG image
//----------------------------------------------------
EqRoot.prototype.ExportSVGNode = function(indent){
  var Result = '<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n';
  Result += '<!--DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN"\n';
  Result += '"http://www.w3.org/Graphics/SVG/1.1/DTD/svg11-flat-20030114.dtd"-->\n';
  Result += '<svg>\n';
  Result += '  <style type="text/css"><![CDATA[\n';
  Result += '  .textelt{\n';
  Result += '   fill: #000;\n';
  Result += '   stroke: none;\n';
  Result += '   font-size:24px;\n';
  Result += '   font-family: sMArTH, Code2000, Arial Unicode MS, serif;\n';
  Result += '   font-style: italic;\n';
  Result += '  }\n';

  Result += '  .numelt, .freetext{\n';
  Result += '   fill: #000;\n';
  Result += '   stroke: none;\n';
  Result += '   font-size:24px;\n';
  Result += '   font-family: sMArTH, Times New Roman, Code2000, Arial Unicode MS, serif;\n';
  Result += '  }\n';

  Result += '  .Operator{\n';
  Result += '  	fill: #000;\n';
  Result += '  	stroke: none;\n';
  Result += '  	font-size:24px;\n';
  Result += '  	font-family: sMArTH, Code2000, Arial Unicode MS, serif;\n';
  Result += '  }\n';

  Result += '  .LargeOp{\n';
  Result += '  	fill: #000;\n';
  Result += '  	stroke: none;\n';
  Result += '  	font-size:32px;\n';
  Result += '  	font-family:sMArTH, Code2000, Arial Unicode MS, serif;\n';
  Result += '  }\n';
  Result += '  .fractionline{\n';
  Result += '  	stroke: #000;\n';
  Result += '  	fill: none;\n';
  Result += '  	stroke-width: 1;\n';
  Result += '  }\n';
  Result += '  .mathSymbolLine{\n';
  Result += '  	stroke: #000;\n';
  Result += '  	fill: none;\n';
  Result += '  	stroke-width: 1;\n';
  Result += '  }\n';
  Result += '  ]]></style>\n';
  for (var i = 0; i < this.childrenObjects.length; i++){
    Result += this.childrenObjects[i].ExportSVGNode('  ');
  }
  Result += '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Insert tspans for children components
//----------------------------------------------------
EqRoot.prototype.InsertTSpanFor = function(child){
  for(var i = 0; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      if(i < this.childrenObjects.length - 1){
        this.MMLP_Content.insertBefore(child.MMLP_Preview, this.childrenObjects[i+1].MMLP_Preview);

        var TeXRowTSpan = MakeTSpan();
        TeXRowTSpan.appendChild(svgDocument.createTextNode('\\]'));
        this.TeX_Content.insertBefore(TeXRowTSpan, this.TeX_Content.childNodes.item(4*i));

        this.TeX_Content.insertBefore(child.TeX_Preview, this.TeX_Content.childNodes.item(4*i));

        TeXRowTSpan = MakeTSpan();
        TeXRowTSpan.appendChild(svgDocument.createTextNode(' '));
        this.TeX_Content.insertBefore(TeXRowTSpan, this.TeX_Content.childNodes.item(4*i));

        TeXRowTSpan = MakeTSpan();
        TeXRowTSpan.appendChild(svgDocument.createTextNode('\\['));
        this.TeX_Content.insertBefore(TeXRowTSpan, this.TeX_Content.childNodes.item(4*i));
      }
      else{
        this.MMLP_Content.appendChild(child.MMLP_Preview);

        var TeXRowTSpan = MakeTSpan();
        TeXRowTSpan.appendChild(svgDocument.createTextNode('\\['));
        this.TeX_Content.appendChild(TeXRowTSpan);

        TeXRowTSpan = MakeTSpan();
        TeXRowTSpan.appendChild(svgDocument.createTextNode(' '));
        this.TeX_Content.appendChild(TeXRowTSpan);

        this.TeX_Content.appendChild(child.TeX_Preview);

        TeXRowTSpan = MakeTSpan();
        TeXRowTSpan.appendChild(svgDocument.createTextNode('\\]'));
        this.TeX_Content.appendChild(TeXRowTSpan);
      }
    }
  }
}