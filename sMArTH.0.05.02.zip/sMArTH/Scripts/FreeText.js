/***********************************************
 FreeText

 <g width="width" height="height">
  <rect x="0" y="0" width="width" height="height" stroke="#000" fill="none" stroke-width="1"/>
  <text></text>
 </g>
************************************************/

FreeText.prototype = new EditableLabel();
FreeText.prototype.constructor = FreeText;

//----------------------------------------------------
//     FreeText Constructor
//----------------------------------------------------
function FreeText(parentObject, scriptLevelModifier){
 //Member data
 this.CursorPosition = 0;
 this.Cursor = null;
 this.Focused = false;
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject = parentObject;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);

 //the component is an intern svg
 this.container = svgDocument.createElement('svg');
 //set the component's location / size
 this.container.setAttribute('width', this.Scale(DEFAULT_TEXTELEMENT_WIDTH));
 this.container.setAttribute('height', this.Scale(DEFAULT_TEXTELEMENT_HEIGHT));
 this.container.setAttribute('viewBox', '0 0 ' + DEFAULT_TEXTELEMENT_WIDTH + ' ' + DEFAULT_TEXTELEMENT_HEIGHT);

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idleempty');

 //create the compomnent's text element
 this.text = svgDocument.createElement('text');
 this.text.setAttribute('baseline-shift', '-80%');
 this.text.setAttribute('class', 'freetext');
 this.text.setAttribute('x', MARGIN);
 this.text.setAttribute('y', MARGIN);
 this.innerText = svgDocument.createTextNode("");
 this.text.appendChild(this.innerText);
 this.container.appendChild(this.text);

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //set the mouse / key event handlers
 this.container.setAttribute('onkeypress', 'eq.eqKeyPress(evt)');
 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');

 this.MMLP_Content = svgDocument.createTextNode('');
 this.MMLP_Preview = MakeTSpan();
 this.MMLP_Preview.appendChild(this.MMLP_Content);

 this.TeX_Preview = MakeTSpan(true);
 this.TeX_Content = svgDocument.createTextNode('');
 this.TeX_Preview.appendChild(this.TeX_Content);
}

//----------------------------------------------------
//     Key Pressed Event
//----------------------------------------------------
FreeText.prototype.KeyPress = function(evt) {
// alert(this.container.getTransformToElement(svgDocument.documentElement));
 switch (evt.charCode){
  case 8: // backspace
    if (this.CursorPosition > 0){
      this.CursorPosition--;
      eq.EqModified(this.hWnd, this.innerText.nodeValue.charCodeAt(this.CursorPosition), UndoStep.prototype.DELETECHAR, this.CursorPosition);
      this.DeleteCharAt(this.CursorPosition);
      this.UpdateCursor();
    }
    break;
  case 13: // enter
    // Send to parent
    this.Split();
    this.parentObject.SetCursorAfter(this);
    this.parentObject.KeyPress(evt);
    break;
  case 32: // space
    // Transform into nbsp
    this.InsertCharAt(160);
    eq.EqModified(this.hWnd, 160, UndoStep.prototype.INSERTCHAR, this.CursorPosition);
    this.CursorPosition++;
    this.UpdateCursor();
    break;
  default:
    // insert char into the string, at the curent cursor position
    this.InsertCharAt(evt.charCode);
    eq.EqModified(this.hWnd, evt.charCode, UndoStep.prototype.INSERTCHAR, this.CursorPosition);
    this.CursorPosition++;
    this.UpdateCursor();
    break;
 }
 this.TextChanged();
}

//----------------------------------------------------
//     Split the label in two components
//----------------------------------------------------
FreeText.prototype.Split = function(Position) {
  if(!Position){
    Position = this.CursorPosition;
  }
  var textAfter = this.innerText.nodeValue.substring(Position);
  if(textAfter == ''){
    this.parentObject.SetCursorAfter(this);
    return this;
  }
  if(Position == 0){
    this.parentObject.SetCursorBefore(this);
    return this;
  }
  eq.EqModified(this.hWnd, this.innerText.nodeValue, UndoStep.prototype.MODIFYTEXT, this.CursorPosition, this.innerText.nodeValue.substring(0, Position));
  this.innerText.nodeValue = this.innerText.nodeValue.substring(0, Position);
  var TextAfter = new FreeText(null);
  TextAfter.innerText.nodeValue = textAfter;
  this.parentObject.SetCursorAfter(this);
  this.parentObject.Insert(TextAfter, true);
  TextAfter.UpdatePositions();
  this.UpdatePositions();
  this.parentObject.SetCursorAfter(this); 
  TextAfter.EnterFromBegin(); 
  return TextAfter;
}

//----------------------------------------------------
//     Text Changed
//----------------------------------------------------
FreeText.prototype.TextChanged = function() {
 if (this.innerText.length > 0){
  if(this.Focused){
    this.frame.setAttribute('class', 'focused');
  }
 }
 else{
  if(this.Focused){ 
    this.frame.setAttribute('class', 'focusedempty');
  }
  this.container.setAttribute('height', this.Scale(DEFAULT_TEXTELEMENT_HEIGHT));
  this.container.setAttribute('width', this.Scale(DEFAULT_TEXTELEMENT_WIDTH));
  this.container.setAttribute('viewBox', '0 0 ' + DEFAULT_TEXTELEMENT_WIDTH + ' ' + DEFAULT_TEXTELEMENT_HEIGHT);

  this.MMLP_Content.nodeValue = '';
  this.TeX_Content.nodeValue = '';
  if(this.parentObject){
    this.parentObject.UpdatePositions();
  }
  eq.Modified();
  return;
 }
 var size = this.text.getBBox();
 var width = this.text.getComputedTextLength() + 2*MARGIN;
 if(width < DEFAULT_TEXTELEMENT_WIDTH){
  width = DEFAULT_TEXTELEMENT_WIDTH;
 }
 var height = size.y + size.height + MARGIN;
 if(height < DEFAULT_TEXTELEMENT_HEIGHT){
  height = DEFAULT_TEXTELEMENT_HEIGHT;
 }
 this.container.setAttribute('height', this.Scale(height));
 this.container.setAttribute('width', this.Scale(width));
 this.container.setAttribute('viewBox', '0 0 ' + width + ' ' + height);

 this.MMLP_Content.nodeValue = '<mtext>' + this.innerText.nodeValue + '</mtext>';
 this.TeX_Content.nodeValue = this.ExportLaTeX();

 if(this.parentObject != null){
   this.parentObject.UpdatePositions();
 }
 eq.Modified();
}

//----------------------------------------------------
//    Export the label as Presentational MathML (<mtext>)
//----------------------------------------------------
FreeText.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent;
  return Result + '<mtext>' + this.innerText.nodeValue + '</mtext>\n';
}

//----------------------------------------------------
//    Export the label as LaTeX
//----------------------------------------------------
FreeText.prototype.ExportLaTeX = function(){
  return '\\mbox{' + this.innerText.nodeValue + '}';
}

//----------------------------------------------------
//    Export label as SVG image
//----------------------------------------------------
FreeText.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += indent + '  ' + printNode(this.text);
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
FreeText.prototype.CreateInstance = function(){
  var copy = new FreeText(null, this.ScriptLevelModifier);
  copy.innerText.nodeValue = this.innerText.nodeValue;
  copy.frame.setAttribute('class', this.frame.getAttribute('class'));
  return copy;
}

//----------------------------------------------------
//    Does this component accept all inputs?
//----------------------------------------------------
FreeText.prototype.WantAllChars = function(){
  return true;
}