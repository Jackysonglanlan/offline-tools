/***********************************************
Component Base
************************************************/

function Component(parentObject, ScriptLevelModifier){
if(arguments.length == 0) return;
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);

 //the object should remember its parent
 this.parentObject = parentObject;

 //the component is an intern svg
 this.container = svgDocument.createElement('svg');

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //set the mouse / key event handlers
 this.container.setAttribute('onkeypress', 'eq.eqKeyPress(evt)');
 this.container.setAttribute('onkeydown', 'eq.eqKeyDown(evt)');
 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Get the components container SVGElement
//----------------------------------------------------
Component.prototype.GetContainer = function(){
 return this.container;
}

//----------------------------------------------------
//     Add a new child to this component
//----------------------------------------------------
Component.prototype.appendChild = function(newChild, InsertPosition, SkipUndo){
  if(!InsertPosition && (InsertPosition != 0)){
    if(this.CursorPosition){
      InsertPosition = this.CursorPosition;
    }
    else{
      InsertPosition = 0;
    }
  }
  if(!SkipUndo){
    eq.EqModified(this.hWnd, newChild, UndoStep.prototype.INSERTCHILD, InsertPosition);
  } 
  this.childrenObjects.push(newChild);
  this.container.appendChild(newChild.GetContainer());
  this.AppendTSpanFor(newChild);
  newChild.parentObject = this;
  this.UpdatePositions();
  eq.Modified();
}

//----------------------------------------------------
//     This component takes the place of an existing
//    component and incorporates it
//----------------------------------------------------
Component.prototype.ReplaceChild = function(replaced){
  eq.EqModified(this.hWnd, newChild, UndoStep.prototype.INSERTCHILD, this.CursorPosition);
  this.parentObject = replaced.parentObject;
  this.ScriptLevelModifier = replaced.ScriptLevelModifier;
  this.parentObject.ReplaceChildWith(replaced, this);
  this.container.replaceChild(replaced.container, this.childrenObjects[0].container);
  this.childrenObjects[0] = replaced;
  replaced.parentObject = this;
  replaced.ScriptLevelModifier = 0;
  if(this.childrenObjects.length > 1){
    var i = 1;
    while(! this.childrenObjects[i]){
      i++;
    }
    eq.setFocusTo(this.childrenObjects[i]);
  }
  replaced.UpdatePositions();
  eq.Modified();
}

//----------------------------------------------------
//     Replace the first child with the given component
//----------------------------------------------------
Component.prototype.ReplaceFirst = function(Replacer){
  this.childrenObjects[0].Clear();
  this.childrenObjects[0].appendChild(Replacer);
  Replacer.parentObject = this.childrenObjects[0];
  Replacer.UpdatePositions();
  eq.Modified();
}

//----------------------------------------------------
//     Insert a new component
//----------------------------------------------------
Component.prototype.Insert = function(NewComponent, KeepThis){
  if(KeepThis || this.IsLocked()){
    this.parentObject.Insert(NewComponent);
    return false;
  }
  else{
    this.parentObject.ReplaceChildWith(this, NewComponent);
    NewComponent.ReplaceFirst(this);
    return true;
  }
}

//----------------------------------------------------
//     Insert all items in NewChildren into this component
//----------------------------------------------------
Component.prototype.InsertRange = function(NewChildren){
  this.parentObject.InsertRange(NewChildren);
  return false;
}

//----------------------------------------------------
//     Explode
//----------------------------------------------------
Component.prototype.Explode = function(){
  var Exploded = new Array();
  Exploded.push(this);
  return Exploded;
}

//----------------------------------------------------
//     Replace one of the children components with
//    a new child component
//    Return true if succeded (the replaced component
//    exists, false otherwise
//----------------------------------------------------
Component.prototype.ReplaceChildWith = function(replaced, newChild, SkipUndo){
 for (var i = 0; i < this.childrenObjects.length; i++){
  if(this.childrenObjects[i] == replaced){
    if (!SkipUndo){
      eq.EqModified(this.hWnd, replaced, UndoStep.prototype.DELETECHILD, i);
      eq.EqModified(this.hWnd, newChild, UndoStep.prototype.INSERTCHILD, i);
    }
    this.container.replaceChild(newChild.container, replaced.container);
    this.childrenObjects[i] = newChild;
    newChild.parentObject = this;
    
    
    this.MMLP_Content.replaceChild(newChild.MMLP_Preview, replaced.MMLP_Preview);
    this.TeX_Content.replaceChild(newChild.TeX_Preview, replaced.TeX_Preview);
    if(this instanceof Row){
      if((this.childrenObjects.length == 1) &&
          ((this.childrenObjects[0] instanceof EditableLabel) || (this.childrenObjects[0] instanceof StaticLabel))){
        this.TeX_OpenBrace.setAttribute('display', 'none');
        this.TeX_CloseBrace.setAttribute('display', 'none');
      }
      else{
        this.TeX_OpenBrace.setAttribute('display', 'inline');
        this.TeX_CloseBrace.setAttribute('display', 'inline');
      }
    }
    eq.Modified();
    return true;
   }
 }
 return false;
}

//----------------------------------------------------
//     Insert a new child
//----------------------------------------------------
Component.prototype.InsertChild = function(newChild, position){
  this.childrenObjects[position] = newChild;
  this.container.appendChild(newChild.container);
  newChild.parentObject = this;
  this.MMLP_Content.appendChild(newChild.MMLP_Preview);
  this.TeX_Content.appendChild(newChild.TeX_Preview);
  eq.Modified();
}

//----------------------------------------------------
//     Place the cursor before this component
//----------------------------------------------------
Component.prototype.SetCursorBefore = function(child) {
  this.parentObject.SetCursorBefore(this);
}

//----------------------------------------------------
//     Place the cursor after this component
//----------------------------------------------------
Component.prototype.SetCursorAfter = function(child, KeepFocus) {
  this.parentObject.SetCursorAfter(this, KeepFocus);
}

//----------------------------------------------------
//     Enter this component from the end
//----------------------------------------------------
Component.prototype.EnterFromEnd = function(){
  this.childrenObjects[0].EnterFromEnd();
}

//----------------------------------------------------
//     Enter this component from the begining
//----------------------------------------------------
Component.prototype.EnterFromBegin = function(){
  this.childrenObjects[0].EnterFromBegin();
}

//***************      EVENTS     *********************
//----------------------------------------------------
//     Set Focus
//----------------------------------------------------
Component.prototype.FocusGained = function() {
 this.frame.setAttribute('class', 'focused');
 eq.GiveCursorTo(null);
 if(this.parentObject){
   this.parentObject.SetCursorAfter(this, true);
 }
}

//----------------------------------------------------
//     Loose Focus
//----------------------------------------------------
Component.prototype.FocusLost = function() {
 this.frame.setAttribute('class', 'idle');
}

//----------------------------------------------------
//     UpdateCursor
//----------------------------------------------------
Component.prototype.UpdateCursor = function() {
}

//----------------------------------------------------
//     Mouse click
//----------------------------------------------------
Component.prototype.MouseClick = function(evt) {
}

//----------------------------------------------------
//     Mouse over
//----------------------------------------------------
Component.prototype.MouseOver = function(evt) {
 var frameclass = this.frame.getAttribute('class');
 if(frameclass === 'idle'){
  this.frame.setAttribute('class', 'hoveridle');
 }
 else if(frameclass === 'idleempty'){
  this.frame.setAttribute('class', 'hoverempty');
 }
}

//----------------------------------------------------
//     Mouse out
//----------------------------------------------------
Component.prototype.MouseOut = function(evt) {
 var frameclass = this.frame.getAttribute('class');
 if(frameclass === 'hoveridle'){
  this.frame.setAttribute('class', 'idle');
 }
 else if(frameclass === 'hoverempty'){
  this.frame.setAttribute('class', 'idleempty');
 }
}

//----------------------------------------------------
//     Key Pressed Event
//----------------------------------------------------
Component.prototype.KeyPress = function(evt){
  switch(evt.charCode){
    case 8: // backspace
      if(this.IsLocked()){
        return;
      }
      this.parentObject.SetCursorBefore(this);
      this.parentObject.KeyPress(evt);
      break;
    default:
      break;
  }
}

//----------------------------------------------------
//     Key Down Event
//----------------------------------------------------
Component.prototype.KeyDown = function(evt){
 switch (evt.keyCode){
  case 127: // delete; replace the selected component with an empty EditableLabel
    if(this.IsLocked()){
      return;
    }
//    var ReplacerText = new EditableLabel(null);
//    eq.setFocusTo(ReplacerText);
//    this.parentObject.ReplaceChildWith(this, ReplacerText);
//    ReplacerText.UpdatePositions();
    this.parentObject.DeleteChild(this);
    break;
  case 33:  // pageUp; select the previous sibling
    this.parentObject.focusPreviousSibling(this);
    break;
  case 34:  // pageDown; select the next sibling
    this.parentObject.focusNextSibling(this);
    break;
  case 35:  // end; select the first child
    if(this.childrenObjects[0] != null){
      this.childrenObjects[0].EnterFromBegin();
    }
    break;
  case 36:  // home; select the parent
    if(this.parentObject != null){
      this.parentObject.EnterFromBegin();
    }
    break;
  case 38:  // up; select the previous EditableLabel
    eq.StartLeafSearch(this);
    if(this.childrenObjects.length > 0){
//        eq.EnterFromBegin(this.getRightmostLeaf(this.childrenObjects[0]));
      this.getRightmostLeaf(this.childrenObjects[0]).EnterFromBegin();
    }
    else{
//        eq.EnterFromBegin(this.parentObject.getPreviousLeaf(this));
      this.parentObject.getPreviousLeaf(this).EnterFromBegin();
    }
    break
  case 37:  // <- (left arrow)
    this.parentObject.SetCursorBefore(this);
    break;
  case 39:  // -> (right arrow)
    this.parentObject.SetCursorAfter(this);
    break;
  case 40:  // down; select the next EditableLabel
      eq.StartLeafSearch(this);
      if(this.childrenObjects.length > 0){
//        eq.EnterFromBegin(this.getLeftmostLeaf(this.childrenObjects[0]));
        this.getLeftmostLeaf(this.childrenObjects[0]).EnterFromBegin();
      }
      else{
//        eq.EnterFromBegin(this.parentObject.getFollowingLeaf(this));
        this.parentObject.getFollowingLeaf(this).EnterFromBegin();
      }
    break;
  default:
//    alert(evt.keyCode);
    if (this.parentObject != null){
      this.parentObject.KeyDown(evt);
    }
    break;
 }
}
//***************************************************

//----------------------------------------------------
//    Return the next EditableLabel.
//  Used by the up key event handler.
//  Navigates through brother nodes
//----------------------------------------------------
Component.prototype.getFollowingLeaf = function(child){
  for(var i = 0; i < this.childrenObjects.length-1; i++){
    if(this.childrenObjects[i] == child){
      while((! this.childrenObjects[i+1]) && i < this.childrenObjects.length-1){
        i++;
      }
      if(i < this.childrenObjects.length-1){
        return this.childrenObjects[i+1].getLeftmostLeaf();
      }
    }
  }
  if(!eq.ContinueLeafSearch(this)){
    eq.StopLeafSearch();
    return this;
  }
  return this.parentObject.getFollowingLeaf(this);
}

//----------------------------------------------------
//    Return the leftmost EditableLabel from this subtree
//  Used by the up key event handler.
//  Navigates through child nodes
//----------------------------------------------------
Component.prototype.getLeftmostLeaf = function(){
  if(!eq.ContinueLeafSearch(this)){
    eq.StopLeafSearch();
    return this;
  }
  if(this.childrenObjects.length > 0){
    return this.childrenObjects[0].getLeftmostLeaf();
  }
  return this.parentObject.getFollowingLeaf(this);
}

//----------------------------------------------------
//    Return the previous EditableLabel.
//  Used by the down key event handler.
//  Navigates through brother nodes
//----------------------------------------------------
Component.prototype.getPreviousLeaf = function(child){
  for(var i = 1; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      while((! this.childrenObjects[i-1]) && i > 0){
        i--;
      }
      if(i > 0){
        return this.childrenObjects[i-1].getRightmostLeaf();
      }
    }
  }
  if(!eq.ContinueLeafSearch(this)){
    eq.StopLeafSearch();
    return this;
  }
  return this.parentObject.getPreviousLeaf(this);
}

//----------------------------------------------------
//    Return the rightmost EditableLabel from this subtree 
//  Used by the down key event handler.
//  Navigates through child nodes
//----------------------------------------------------
Component.prototype.getRightmostLeaf = function(){
  if(!eq.ContinueLeafSearch(this)){
    eq.StopLeafSearch();
    return this;
  }
  if(this.childrenObjects.length > 0){
    return this.childrenObjects[this.childrenObjects.length - 1].getRightmostLeaf();
  }
  return this.parentObject.getPreviousLeaf(this);
}

//----------------------------------------------------
//    Select the next sibling of this node.
//  Used by the page down key event handler.
//  Navigates through brother nodes. 
//----------------------------------------------------
Component.prototype.focusNextSibling = function(focusedChild){
  for(var i = 0; i < this.childrenObjects.length-1; i++){
    if(this.childrenObjects[i] == focusedChild){
      eq.setFocusTo(this.childrenObjects[i+1]);
      return;
    }
  }
  if(this.childrenObjects.length > 0){
    eq.setFocusTo(this.childrenObjects[0]);
  }
}

//----------------------------------------------------
//    Select the previous sibling of this node.
//  Used by the page up key event handler.
//  Navigates through brother nodes.
//----------------------------------------------------
Component.prototype.focusPreviousSibling = function(focusedChild){
  for(var i = 1; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == focusedChild){
      eq.setFocusTo(this.childrenObjects[i-1]);
      return;
    }
  }
  if(this.childrenObjects.length > 0){
    eq.setFocusTo(this.childrenObjects[this.childrenObjects.length - 1]);
  }
}

//----------------------------------------------------
//    Update component layout
//----------------------------------------------------
Component.prototype.UpdatePositions = function(){
 if(this.parentObject){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Get component size
//----------------------------------------------------
Component.prototype.GetSize = function() {
 var size = svgDocument.documentElement.createSVGPoint();
 var x = this.container.getAttribute('width');
 if(x){
   size.x = parseFloat(x);
 }
 else{
   size.x = 0;
 }
 var y = this.container.getAttribute('height');
 if(y){
   size.y = parseFloat(y);
 }
 else{
   size.y = 0;
 }
 return size;
}

//----------------------------------------------------
//    Get component midline
//----------------------------------------------------
Component.prototype.GetMidlineY = function() {
  return this.Midline;
}

//----------------------------------------------------
//    Scale dimensions
//----------------------------------------------------
Component.prototype.Scale = function(dimension){
 return (dimension / Math.pow(SCRIPTSIZEMULTIPLIER, this.ScriptLevelModifier));
}

//----------------------------------------------------
//    Export the equation component as Presentational MathML
//----------------------------------------------------
Component.prototype.ExportPresentationalMathML = function(){
  var Result = '<component_pmml>\n';
  if(this.childrenObjects){
    for(var i = 0; i < this.childrenObjects.length; i++){
      if(this.childrenObjects[i]){
        Result += this.childrenObjects[i].ExportPresentationalMathML();
      }
    }
  }
  return Result + '</component_pmml>\n';
}

//----------------------------------------------------
//    Export the equation component as Content MathML
//----------------------------------------------------
Component.prototype.ExportContentMathML = function(){
  var Result = '<component_cmml>\n';
  if(this.childrenObjects){
    for(var i = 0; i < this.childrenObjects.length; i++){
      if(this.childrenObjects[i]){
        Result += this.childrenObjects[i].ExportContentMathML();
      }
    }
  }
  return Result + '</component_cmml>\n';
}

//----------------------------------------------------
//    Export container begin tag
// 
//----------------------------------------------------
Component.prototype.ExportSVGNodeBeginTag = function(indent){
  var Result = indent + '<svg ';
  Result += ' x="' + this.container.getAttribute('x') + '"';
  Result += ' y="' + this.container.getAttribute('y') + '"';
  Result += ' width="' + this.container.getAttribute('width') + '"';
  Result += ' height="' + this.container.getAttribute('height') + '"';
  Result += ' viewBox="' + this.container.getAttribute('viewBox') + '">\n';
  return Result;
}
//----------------------------------------------------
//    Export component as SVG image
//----------------------------------------------------
Component.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  for (var i = 0; i < this.childrenObjects.length; i++){
    if (this.childrenObjects[i]){
     Result += this.childrenObjects[i].ExportSVGNode(indent + '  ');
    }
  }
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Does this component accept all inputs?
//----------------------------------------------------
Component.prototype.WantAllChars = function(){
  return false;
}

//----------------------------------------------------
//    Can this component be replaced or modified? 
//----------------------------------------------------
Component.prototype.IsLocked = function(){
  return this.Locked;
}

//----------------------------------------------------
//    Get Next Available Child 
//----------------------------------------------------
Component.prototype.GetNextAvailableChild = function(index){
  for (var i = index + 1; i < this.childrenObjects.length; i++){
    if (this.childrenObjects[i]) return i;
  }
  return -1;
  
}

//----------------------------------------------------
//    Preview the component as Presentational MathML ( <mrow> )
//----------------------------------------------------
Component.prototype.PreviewPresentationalMathML = function(indent){
  
}

//----------------------------------------------------
//    Insert tspans for children components
//----------------------------------------------------
Component.prototype.InsertTSpanFor = function(child, tag){
  for(var i = 0; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      if(i < this.childrenObjects.length - 1){
        this.MMLP_Content.insertBefore(child.MMLP_Preview, this.childrenObjects[i+1].MMLP_Preview);
        this.TeX_Content.insertBefore(child.TeX_Preview, this.childrenObjects[i+1].TeX_Preview);
      }
      else{
        this.MMLP_Content.appendChild(child.MMLP_Preview);
        this.TeX_Content.appendChild(child.TeX_Preview);
      }
    }
  }
}

//----------------------------------------------------
//    Append tspans for children components
//----------------------------------------------------
Component.prototype.AppendTSpanFor = function(child){
  this.MMLP_Content.appendChild(child.MMLP_Preview);
  this.TeX_Content.appendChild(child.TeX_Preview);
}

//----------------------------------------------------
//    Create preview tspans
//----------------------------------------------------
Component.prototype.CreateTSpans = function(startTag, endTag){
 this.MMLP_Content = MakeTSpan();
 this.MMLP_Preview = MakeTSpan();
 this.TeX_Preview = MakeTSpan(true);
 this.TeX_Content = MakeTSpan(true);
 if(startTag){
//   this.MMLP_OpenHandleTag = MakeTSpan();
//   this.MMLP_OpenHandleTag.appendChild(svgDocument.createTextNode('+'));
//   this.MMLP_OpenHandleTag.setAttribute('display', 'none');
//   this.MMLP_CloseHandleTag = MakeTSpan();
//   this.MMLP_CloseHandleTag.appendChild(svgDocument.createTextNode('-'));
   this.MMLP_StartTag = MakeTSpan();
   this.MMLP_StartTag.appendChild(svgDocument.createTextNode('<' + startTag + '>'));
   this.MMLP_EndTag = MakeTSpan();
   this.MMLP_EndTag.appendChild(svgDocument.createTextNode('</' + endTag + '>'));
//   this.MMLP_Preview.appendChild(this.MMLP_OpenHandleTag);
//   this.MMLP_Preview.appendChild(this.MMLP_CloseHandleTag);
   this.MMLP_Preview.appendChild(this.MMLP_StartTag);
 }
 this.MMLP_Preview.appendChild(this.MMLP_Content);
 if(startTag){
   this.MMLP_Preview.appendChild(this.MMLP_EndTag);
 }
}

//----------------------------------------------------
//    Clone the component for cut/copy/paste
//----------------------------------------------------
Component.prototype.Clone = function(){
  var clone = this.CreateInstance();
  clone.Midline = this.Midline;
  clone.Locked = this.Locked;
  if(this.childrenObjects){
    for(var i = 0; i < this.childrenObjects.length; i++){
      if(this.childrenObjects[i]){
        if(!clone.childrenObjects[i]){
          clone.InsertChild(this.childrenObjects[i].Clone(), i, true);
        }
        else{
          clone.ReplaceChildWith(clone.childrenObjects[i], this.childrenObjects[i].Clone(), true);
        }
      }
    }
  }
  clone.UpdatePositions();
  return clone;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Component.prototype.CreateInstance = function(){
  return new Component(null, this.ScriptLevelModifier);
}

//----------------------------------------------------
//    Delete a child component
//----------------------------------------------------
Component.prototype.DeleteChild = function(child){
  if((this.childrenObjects.length == 1)){
    var row = new Row();
    row.Insert(new EditableLabel(null));
    this.ReplaceChildWith(this.childrenObjects[0], row);
    row.parentObject = this;
    row.childrenObjects[0].UpdatePositions();
    eq.setFocusTo(row.childrenObjects[0]);
    if((this instanceof Row) && (this.childrenObjects.length == 1) &&
        ((this.childrenObjects[0] instanceof EditableLabel) || (this.childrenObjects[0] instanceof StaticLabel))){
      this.TeX_OpenBrace.setAttribute('display', 'none');
      this.TeX_CloseBrace.setAttribute('display', 'none');
    }
    else{
      this.TeX_OpenBrace.setAttribute('display', 'inline');
      this.TeX_CloseBrace.setAttribute('display', 'inline');
    }
    eq.Modified();
    return;
  }

/*  if((this.childrenObjects.length == 1) && (this.childrenObjects[0] == child){
    this.parentObject.deleteChild(this);
  }*/
  var i;
  for(i = 0; i < this.childrenObjects.length; i++){
    if(this.childrenObjects[i] == child){
      this.MMLP_Content.removeChild(child.MMLP_Preview);
      this.TeX_Content.removeChild(child.TeX_Preview);
      this.container.removeChild(child.GetContainer());
      this.childrenObjects.splice(i, 1);
      if(i < this.childrenObjects.length){
        this.childrenObjects[i].EnterFromBegin();
      }
      else{
        this.childrenObjects[i-1].EnterFromBegin();
      }
      this.UpdatePositions();
      eq.EqModified(this.hWnd, child, UndoStep.prototype.DELETECHILD, i);
      if((this instanceof Row) && (this.childrenObjects.length == 1) &&
          ((this.childrenObjects[0] instanceof EditableLabel) || (this.childrenObjects[0] instanceof StaticLabel))){
        this.TeX_OpenBrace.setAttribute('display', 'none');
        this.TeX_CloseBrace.setAttribute('display', 'none');
      }
      else{
        this.TeX_OpenBrace.setAttribute('display', 'inline');
        this.TeX_CloseBrace.setAttribute('display', 'inline');
      }
      eq.Modified();
      return;
    }
  }
}