/***********************************************
 TOOLBAR
************************************************/
function newfraction(FracBevelled){
  eq.BeginUndoSequence();
  var newFrac = new Fraction(null, null, FracBevelled);
  if (eq.getFocusedElement().Insert(newFrac) == true){
    newFrac.childrenObjects[1].childrenObjects[0].EnterFromBegin();
  }
  else{
    newFrac.childrenObjects[0].childrenObjects[0].EnterFromBegin();
  }
}

function newroot(){
  eq.BeginUndoSequence();
  var newRoot = new Root(null);
  if (eq.getFocusedElement().Insert(newRoot) == true){
    newRoot.childrenObjects[1].childrenObjects[0].EnterFromBegin();
  }
  else{
    newRoot.childrenObjects[0].childrenObjects[0].EnterFromBegin();
  }
}

function newsqrt(evt){
  eq.BeginUndoSequence();
  var newRoot = new Sqrt(null);
  if (eq.getFocusedElement().Insert(newRoot) == false){
    newRoot.childrenObjects[0].childrenObjects[0].EnterFromBegin();
  }
}

function newsubsup(Type){
  eq.BeginUndoSequence();
 var newSubSup = new SubSup(null, 0, Type);
 if (eq.getFocusedElement().Insert(newSubSup) == true){
  nextindex = newSubSup.GetNextAvailableChild(0);
  if (nextindex != -1){
    newSubSup.childrenObjects[nextindex].childrenObjects[0].EnterFromBegin();
  }
 }
 else{
  newSubSup.childrenObjects[0].childrenObjects[0].EnterFromBegin();
 }
}

function newoverunder(Type){
  eq.BeginUndoSequence();
 var newOverUnder = new OverUnder(null, 0, Type);
 if (eq.getFocusedElement().Insert(newOverUnder) == true){
  nextindex = newOverUnder.GetNextAvailableChild(0);
  if (nextindex != -1){
    newOverUnder.childrenObjects[nextindex].childrenObjects[0].EnterFromBegin();
  }
 }
 else{
  newOverUnder.childrenObjects[0].childrenObjects[0].EnterFromBegin();
 }
}

function newtext(){
  eq.BeginUndoSequence();
 var newText = new FreeText(null);
 eq.getFocusedElement().Insert(newText, true);
 newText.EnterFromBegin();
}

function newfenced(open, close){
  eq.BeginUndoSequence();
 var f = new Fenced(null, 0, open, close);
 eq.getFocusedElement().Insert(f);
 eq.setFocusTo(f.childrenObjects[f.ARGUMENT].childrenObjects[0]);
}

function newhat(Type){
  eq.BeginUndoSequence();
 //eq.getFocusedElement().Insert(new Hats(null, 0, Type));
 var f = new Hats(null, 0, Type);
 eq.getFocusedElement().Insert(f);
 eq.setFocusTo(f.childrenObjects[f.ARGUMENT].childrenObjects[0]);
}

function newshoe(Type){
  eq.BeginUndoSequence();
  var f = new Shoes(null, 0, Type);
  eq.getFocusedElement().Insert(f);
  eq.setFocusTo(f.childrenObjects[f.ARGUMENT].childrenObjects[0]);
}

function newprime(Type){
  eq.BeginUndoSequence();
  var prime = new Prime(null, 0, Type);
  var Focused = eq.getFocusedElement();
  var Parent = Focused.parentObject;
  if(Focused.Insert(prime) == true){
    Parent.SetCursorAfter(prime);
  }
  else{
    prime.childrenObjects[0].childrenObjects[0].EnterFromBegin();
  }
}

function newmatrix(Rows, Cols){
  eq.BeginUndoSequence();
  var m = new Matrix(null, 0, Rows, Cols);
  eq.getFocusedElement().Insert(m);
  eq.setFocusTo(m.childrenObjects[0].childrenObjects[0]);
}

function newmatrixEllipsis(){
  eq.BeginUndoSequence();
  var m = new Matrix(null, 0, 4, 4);
  eq.getFocusedElement().Insert(m);
  m.childrenObjects[2].Insert(new StaticLabel(null, 0, '&vellip;'));
  m.childrenObjects[6].Insert(new StaticLabel(null, 0, '&vellip;'));
  m.childrenObjects[14].Insert(new StaticLabel(null, 0, '&vellip;'));
  m.childrenObjects[8].Insert(new StaticLabel(null, 0, '&ctdot;'));
  m.childrenObjects[9].Insert(new StaticLabel(null, 0, '&ctdot;'));
  m.childrenObjects[11].Insert(new StaticLabel(null, 0, '&ctdot;'));
  m.childrenObjects[10].Insert(new StaticLabel(null, 0, '&dtdot;'));
  eq.setFocusTo(m.childrenObjects[0].childrenObjects[0]);
}

function newmatrixHEllipsis(){
  eq.BeginUndoSequence();
  var m = new Matrix(null, 0, 1, 4);
  eq.getFocusedElement().Insert(m);
  m.childrenObjects[2].Insert(new StaticLabel(null, 0, '&ctdot;'));
  eq.setFocusTo(m.childrenObjects[0].childrenObjects[0]);
}

function newmatrixVEllipsis(){
  eq.BeginUndoSequence();
 var m = new Matrix(null, 0, 4, 1);
 eq.getFocusedElement().Insert(m);
 m.childrenObjects[2].Insert(new StaticLabel(null, 0, '&vellip;'));
 eq.setFocusTo(m.childrenObjects[0].childrenObjects[0]);
}

function newbinaryop(op){
  eq.BeginUndoSequence();
  eq.getFocusedElement().Insert(new StaticLabel(null, 0, op), true);
}

function newstatic(op, Type, Locked, ContentType){
  eq.BeginUndoSequence();
  eq.getFocusedElement().Insert(new StaticLabel(null, 0, op, ContentType), true);
}

function newcalculusfunc(operation, OverUnderSelection){
  eq.BeginUndoSequence();
  var func = new Pair(null, 0, 'calculus');
  eq.getFocusedElement().Insert(func);
  var funcSign = new StaticLabel(func, 0, operation);
  funcSign.OperatorType = operation;
  funcSign.text.setAttribute('class', 'LargeOp');
  func.childrenObjects[func.LEFT].childrenObjects[0].Insert(funcSign);
  if (OverUnderSelection > 0) {
    var funcOp = new OverUnder(funcSign, 0, OverUnderSelection);
    funcSign.Insert(funcOp);
    funcOp.Locked = true;
    funcOp.childrenObjects[funcOp.BASE].Locked = true;
  }
  eq.setFocusTo(func.childrenObjects[func.RIGHT].childrenObjects[0]);

  funcSign.Locked = true;
}

function newd(operation){
  eq.BeginUndoSequence();
  var func = new Pair(null, 0, 'calculus');
  eq.getFocusedElement().Insert(func);
  var funcSign = new StaticLabel(func, 0, operation);
  func.childrenObjects[func.LEFT].childrenObjects[0].Insert(funcSign);
  eq.setFocusTo(func.childrenObjects[func.RIGHT].childrenObjects[0]);

  funcSign.Locked = true;
}

function newintegral(operation, OverUnderSelection){
  eq.BeginUndoSequence();
  var func = new Triplet(null);
  eq.getFocusedElement().Insert(func);
  var funcSign = new StaticLabel(func, 0, operation);
  funcSign.OperatorType = operation;
  funcSign.text.setAttribute('class', 'LargeOp');
  func.childrenObjects[func.LEFT].childrenObjects[0].Insert(funcSign);
  if (OverUnderSelection > 0) {
    var funcOp = new OverUnder(funcSign, 0, OverUnderSelection);
    funcSign.Insert(funcOp);
    funcOp.Locked = true;
    funcOp.childrenObjects[funcOp.BASE].Locked = true;
  }
  var funcDx = new Pair(null);
  func.childrenObjects[func.RIGHT].childrenObjects[0].Insert(funcDx);
  Dx = new StaticLabel(null, 0, 'd');
  funcDx.childrenObjects[funcDx.LEFT].childrenObjects[0].Insert(Dx);
  eq.setFocusTo(func.childrenObjects[func.MIDDLE].childrenObjects[0]);

  funcSign.Locked = true;
}

function newlimit(LimitType){
  eq.BeginUndoSequence();
  var limit = new Pair(null, 0, 'limit');
  eq.getFocusedElement().Insert(limit);

  limit.limitType = LimitType;
  var limitSign = new StaticLabel(limit, 0, 'lim', StaticLabel.prototype.FUNCTION);
  limit.childrenObjects[limit.LEFT].childrenObjects[0].Insert(limitSign);

  var limitOp = new OverUnder(null, 0, 2);
  limitSign.Insert(limitOp);
  var limitUnder = limitOp.childrenObjects[limitOp.UNDER].childrenObjects[0];

  if(LimitType == 'above'){
    var limitTendsTo = new BinaryOp(null, 0, '&LowerRightArrow;');
  }
  else if(LimitType == 'below'){
    var limitTendsTo = new BinaryOp(null, 0, '&UpperRightArrow;');
  }
  else if(LimitType == 'two-sided'){
    var limitTendsTo = new BinaryOp(null, 0, '&rarr;');
  }
  else{
    var limitTendsTo = new BinaryOp(null, 0, '&rarr;');
  }
  limitUnder.Insert(limitTendsTo);
  limitSign.Locked = true;
  limitOp.Locked = true;
  limitOp.childrenObjects[limitOp.BASE].Locked = true;
  limitOp.childrenObjects[limitOp.UNDER].Locked = true;
  limit.childrenObjects[limit.LEFT].Locked = true;
  limitTendsTo.Locked = true;
  limitTendsTo.childrenObjects[limitTendsTo.OP].Locked = true;
  
  eq.setFocusTo(limitTendsTo.childrenObjects[limitTendsTo.LEFT].childrenObjects[0]);
}

function newdoverdx(DifType){
  eq.BeginUndoSequence();
 var d_dx = new Fraction(null);
 eq.getFocusedElement().Insert(d_dx, true);
 var d = new StaticLabel(null, 0, DifType);
 d_dx.childrenObjects[d_dx.NUMERATOR].childrenObjects[0].Insert(d);
 var dx = new Pair(null);
 d_dx.childrenObjects[d_dx.DENOMINATOR].childrenObjects[0].Insert(dx);
 var diffd = new StaticLabel(null, 0, DifType);
 dx.childrenObjects[dx.LEFT].childrenObjects[0].Insert(diffd);
 eq.setFocusTo(dx.childrenObjects[dx.RIGHT].childrenObjects[0]);
}

function newtrig(functionType){
  eq.BeginUndoSequence();
 var func = new Pair(null, 0, 'trig');
 eq.getFocusedElement().Insert(func);
 var funcSign = new StaticLabel(func, 0, functionType, StaticLabel.prototype.FUNCTION);
 func.childrenObjects[func.LEFT].childrenObjects[0].Insert(funcSign);

 var funcArg = new Fenced(null, 0, '(', ')');
 func.childrenObjects[func.RIGHT].childrenObjects[0].Insert(funcArg);
 eq.setFocusTo(funcArg.childrenObjects[funcArg.ARGUMENT].childrenObjects[0]);
}
