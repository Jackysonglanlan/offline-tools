/**********************************************
Shoe
Shoe types:
( { | 
***********************************************/

Shoe.prototype = new Component();
Shoe.prototype.constructor = Shoe;
//children components indexes 
Shoe.prototype.Shoe = 0;

function Shoe(parentObject, scriptLevelModifier, Type){
  this.Locked = true
  //when creted, this component notifies the component manager
  this.hWnd = eq.registerWindow(this);
  //the object should remember its parent
  this.parentObject = parentObject;
  this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
  this.Type = Type;

  this.MMLP_Content = svgDocument.createTextNode('<mo accent="true">' + this.Type + '</mo>');
  this.MMLP_Preview = MakeTSpan();
  this.MMLP_Preview.appendChild(this.MMLP_Content);

  this.TeX_Preview = MakeTSpan(true);
  this.TeX_Content = svgDocument.createTextNode(GetLaTeX(this.Type));
  this.TeX_Preview.appendChild(this.TeX_Content);

  this.container = svgDocument.createElement('svg'); 

  //create the component outer frame
  this.frame = svgDocument.createElement('rect');
  this.frame.setAttribute('width', '100%');
  this.frame.setAttribute('height', '100%');

  //set the component status to idle
  this.frame.setAttribute('class', 'idle');

  //insert the frame in the component
  this.container.appendChild(this.frame);

  //create children components 
  this.childrenObjects = new Array();
  // Make the Shoe path
  this.childrenObjects.push(svgDocument.createElement('path'));
  this.childrenObjects[this.Shoe].setAttribute('class', 'mathSymbolLine');

  //insert the Shoe path in the component
  this.container.appendChild(this.childrenObjects[0]);

  this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Shoe.prototype.UpdateComponent = function(){
 switch(this.Type){
  case '&UnderBar;':
    this.childrenObjects[0].setAttribute('d', this.GetUnderBarPath());
    break;
  case '&UnderParenthesis;':
    this.childrenObjects[0].setAttribute('d', this.GetUnderParenthesisPath());
    break;
  case '&UnderBrace;':
    this.childrenObjects[0].setAttribute('d', this.GetUnderBracePath());
    break;
  default :
    alert('altceva');
 }

 this.container.setAttribute('width', this.Width);
 this.container.setAttribute ('height', DECO_HEIGHT);
}

Shoe.prototype.UpdatePositions = function(){
 this.UpdateComponent();
 this.parentObject.UpdatePositions();
}

Shoe.prototype.GetUnderBarPath = function(){
m = "M 0 " + (DECO_HEIGHT/2) + " H " + this.Width;
return m;
}

Shoe.prototype.GetUnderParenthesisPath = function(){
/*m = "M " + (LINEWIDTH/2) + " 0 a " + (DECO_HEIGHT-LINEWIDTH/2) + " " + (DECO_HEIGHT-LINEWIDTH/2) + " 0 0 0 " + (DECO_HEIGHT-LINEWIDTH/2) + " " + ((DECO_HEIGHT-LINEWIDTH/2));
m += " H " + (this.Width - DECO_HEIGHT);
m += " a " + (DECO_HEIGHT-LINEWIDTH/2) + " " + (DECO_HEIGHT-LINEWIDTH/2) + " 0 0 0 " + (DECO_HEIGHT-LINEWIDTH/2) + " " + (-(DECO_HEIGHT-LINEWIDTH/2));*/
var m = "M " + (LINEWIDTH/2) + " 0 C";
m += (LINEWIDTH/2) + " "  + (4*(DECO_HEIGHT-LINEWIDTH/2)/3) + " " + (this.Width - LINEWIDTH/2) + " "  + (4*(DECO_HEIGHT-LINEWIDTH/2)/3);
m += " " + (this.Width - LINEWIDTH/2) + " 0";
return m;
}

Shoe.prototype.GetUnderBracePath = function(){
m = "M " + (LINEWIDTH/2) + " 0 a " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2) + " 0 0 0 " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2);
m += " H " + ((this.Width - DECO_HEIGHT + LINEWIDTH)/2);
m += " a " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2) + " 0 0 1 " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2);
m += " a " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2) + " 0 0 1 " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (-DECO_HEIGHT/2);
m += " H " + (this.Width - (DECO_HEIGHT)/2);
m += " a " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2) + " 0 0 0 " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (-DECO_HEIGHT/2);
return m;
}


//----------------------------------------------------
//    Export the shoe as Presentational MathML ( <mo> )
//----------------------------------------------------
Shoe.prototype.ExportPresentationalMathML = function(indent){
  return indent + '<mo accent="true">' + this.Type + '</mo>\n';
}

//----------------------------------------------------
//    Export the Shoe as LaTeX
//----------------------------------------------------
Shoe.prototype.ExportLaTeX = function(){
  return GetLaTeX(this.Type);
}

//----------------------------------------------------
//    Export shoe as SVG image
//----------------------------------------------------
Shoe.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += indent + '  ' + printNode(this.childrenObjects[0]) + '\n';
  Result += indent + '</svg>\n';
  return Result;
}