/**********************************************
Root
***********************************************/

Root.prototype = new Component();
Root.prototype.constructor = Root;
//children components indexes 
Root.prototype.BASE = 0;
Root.prototype.INDEX = 1;

function Root(parentObject, scriptLevelModifier){
  this.Midline = 0;
  this.Locked = false;
  this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);

  // When created, this component notifies the component manager
  this.hWnd = eq.registerWindow(this);
  // The object should remember its parent
  this.parentObject = parentObject;

  this.CreateTSpans('mroot', 'mroot');

  this.TeX_Preview = MakeTSpan(true);
  this.TeX_Content = MakeTSpan(true);
  var TeXTspan = MakeTSpan(true);
  TeXTspan.appendChild(document.createTextNode('\\sqrt [\n'));
  this.TeX_Preview.appendChild(TeXTspan);
  this.TeX_Preview.appendChild(this.TeX_Content);

  this.container = svgDocument.createElement('svg');

  //create the component outer frame
  this.frame = svgDocument.createElement('rect');
  this.frame.setAttribute('width', '100%');
  this.frame.setAttribute('height', '100%');

  //set the component status to idle
  this.frame.setAttribute('class', 'idle');

  //insert the frame in the component
  this.container.appendChild(this.frame);

  //Draw the symbol
  this.rootSymbol = svgDocument.createElement('path');
  this.rootSymbol.setAttribute('class', 'mathSymbolLine');

  //insert the root symbol in the component
  this.container.appendChild(this.rootSymbol);

  //create children components
  this.childrenObjects = new Array();
  this.appendChild(new Row(this), this.BASE, true);
  this.appendChild(new Row(this, 2), this.INDEX, true);

  this.childrenObjects[this.BASE].appendChild(new EditableLabel(this.childrenObjects[this.BASE]), 0, true);
  this.childrenObjects[this.INDEX].appendChild(new EditableLabel(this.childrenObjects[this.INDEX]), 0, true);
  this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');

  this.MMLP_Content.appendChild(this.childrenObjects[this.BASE].MMLP_Preview);
  this.MMLP_Content.appendChild(this.childrenObjects[this.INDEX].MMLP_Preview);

  this.TeX_Content.appendChild(this.childrenObjects[this.INDEX].TeX_Preview);
  TeXTspan = MakeTSpan(true);
  TeXTspan.appendChild(document.createTextNode('] '));
  this.TeX_Content.appendChild(TeXTspan);
  this.TeX_Content.appendChild(this.childrenObjects[this.BASE].TeX_Preview);
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Root.prototype.UpdatePositions = function(){
  if(this.childrenObjects.length < 2) return;
  var base_size = this.childrenObjects[this.BASE].GetSize();
  var index_size   = this.childrenObjects[this.INDEX].GetSize();
  var rootSymbolHeight = base_size.y + MARGIN;
  var tailLeftHeight = Minimum(rootSymbolHeight/3, ROOT_TAIL_HEIGHT);
  var tailRightWidth = Minimum(rootSymbolHeight/3, ROOT_TAIL_RIGHT_WIDTH);
  var tailLeftWidth  = Minimum(rootSymbolHeight/6, ROOT_TAIL_LEFT_WIDTH);
  var tailCenterX = Maximum(index_size.x + MARGIN, MARGIN + tailLeftWidth);
  var rootSymbolY = Maximum(Maximum(index_size.y - (rootSymbolHeight/2),
   index_size.y + MARGIN + tailLeftHeight - rootSymbolHeight), LINEWIDTH);
  var rootSymbolX = tailCenterX - tailLeftWidth;
  var Width = tailCenterX + tailRightWidth + MARGIN + base_size.x;
  var Height = rootSymbolY + rootSymbolHeight;
  var baseX = Width - base_size.x;
  var baseY = Height - base_size.y;
  var indexBottomY = Minimum(Height - tailLeftHeight - MARGIN, Height - rootSymbolHeight/2);
  var indexY = indexBottomY - index_size.y;
  var indexX = tailCenterX - index_size.x;
  
  this.container.setAttribute ('width', this.Scale(Width));
  this.container.setAttribute ('height', this.Scale(Height));
  this.container.setAttribute('viewBox', '0 0 ' + Width + ' ' + Height);
  
  var rootSymbolPath = "M " + (rootSymbolX-1) + " " + (Height - tailLeftHeight + 1) + " L " + 
    rootSymbolX + " " + (Height - tailLeftHeight) + " " +
    tailCenterX + " " + Height + " " +
    (tailCenterX + tailRightWidth) + " " + (rootSymbolY - LINEWIDTH/2) + " " +
    (Width) + " " + (rootSymbolY - LINEWIDTH/2);
  this.rootSymbol.setAttribute('d', rootSymbolPath);
  
  this.Midline = baseY + this.childrenObjects[this.BASE].GetMidlineY();
  
  this.childrenObjects[this.INDEX].container.setAttribute('x', indexX);
  this.childrenObjects[this.INDEX].container.setAttribute('y', indexY);
  this.childrenObjects[this.BASE].container.setAttribute('x', baseX);
  this.childrenObjects[this.BASE].container.setAttribute('y', baseY);
  if(this.parentObject != null){
    this.parentObject.UpdatePositions();
  }
}

//----------------------------------------------------
//    Export the Root as Presentational MathML (<mroot>)
//----------------------------------------------------
Root.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent + '<mroot>\n';
  Result += this.childrenObjects[this.BASE].ExportPresentationalMathML(indent + '  ');
  Result += this.childrenObjects[this.INDEX].ExportPresentationalMathML(indent + '  ');
  return Result + indent + '</mroot>\n';
}

//----------------------------------------------------
//    Export the Root as LaTeX
//----------------------------------------------------
Root.prototype.ExportLaTeX = function(){
  var Result = '\\sqrt [';
  Result += this.childrenObjects[this.INDEX].ExportLaTeX() + '] ';
  Result += this.childrenObjects[this.BASE].ExportLaTeX();
  return Result;
}

//----------------------------------------------------
//    Export root as SVG image
//----------------------------------------------------
Root.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += indent + '  ' + printNode(this.rootSymbol) + '\n';
  Result += this.childrenObjects[this.INDEX].ExportSVGNode(indent + '  ');
  Result += this.childrenObjects[this.BASE].ExportSVGNode(indent + '  ');
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Root.prototype.CreateInstance = function(){
  return new Root(null, this.ScriptLevelModifier);
}
