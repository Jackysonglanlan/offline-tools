/***********************************************
 editableLabel
 
 <g width="width" height="height">
  <rect x="0" y="0" width="width" height="height" stroke="#000" fill="none" stroke-width="1"/>
  <text></text>
 </g>
************************************************/

EditableLabel.prototype = new Component();
EditableLabel.prototype.constructor = EditableLabel;

//----------------------------------------------------
//     editableLabel Constructor
//----------------------------------------------------
function EditableLabel(parentObject, scriptLevelModifier){
 if(arguments.length == 0){
  return;
 }
 //Member data
 this.CursorPosition = 0;
 this.Cursor = null;
 this.Focused = false;
 this.Locked = false;
 this.IsNumber = true; // number or identifier? default: number
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject = parentObject;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);

 //the component is an intern svg
 this.container = svgDocument.createElement('svg');
 //set the component's location / size
 this.container.setAttribute('width', this.Scale(DEFAULT_TEXTELEMENT_WIDTH));
 this.container.setAttribute('height', this.Scale(DEFAULT_TEXTELEMENT_HEIGHT));
 this.container.setAttribute('viewBox', '0 0 ' + DEFAULT_TEXTELEMENT_WIDTH + ' ' + DEFAULT_TEXTELEMENT_HEIGHT);

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idleempty');

 //create the compomnent's text element
 this.text = svgDocument.createElement('text');
 this.text.setAttribute('baseline-shift', '-80%');
 this.text.setAttribute('class', 'textelt');
 this.text.setAttribute('x', MARGIN);
 this.text.setAttribute('y', MARGIN);
 this.innerText = svgDocument.createTextNode("");
 this.text.appendChild(this.innerText);
 this.container.appendChild(this.text);

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //set the mouse / key event handlers
 this.container.setAttribute('onkeypress', 'eq.eqKeyPress(evt)');
 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');

 this.MMLP_Content = svgDocument.createTextNode('');
 this.MMLP_Preview = MakeTSpan();
 this.MMLP_Preview.appendChild(this.MMLP_Content);

 this.TeX_Preview = MakeTSpan(true);
 this.TeX_Content = svgDocument.createTextNode('');
 this.TeX_Preview.appendChild(this.TeX_Content);
}

//----------------------------------------------------
//     Replace the first child with the given component
//----------------------------------------------------
EditableLabel.prototype.ReplaceFirst = function(Replacer){
  return;
}

//----------------------------------------------------
//     Insert a new component
//----------------------------------------------------
EditableLabel.prototype.Insert = function(NewComponent, KeepThis){
  if(NewComponent instanceof StaticLabel){
    this.Split();
    if (this.CursorPosition == 0){ 
      this.parentObject.SetCursorBefore(this);
    }
    else {
      this.parentObject.SetCursorAfter(this);
    }
  }
  if(this.innerText.nodeValue.length == 0){
    this.parentObject.ReplaceChildWith(this, NewComponent);
    NewComponent.UpdatePositions();
    if(NewComponent.EnterFromBegin){
      NewComponent.EnterFromBegin();
    }
    else{
      this.parentObject.SetCursorAfter(NewComponent);
    }
    NewComponent.UpdatePositions();
    return false;
  }
  if(KeepThis){
    this.parentObject.Insert(NewComponent);
    return false;
  }
  else{
    this.parentObject.ReplaceChildWith(this, NewComponent);
    NewComponent.ReplaceFirst(this);
    return true;
  }
}

//----------------------------------------------------
//     This component takes the place of an existing
//    component and incorporates it
//----------------------------------------------------
EditableLabel.prototype.ReplaceChild = function(replaced){
 this.parentObject = replaced.parentObject;
 this.ScriptLevelModifier = replaced.ScriptLevelModifier;
 this.parentObject.ReplaceChildWith(replaced, this);
 this.UpdatePositions();
}

//----------------------------------------------------
//     Set Focus
//----------------------------------------------------
EditableLabel.prototype.FocusGained = function() {
  this.Focused = true;
  if (this.innerText.length > 0){
    this.frame.setAttribute('class', 'focused');
  }
  else {
    this.frame.setAttribute('class', 'focusedempty');
  }
  this.Cursor = eq.GiveCursorTo(this);
  if (this.Cursor != null){
    this.container.appendChild(this.Cursor);
    this.UpdateCursor();
  }
  if(this.parentObject){
    this.parentObject.SetCursorAfter(this, true);
  }
}

//----------------------------------------------------
//     Loose Focus
//----------------------------------------------------
EditableLabel.prototype.FocusLost = function() {
 this.Focused = false;
 if (this.innerText.length > 0){
  this.frame.setAttribute('class', 'idle');
 }
 else {
  this.frame.setAttribute('class', 'idleempty');
 }
}

//----------------------------------------------------
//     Mouse click
//----------------------------------------------------
EditableLabel.prototype.MouseClick = function(evt) {
  if(this.innerText.nodeValue.length < 1) return;
  this.CursorPosition = this.GetClickedChar(ScreenToClient(this.container, evt));
  this.UpdateCursor();
}

//----------------------------------------------------
//     Get the char index of the clicked char
//----------------------------------------------------
EditableLabel.prototype.GetClickedChar = function(point){
  var i = 0;
  while((i < this.innerText.nodeValue.length) && (this.text.getEndPositionOfChar(i).x < point.x)){
   i++;
  }
  if(i == this.innerText.nodeValue.length){
    return i;
  }
  if((point.x - this.text.getStartPositionOfChar(i).x) > 
    (this.text.getEndPositionOfChar(i).x - point.x)){
    i++;
  }
  return i;
}

//----------------------------------------------------
//     Enter this label from the end
//----------------------------------------------------
EditableLabel.prototype.EnterFromEnd = function(){
  eq.setFocusTo(this);
  this.CursorPosition = this.innerText.nodeValue.length;
  this.UpdateCursor();
}

//----------------------------------------------------
//     Enter this label from the begining
//----------------------------------------------------
EditableLabel.prototype.EnterFromBegin = function(){
  eq.setFocusTo(this);
  this.CursorPosition = 0;
  this.UpdateCursor();
}

//----------------------------------------------------
//     Key Pressed Event
//----------------------------------------------------
EditableLabel.prototype.KeyPress = function(evt) {
 switch (evt.charCode){
  case 8: // backspace
    if(this.CursorPosition == 1 && this.innerText.nodeValue.length == 1){
      this.parentObject.DeleteChild(this);
    }
    else{
      if (this.CursorPosition > 0){
        // Delete inner char
        this.CursorPosition--;
        eq.EqModified(this.hWnd, this.innerText.nodeValue.charCodeAt(this.CursorPosition), UndoStep.prototype.DELETECHAR, this.CursorPosition);
        this.DeleteCharAt(this.CursorPosition);
        this.UpdateCursor();
      }
      else {
        this.parentObject.SetCursorBefore(this);
        this.parentObject.KeyPress(evt);
      }
    }
    break;
  case 13: // enter
    // Send to parent
    this.Split();
    this.parentObject.SetCursorAfter(this);
    this.parentObject.KeyPress(evt);
    break;
  case 40 : // (
    evt.stopPropagation();
    //check for function
    if (!this.CheckFunction()){
      var splitted = this.Split();
      if ((splitted == this) && (this.innerText.nodeValue.length > 0)){
        this.parentObject.SetCursorAfter(this);
      }
      else {
        splitted.EnterFromBegin();
      }
      newfenced('(', ')');
    }
    break;
  default:
    // insert char into the string, at the curent cursor position
    this.InsertCharAt(evt.charCode);
    eq.EqModified(this.hWnd, evt.charCode, UndoStep.prototype.INSERTCHAR, this.CursorPosition);
    this.CursorPosition++;
    this.UpdateCursor();
    break;
 }
 this.TextChanged();
}

//----------------------------------------------------
//     Key Down Event
//----------------------------------------------------
EditableLabel.prototype.KeyDown = function(evt) {
 switch (evt.keyCode){
  case 127: // delete
    if(this.CursorPosition == 0 && this.innerText.nodeValue.length == 1){
      this.parentObject.DeleteChild(this);
    }
    else{
      if (this.CursorPosition < this.innerText.nodeValue.length){
        // Delete inner char
        eq.EqModified(this.hWnd, this.innerText.nodeValue.charCodeAt(this.CursorPosition), UndoStep.prototype.DELETECHAR, this.CursorPosition);
        this.DeleteCharAt(this.CursorPosition);
      }
      else {
        this.parentObject.SetCursorAfter(this);
        this.parentObject.KeyDown(evt);
      }
    }
    break;
  case 37:  // <- (left arrow)
    if (this.CursorPosition > 0) {
      this.CursorPosition--;
      this.UpdateCursor();
    }
    else{
      this.parentObject.SetCursorBefore(this);
    }
    break;
  case 39:  // -> (right arrow)
    if (this.CursorPosition < this.innerText.length){ 
      this.CursorPosition++;
      this.UpdateCursor();
     }
    else{
      this.parentObject.SetCursorAfter(this);
    }
    break;
  case 33:  // pageUp; select the previous sibling
    this.parentObject.focusPreviousSibling(this);
    break;
  case 34:  // pageDown; select the next sibling
    this.parentObject.focusNextSibling(this);
    break;
  case 35:  // end; go to the end of the text
    this.CursorPosition = this.innerText.length;
    this.UpdateCursor();
    break;
  case 36:  // home; select the parent
      if(this.parentObject != null){
        this.parentObject.EnterFromBegin();
      }
    break;
  case 38:  // up; select the previous EditableLabel
    eq.setFocusTo(this.parentObject.getPreviousLeaf(this));
    break;
  case 40:  // down; select the next EditableLabel
    eq.setFocusTo(this.parentObject.getFollowingLeaf(this));
    break;
  default:
    if (this.parentObject != null){
      this.parentObject.KeyDown(evt);
    }
    break;
 }
}

//----------------------------------------------------
//      Delete the char at the given position
//----------------------------------------------------
EditableLabel.prototype.DeleteCharAt = function(Position) {
  if(!Position && (Position != 0)){
    Position = this.CursorPosition;
  }
  var substr1 = this.innerText.nodeValue.substring(0, Position);
  var substr2 = this.innerText.nodeValue.substring(Position+1);
  this.innerText.nodeValue = substr1 + substr2;
  this.TextChanged();
  delete substr1;
  delete substr2;
}

//----------------------------------------------------
//      Insert a char at the given position
//----------------------------------------------------
EditableLabel.prototype.InsertCharAt = function(InsertedChar, Position) {
  if(!Position && (Position != 0)){
    Position = this.CursorPosition;
  }
  var substr1 = this.innerText.nodeValue.substring(0, Position) + String.fromCharCode(InsertedChar);
  var substr2 = this.innerText.nodeValue.substring(Position);
  this.innerText.nodeValue = substr1 + substr2;
  delete substr1;
  delete substr2;
}

//----------------------------------------------------
//      Update Label text type: number / identifier
//----------------------------------------------------
EditableLabel.prototype.UpdateType = function() {
  this.IsNumber = (parseFloat(this.innerText.nodeValue) == this.innerText.nodeValue);
  this.text.setAttribute('class', this.IsNumber ? 'numelt' : 'textelt');
}

//----------------------------------------------------
//      Check if a function name was typed
//----------------------------------------------------
EditableLabel.prototype.CheckFunction = function() {
  var BeforeCursor = this.innerText.nodeValue.substring(0, this.CursorPosition);
  var FuncType = FunctionType(BeforeCursor);
  if (FuncType == false) return false;
  if (FuncType == 'trig'){
    newtrig(BeforeCursor);
  }
  else if (FuncType == 'lim'){
    newlimit('two-sided');
  }
  eq.EqModified(this.hWnd, this.innerText.nodeValue, UndoStep.prototype.MODIFYTEXT, this.CursorPosition, this.innerText.nodeValue.substring(this.CursorPosition));
  this.innerText.nodeValue =  this.innerText.nodeValue.substring(this.CursorPosition);
  this.CursorPosition = 0;
  this.EnterFromBegin();
  return true;
}

//----------------------------------------------------
//     Split the label in two components
//----------------------------------------------------
EditableLabel.prototype.Split = function(Position) {
  if(!Position){
    Position = this.CursorPosition;
  }
  var textAfter = this.innerText.nodeValue.substring(Position);
  if(textAfter == ''){
    this.parentObject.SetCursorAfter(this);
    return this;
  }
  if(Position == 0){
    this.parentObject.SetCursorBefore(this);
    return this;
  }
  eq.EqModified(this.hWnd, this.innerText.nodeValue, UndoStep.prototype.MODIFYTEXT, this.CursorPosition, this.innerText.nodeValue.substring(0, Position));
  this.innerText.nodeValue = this.innerText.nodeValue.substring(0, Position);
  var LabelAfter = new EditableLabel(null);
  LabelAfter.innerText.nodeValue = textAfter;
  this.parentObject.SetCursorAfter(this);
  this.parentObject.Insert(LabelAfter, true);
  LabelAfter.UpdatePositions();
  LabelAfter.UpdateType();
  this.UpdatePositions();
  this.UpdateType();
  this.parentObject.SetCursorAfter(this); 
  LabelAfter.EnterFromBegin(); 
  return LabelAfter;
}

//----------------------------------------------------
//     Text Changed
//----------------------------------------------------
EditableLabel.prototype.TextChanged = function() {
 if (this.innerText.nodeValue.length > 0){
  if(this.Focused){
    this.frame.setAttribute('class', 'focused');
  }
 }
 else{
  if(this.Focused){ 
    this.frame.setAttribute('class', 'focusedempty');
  }
  this.container.setAttribute('height', this.Scale(DEFAULT_TEXTELEMENT_HEIGHT));
  this.container.setAttribute('width', this.Scale(DEFAULT_TEXTELEMENT_WIDTH));
  this.container.setAttribute('viewBox', '0 0 ' + DEFAULT_TEXTELEMENT_WIDTH + ' ' + DEFAULT_TEXTELEMENT_HEIGHT);

  this.MMLP_Content.nodeValue = '';
  this.TeX_Content.nodeValue = '';
  if(this.parentObject){
    this.parentObject.UpdatePositions();
  }
  eq.Modified();
  return;
 }
 if (this.innerText.nodeValue.length == 1){
  this.UpdateType();
 }
 else if (this.CursorPosition != 0){
   var crPos = this.CursorPosition;
   var LastTypedChar = this.innerText.nodeValue.charCodeAt(crPos - 1);
   var MustSplit = !((this.IsNumber && (parseFloat(this.innerText.nodeValue) == this.innerText.nodeValue)) 
     || ((!this.IsNumber) && IsAlpha(LastTypedChar)));
   if (MustSplit){ 
    this.CursorPosition = 0;
    if (crPos < this.innerText.nodeValue.length){
      var ToFocus = this.Split(crPos);
    }
    var ToFocus = this.Split(crPos - 1);
    this.CursorPosition = crPos - 1;
    ToFocus.EnterFromEnd();
   }
 }
 var size = this.text.getBBox();
 var width = this.text.getComputedTextLength() + 2*MARGIN;
 if(width < DEFAULT_TEXTELEMENT_WIDTH){
  width = DEFAULT_TEXTELEMENT_WIDTH;
 }
 var height = size.y + size.height + MARGIN;
 if(height < DEFAULT_TEXTELEMENT_HEIGHT){
  height = DEFAULT_TEXTELEMENT_HEIGHT;
 }
 this.container.setAttribute('height', this.Scale(height));
 this.container.setAttribute('width', this.Scale(width));
 this.container.setAttribute('viewBox', '0 0 ' + width + ' ' + height);

 if(parseFloat(this.innerText.nodeValue) == this.innerText.nodeValue){
   this.MMLP_Content.nodeValue = '<mn>' + this.innerText.nodeValue + '</mn>';
 }
 else{
   this.MMLP_Content.nodeValue = '<mi>' + this.innerText.nodeValue + '</mi>';
 }
 this.TeX_Content.nodeValue = this.innerText.nodeValue + ' ';

 if(this.parentObject != null){
   this.parentObject.UpdatePositions();
 }
 eq.Modified();
}

//----------------------------------------------------
//    Return the leftmost EditableLabel from this subtree
//  Used by the up key event handler.
//  Return this editable label
//----------------------------------------------------
EditableLabel.prototype.getLeftmostLeaf = function(child){
  eq.StopLeafSearch();
  return this;
}

//----------------------------------------------------
//    Return the rightmost EditableLabel from this subtree 
//  Used by the down key event handler.
//  Return this editable label
//----------------------------------------------------
EditableLabel.prototype.getRightmostLeaf = function(child){
  eq.StopLeafSearch();
  return this;
}

//----------------------------------------------------
//    Update component layout
//----------------------------------------------------
EditableLabel.prototype.UpdatePositions = function(){
 this.TextChanged();
}

//----------------------------------------------------
//     Update Cursor Position   
//----------------------------------------------------
EditableLabel.prototype.UpdateCursor = function(evt) {
 cursor_offset = MARGIN;  
 if (this.CursorPosition > 0){
  if (this.CursorPosition < this.innerText.nodeValue.length){
   cursor_offset = (this.text.getEndPositionOfChar(this.CursorPosition - 1).x + this.text.getStartPositionOfChar(this.CursorPosition).x)/2;
//    cursor_offset = (this.text.getSubStringLength(0, this.CursorPosition)) + MARGIN;
  }
  else if(this.CursorPosition == this.innerText.nodeValue.length){
    cursor_offset = this.text.getEndPositionOfChar(this.CursorPosition - 1).x;
//    cursor_offset = this.text.getSubStringLength(0, this.CursorPosition - 1) + MARGIN;
  }
  else{
    this.CursorPosition = this.innerText.nodeValue.length;
  }
 }
 cursor_offset -= this.Cursor.getAttribute('width')/2;
 this.Cursor.setAttribute('x', cursor_offset);
}

//----------------------------------------------------
//     Loose Cursor    
//----------------------------------------------------
EditableLabel.prototype.LooseCursor = function(evt) {
 if (this.Cursor != null){
  this.container.removeChild(this.Cursor);
  this.Cursor = null;
 }
}

//----------------------------------------------------
//    Get component midline
//----------------------------------------------------
EditableLabel.prototype.GetMidlineY = function() {
 var MeasuredMinu = svgDocument.createTextNode('-');
 var MeasuredMinus = svgDocument.createElement('text');
 MeasuredMinus.appendChild(MeasuredMinu);
 MeasuredMinus.setAttribute('opacity', 0);
 MeasuredMinus.setAttribute('baseline-shift', '-80%');
 MeasuredMinus.setAttribute('y', this.text.getAttribute('y'));
 MeasuredMinus.setAttribute('class', this.text.getAttribute('class'));
 this.container.appendChild(MeasuredMinus);
 var size = MeasuredMinus.getBBox();
 this.container.removeChild(MeasuredMinus);
 delete MeasuredMinu;
 delete MeasuredMinus;
 var MidlineY = size.y + size.height/2;
 delete size;
 return this.Scale(parseFloat(MidlineY));
}

//----------------------------------------------------
//    Export the label as Presentational MathML (<mi> or <mn>)
//----------------------------------------------------
EditableLabel.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent;
  if(parseFloat(this.innerText.nodeValue) == this.innerText.nodeValue){
    return Result + '<mn>' + this.innerText.nodeValue + '</mn>\n';
  }
  else{
    return Result + '<mi>' + this.innerText.nodeValue + '</mi>\n';
  }
}

//----------------------------------------------------
//    Export the label as LaTeX
//----------------------------------------------------
EditableLabel.prototype.ExportLaTeX = function(){
  if (this.innerText.nodeValue.length == 0) return "{}";
  return this.innerText.nodeValue;
}

//----------------------------------------------------
//    Export label as SVG image
//----------------------------------------------------
EditableLabel.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += indent + '  ' + printNode(this.text);
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
EditableLabel.prototype.CreateInstance = function(){
  var copy = new EditableLabel(null, this.ScriptLevelModifier);
  copy.innerText.nodeValue = this.innerText.nodeValue;
  if(this.innerText.nodeValue.length > 0){
    copy.frame.setAttribute('class', 'idle');
  }
  else{
    copy.frame.setAttribute('class', 'idleempty');
  }
  copy.IsNumber = this.IsNumber;
  copy.text.setAttribute('class', this.text.getAttribute('class'));
  return copy;
}