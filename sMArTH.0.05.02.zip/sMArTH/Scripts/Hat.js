/**********************************************
Hat
Hat types:
( [ { ^ | || -> <-> <- -\ -/ . .. ~ 
***********************************************/

Hat.prototype = new Component();
Hat.prototype.constructor = Hat;
//children components indexes 
Hat.prototype.HAT = 0;

function Hat(parentObject, scriptLevelModifier, Type){
 this.Locked = false;
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject = parentObject;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.Type = Type;

 this.MMLP_Preview = MakeTSpan();
 this.MMLP_Content = svgDocument.createTextNode('<mo accent="true">' + this.Type + '</mo>');
 this.MMLP_Preview.appendChild(this.MMLP_Content);

 this.TeX_Preview = MakeTSpan(true);
 if(this.Type == '&rarr;' || this.Type == '&larr;' || this.Type == '&harr;'){
   this.TeX_Content = svgDocument.createTextNode('\\vec');
 }
 else{
   this.TeX_Content = svgDocument.createTextNode(GetLaTeX(this.Type));
 }
 this.TeX_Preview.appendChild(this.TeX_Content);

 this.container = svgDocument.createElement('svg'); 

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //create children components 
 this.childrenObjects = new Array();
 // Make the Hat path
 this.childrenObjects.push(svgDocument.createElement('path'));
 this.childrenObjects[this.HAT].setAttribute('class', 'mathSymbolLine');

 //insert the Hat path in the component
 this.container.appendChild(this.childrenObjects[0]);

 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Hat.prototype.UpdateComponent = function(){
 switch(this.Type){
  case '&OverBar;':
    this.childrenObjects[0].setAttribute('d', this.GetOverbarPath());
    break;
  case '&OverParenthesis;':
    this.childrenObjects[0].setAttribute('d', this.GetOverParenthesisPath());
    break;
  case '&OverBrace;':
    this.childrenObjects[0].setAttribute('d', this.GetOverBracePath());
    break;
  case '&rarr;':
    this.childrenObjects[0].setAttribute('d', this.GetOverRarrPath());
    break;
  case '&harr;':
    this.childrenObjects[0].setAttribute('d', this.GetOverHarrPath());
    break;
  case '&larr;':
    this.childrenObjects[0].setAttribute('d', this.GetOverLarrPath());
    break;
  case '&tilde;':
    this.childrenObjects[0].setAttribute('d', this.GetOverTildePath());
    break;
  case '&Hat;':
    this.childrenObjects[0].setAttribute('d', this.GetOverHatPath());
    break;
  case '&dot;':
    this.childrenObjects[0].setAttribute('d', this.GetOverDotPath());
    break;
  case '&Dot;':
    this.childrenObjects[0].setAttribute('d', this.GetOverDdotPath());
    break;
  default :
    alert('altceva');
 }

 this.container.setAttribute('width', this.Width);
 this.container.setAttribute ('height', DECO_HEIGHT);
}

Hat.prototype.UpdatePositions = function(){
 this.UpdateComponent();
 this.parentObject.UpdatePositions();
}

Hat.prototype.GetOverbarPath = function(){
m = "M 0 " + (DECO_HEIGHT/2) + " H " + this.Width;
return m;
}

Hat.prototype.GetOverParenthesisPath = function(){
/*m = "M " + (LINEWIDTH/2) + " " + DECO_HEIGHT + " a " + (DECO_HEIGHT-LINEWIDTH/2) + " " + (DECO_HEIGHT-LINEWIDTH/2) + " 0 0 1 " + (DECO_HEIGHT-LINEWIDTH/2) + " " + (-(DECO_HEIGHT-LINEWIDTH/2));
m += " H " + (this.Width - DECO_HEIGHT);
m += " a " + (DECO_HEIGHT-LINEWIDTH/2) + " " + (DECO_HEIGHT-LINEWIDTH/2) + " 0 0 1 " + (DECO_HEIGHT-LINEWIDTH/2) + " " + (DECO_HEIGHT-LINEWIDTH/2);*/
var m = "M " + (LINEWIDTH/2) + " " + DECO_HEIGHT;
m += " C " + (LINEWIDTH/2) + " "  + (-(DECO_HEIGHT-LINEWIDTH/2)/3+LINEWIDTH/2) + " " + (this.Width - LINEWIDTH/2) + " "  + (-(DECO_HEIGHT-LINEWIDTH/2)/3+LINEWIDTH/2);
m += " " + (this.Width - LINEWIDTH/2) + " " + DECO_HEIGHT;
return m;
}

Hat.prototype.GetOverBracePath = function(){
var m = "M " + (LINEWIDTH/2) + " " + DECO_HEIGHT + " a " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2) + " 0 0 1 " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (-DECO_HEIGHT/2);
m += " H " + ((this.Width - DECO_HEIGHT + LINEWIDTH)/2);
m += " a " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2) + " 0 0 0 " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (-DECO_HEIGHT/2);
m += " a " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2) + " 0 0 0 " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2);
m += " H " + (this.Width - (DECO_HEIGHT)/2);
m += " a " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2) + " 0 0 1 " + (DECO_HEIGHT/2-LINEWIDTH/2) + " " + (DECO_HEIGHT/2);
return m;
}

Hat.prototype.GetOverRarrPath = function(){
var m = "M 0 " + (DECO_HEIGHT/2) + " H " + this.Width;
m += "m " + (-DECO_HEIGHT) + " " + (-DECO_HEIGHT + LINEWIDTH)/2 + " l " + (DECO_HEIGHT) + " " + (DECO_HEIGHT - LINEWIDTH)/2;
m += " " + (-DECO_HEIGHT) + " " + (DECO_HEIGHT - LINEWIDTH)/2
return m;
}

Hat.prototype.GetOverLarrPath = function(){
var m = "M " + this.Width + " " + (DECO_HEIGHT/2) + " H 0 ";
m += "m " + (DECO_HEIGHT) + " " + (-DECO_HEIGHT + LINEWIDTH)/2 + " l " + (-DECO_HEIGHT) + " " + (DECO_HEIGHT - LINEWIDTH)/2;
m += " " + (DECO_HEIGHT) + " " + (DECO_HEIGHT - LINEWIDTH)/2
return m;
}

Hat.prototype.GetOverHarrPath = function(){
var m = "M " + this.Width + " " + (DECO_HEIGHT/2) + " H 0 ";
m += "m " + (DECO_HEIGHT) + " " + (-DECO_HEIGHT + LINEWIDTH)/2 + " l " + (-DECO_HEIGHT) + " " + (DECO_HEIGHT - LINEWIDTH)/2;
m += " " + (DECO_HEIGHT) + " " + (DECO_HEIGHT - LINEWIDTH)/2
m += " M " + (this.Width-DECO_HEIGHT) + " " + (LINEWIDTH)/2 + " l " + (DECO_HEIGHT) + " " + (DECO_HEIGHT - LINEWIDTH)/2;
m += " " + (-DECO_HEIGHT) + " " + (DECO_HEIGHT - LINEWIDTH)/2
return m;
}

Hat.prototype.GetOverTildePath = function(){
var m = "M " + LINEWIDTH/2 + " " + (DECO_HEIGHT/2);
m += " Q " + this.Width/4 + " " + (-DECO_HEIGHT/2 + LINEWIDTH) + " " + this.Width/2 + " " + DECO_HEIGHT/2;
m += " T " + (this.Width - LINEWIDTH/2) + " " + DECO_HEIGHT/2
return m;
}

Hat.prototype.GetOverHatPath = function(){
var m = "M 0 " + (DECO_HEIGHT - LINEWIDTH/2) + " L " + this.Width/2 + " " + LINEWIDTH/2 + " " + this.Width + " " + (DECO_HEIGHT - LINEWIDTH/2);
return m;
}

Hat.prototype.GetOverDotPath = function(){
var m = "M " + (this.Width - LINEWIDTH)/2 + " " + (DECO_HEIGHT/2) + " a ";
m += LINEWIDTH/2 + " " + LINEWIDTH/2 + " 0 0 0 " + LINEWIDTH + " 0 ";
m += LINEWIDTH/2 + " " + LINEWIDTH/2 + " 0 1 0 " + (-LINEWIDTH) + " 0";
return m;
}

Hat.prototype.GetOverDdotPath = function(){
var m = "M " + ((this.Width - LINEWIDTH)/2 - 3) + " " + (DECO_HEIGHT/2) + " a ";
m += LINEWIDTH/2 + " " + LINEWIDTH/2 + " 0 0 0 " + LINEWIDTH + " 0 ";
m += LINEWIDTH/2 + " " + LINEWIDTH/2 + " 0 1 0 " + (-LINEWIDTH) + " 0";
m += "M " + ((this.Width - LINEWIDTH)/2 + 3) + " " + (DECO_HEIGHT/2) + " a ";
m += LINEWIDTH/2 + " " + LINEWIDTH/2 + " 0 0 0 " + LINEWIDTH + " 0 ";
m += LINEWIDTH/2 + " " + LINEWIDTH/2 + " 0 1 0 " + (-LINEWIDTH) + " 0";
return m;
}


//----------------------------------------------------
//    Export the hat as Presentational MathML ( <mo> )
//----------------------------------------------------
Hat.prototype.ExportPresentationalMathML = function(indent){
  return indent + '<mo accent="true">' + this.Type + '</mo>\n';
}

//----------------------------------------------------
//    Export the Hat as LaTeX
//----------------------------------------------------
Hat.prototype.ExportLaTeX = function(){
 if(this.Type == '&rarr;' || this.Type == '&larr;' || this.Type == '&harr;'){
   return '\\vec';
 }
 else{
   return GetLaTeX(this.Type);
 }
}

//----------------------------------------------------
//    Export hat as SVG image
//----------------------------------------------------
Hat.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += indent + '  ' + printNode(this.childrenObjects[0]) + '\n';
  Result += indent + '</svg>\n';
  return Result;
}