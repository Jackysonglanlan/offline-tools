/**********************************************
Hata (overbars) support
***********************************************/

Hats.prototype = new Component();
Hats.prototype.constructor = Hats;
//children components indexes 
Hats.prototype.ARGUMENT = 0;

function Hats(parentObject, scriptLevelModifier, Type){
 this.Midline = 0;
 this.Locked = false;
 //when created, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject = parentObject;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.Type = Type;

 this.CreateTSpans('mover', 'mover');

 this.container = svgDocument.createElement('svg');

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //insert the frame in the component
 this.container.appendChild(this.frame);

 this.Hat = new Hat(this, 0, Type);
 this.container.appendChild(this.Hat.GetContainer());

 //create children components 
 this.childrenObjects = new Array();
 this.appendChild(new Row(this), this.ARGUMENT, true);
 this.childrenObjects[this.ARGUMENT].appendChild(new EditableLabel(null), 0, true);

 this.MMLP_Content.appendChild(this.childrenObjects[this.ARGUMENT].MMLP_Preview);
 this.MMLP_Content.appendChild(this.Hat.MMLP_Preview);
 this.TeX_Content.appendChild(this.Hat.TeX_Preview);
 this.TeX_Content.appendChild(this.childrenObjects[this.ARGUMENT].TeX_Preview);
 this.TeX_Preview.appendChild(this.TeX_Content);

 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Hats.prototype.UpdatePositions = function(){
 if(this.childrenObjects.length < 1) return;
 var argument_size = this.childrenObjects[this.ARGUMENT].GetSize();
 var argumentMidline = this.childrenObjects[this.ARGUMENT].GetMidlineY();

 var Width = Maximum(argument_size.x, MIN_DECO_WIDTH);
 this.Hat.Width = Width;
 this.Hat.UpdateComponent();
 var hat_size = this.Hat.GetSize();
 var Height = argument_size.y + hat_size.y;

 this.Midline = argumentMidline + hat_size.y;

 this.container.setAttribute('width', this.Scale(Width));
 this.container.setAttribute('height', this.Scale(Height));
 this.container.setAttribute('viewBox', '0 0 ' + Width + ' ' + Height);

 this.childrenObjects[this.ARGUMENT].container.setAttribute('x', (Width - argument_size.x)/2);
 this.childrenObjects[this.ARGUMENT].container.setAttribute('y', hat_size.y);
 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the Hats as Presentational MathML ( <mover> )
//----------------------------------------------------
Hats.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent + '<mover>\n';
  Result += this.childrenObjects[this.ARGUMENT].ExportPresentationalMathML(indent + '  ');
  Result += this.Hat.ExportPresentationalMathML(indent + '  ');
  Result += indent + '</mover>\n';
  return Result;
}

//----------------------------------------------------
//    Export the Hats as LaTeX
//----------------------------------------------------
Hats.prototype.ExportLaTeX = function(){
  var Result = this.Hat.ExportLaTeX() + ' ';
  Result += this.childrenObjects[this.ARGUMENT].ExportLaTeX();
  return Result;
}

//----------------------------------------------------
//    Export hat component as SVG image
//----------------------------------------------------
Hats.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += this.Hat.ExportSVGNode(indent + '  ');
  Result += this.childrenObjects[0].ExportSVGNode(indent + '  ');
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Hats.prototype.CreateInstance = function(){
  return new Hats(null, this.ScriptLevelModifier, this.Type);
}
