/*******************************************
Initialisations
********************************************/

//----------------------------------------------------
//     initialize
//----------------------------------------------------
function initialize(){
  if ( window.svgDocument == null ){
    svgDocument = evt.target.ownerDocument;
  }
 eq = new EQContainer();
 scroller = new Scroller('scroller', null, WORK_AREA_WIDTH, WORK_AREA_HEIGHT, 'eqContainerGroup');
 eq.makeRootElement();
 scroller.Target = eq.getRootElement().container;
 scroller.FocusCursor = true;
 eq.setFocusTo(eq.getRootElement().childrenObjects[0].childrenObjects[0]);
 loadToolbars();
 loadPreviews();
 CheckPHP();
}

//----------------------------------------------------
//     IsAlpha
//----------------------------------------------------
function IsAlpha(charCode){
 if (charCode >= 65 && charCode <=  90) return true;
 if (charCode >= 97 && charCode <= 122) return true;
 return false;
}
//----------------------------------------------------
//     IsNum
//----------------------------------------------------
function IsNum(charCode){
 if (charCode >= 48 && charCode <=  57) return true;
 return false;
}

//----------------------------------------------------
//     IsAlNum
//----------------------------------------------------
function IsAlNum(charCode){
 return (IsAlpha(charCode) || IsNum(charCode));
}

//----------------------------------------------------
//     Compute the minimum of 2 numbers
//----------------------------------------------------
function Minimum(Param1, Param2){
 return parseFloat((Param1 < Param2) ? Param1 : Param2);
}

//----------------------------------------------------
//     Compute the maximum of 2 numbers
//----------------------------------------------------
function Maximum(Param1, Param2){
 return parseFloat((Param1 > Param2) ? Param1 : Param2);
}

//----------------------------------------------------
//     Return the Unicode character from it's encoding
//----------------------------------------------------
function GetUnicode(Encoding){
 return parseXML('<text>' + Encoding + '</text>', document).childNodes.item(0).childNodes.item(0).nodeValue;
}

//----------------------------------------------------
//     Create a tspan element
//----------------------------------------------------
function MakeTSpan(dontRestart){
 var tspan = svgDocument.createElement('tspan');
 if(!dontRestart){
   tspan.setAttribute('x', PREVIEW_TSPAN_X);
   tspan.setAttribute('dy', PREVIEW_TSPAN_DY);
 }
 else{
//   tspan.setAttribute('dx', 2);
 }
 return tspan;
}

//----------------------------------------------------
//     Check if the param is a function name 
//----------------------------------------------------
function FunctionType(string){
 if (string == 'sin' || string == 'cos' || string == 'tan' || string == 'sec' || string == 'csc' || string == 'cot'
  || string == 'sinh' || string == 'cosh' || string == 'tanh' || string == 'sech' || string == 'csch' || string == 'coth'
  || string == 'arcsin' || string == 'arccos' || string == 'arctan' || string == 'arcsec' || string == 'arccsc' || string == 'arccot'
  || string == 'arcsinh' || string == 'arccosh' || string == 'arctanh' || string == 'arcsech' || string == 'arccsch' || string == 'arccoth')
  return 'trig';
 if (string == 'lim')
  return string;
 return false;
}

//----------------------------------------------------
//     Return the width of a space 
//----------------------------------------------------
function GetSpaceWidth(string){
  if((this.displayedText == '&ThinSpace;') || (this.displayedText == '&#x02009;')){
    return '0.2em';
  }
  if((this.displayedText == '&VeryThinSpace;') || (this.displayedText == '&#x0200A;')){
    return '0.1em';
  }
//    (this.displayedText == '&NegativeThinSpace;') || (this.displayedText == '&#x0200B;') ||
//    (this.displayedText == '&NegativeThickSpace;') || (this.displayedText == '&#NegativeMediumSpace;')){
}