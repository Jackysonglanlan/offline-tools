/**********************************************
Binary Operator
***********************************************/

BinaryOp.prototype = new Component();
BinaryOp.prototype.constructor = BinaryOp;

//children components indexes 
BinaryOp.prototype.LEFT = 0;
BinaryOp.prototype.OP = 1;
BinaryOp.prototype.RIGHT = 2;

function BinaryOp(parentObject, scriptLevelModifier, Operator){
  //when creted, this component notifies the component manager
  this.hWnd = eq.registerWindow(this);
  //the object should remember its parent
  this.parentObject     = parentObject;
  this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
  this.Operator = Operator;
  this.Midline = 0;
  this.Locked = false;

  this.CreateTSpans('mrow', 'mrow');

  this.container = svgDocument.createElement('svg');

  var TeXTspan = MakeTSpan(true);
  TeXTspan.appendChild(document.createTextNode(' { '));
  this.TeX_Preview.appendChild(TeXTspan);
  this.TeX_Preview.appendChild(this.TeX_Content);
  TeXTspan = MakeTSpan(true);
  TeXTspan.appendChild(document.createTextNode('} '));
  this.TeX_Preview.appendChild(TeXTspan);

  //create the component outer frame
  this.frame = svgDocument.createElement('rect');
  this.frame.setAttribute('width', '100%');
  this.frame.setAttribute('height', '100%');

  //set the component status to idle
  this.frame.setAttribute('class', 'idle');

  //insert the frame in the component
  this.container.appendChild(this.frame);
  
  //create children components 
  this.childrenObjects = new Array();

  this.appendChild(new Row(this), this.LEFT, true);
  this.InsertTSpanFor(this.childrenObjects[this.LEFT]);
  this.childrenObjects[this.LEFT].appendChild(new EditableLabel(null), 0, true);

  this.appendChild(new Row(this), this.OP, true);
  this.InsertTSpanFor(this.childrenObjects[this.OP]);
  this.childrenObjects[this.OP].appendChild(new StaticLabel(null, 0, this.Operator), 0, true);

  this.appendChild(new Row(this), this.RIGHT, true);
  this.InsertTSpanFor(this.childrenObjects[this.RIGHT]);
  this.childrenObjects[this.RIGHT].appendChild(new EditableLabel(null), 0, true);

  this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
BinaryOp.prototype.UpdatePositions = function(){
 if(this.childrenObjects.length < 3) return;
 // Compute children's boundingboxes
 var left_size  = this.childrenObjects[this.LEFT].GetSize();
 var op_size    = this.childrenObjects[this.OP].GetSize();
 var right_size = this.childrenObjects[this.RIGHT].GetSize();

 // Compute children's midline positions
 var LeftMidline = this.childrenObjects[this.LEFT].GetMidlineY();
 var OpMidline = this.childrenObjects[this.OP].GetMidlineY();
 var RightMidline = this.childrenObjects[this.RIGHT].GetMidlineY();

 // Compute global midline
 this.Midline = Maximum(Maximum(LeftMidline, OpMidline), RightMidline);

 var width = left_size.x + op_size.x + right_size.x + 4*MARGIN;
 var height = Maximum(Maximum(left_size.y + this.Midline - LeftMidline, op_size.y + this.Midline - OpMidline),
    right_size.y + this.Midline - RightMidline);

 this.container.setAttribute('width', this.Scale(width));
 this.container.setAttribute('height', this.Scale(height));
 this.container.setAttribute('viewBox', '0 0 ' + width + ' ' + height);

 this.childrenObjects[this.LEFT].container.setAttribute('x', MARGIN);
 this.childrenObjects[this.OP].container.setAttribute('x', 2*MARGIN + left_size.x);
 this.childrenObjects[this.RIGHT].container.setAttribute('x', 3*MARGIN + left_size.x + op_size.x);

 this.childrenObjects[this.LEFT].container.setAttribute('y', this.Midline - LeftMidline);
 this.childrenObjects[this.OP].container.setAttribute('y', this.Midline - OpMidline);
 this.childrenObjects[this.RIGHT].container.setAttribute('y', this.Midline - RightMidline);

 if(this.parentObject != null){
  this.parentObject.UpdatePositions();
 }
}

//----------------------------------------------------
//    Export the operator as Presentational MathML
//----------------------------------------------------
BinaryOp.prototype.ExportPresentationalMathML = function(indent){
  var Result = indent + '<mrow>\n';
  Result += this.childrenObjects[this.LEFT].ExportPresentationalMathML(indent + '  ');
  Result += this.childrenObjects[this.OP].ExportPresentationalMathML(indent + '  ');
  Result += this.childrenObjects[this.RIGHT].ExportPresentationalMathML(indent + '  ');
  Result += indent + '</mrow>\n';
  return Result;
}

//----------------------------------------------------
//    Export the operator as LaTeX
//----------------------------------------------------
BinaryOp.prototype.ExportLaTeX = function(){
  var Result = '{';
  Result += this.childrenObjects[this.LEFT].ExportLaTeX() + ' ';
  Result += this.childrenObjects[this.OP].ExportLaTeX() + ' ';
  Result += this.childrenObjects[this.RIGHT].ExportLaTeX();
  Result += '}';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
BinaryOp.prototype.CreateInstance = function(){
  return new BinaryOp(null, this.ScriptLevelModifier, this.Operator);
}
