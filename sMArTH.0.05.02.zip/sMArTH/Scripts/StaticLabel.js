/***********************************************
 Static Label

 <g width="width" height="height">
  <rect x="0" y="0" width="width" height="height" stroke="#000" fill="none" stroke-width="1"/>
  <text></text>
 </g>
************************************************/

StaticLabel.prototype = new Component();
StaticLabel.prototype.constructor = StaticLabel;
StaticLabel.prototype.OPERATOR = 1;
StaticLabel.prototype.IDENTIFIER = 2;
StaticLabel.prototype.MTEXT = 3;
StaticLabel.prototype.FUNCTION = 4;

//----------------------------------------------------
//     StaticLabel Constructor
//----------------------------------------------------
function StaticLabel(parentObject, scriptLevelModifier, operator, ContentType){
 this.Midline = 0;
 this.Locked = false;
 //when creted, this component notifies the component manager
 this.hWnd = eq.registerWindow(this);
 //the object should remember its parent
 this.parentObject = parentObject;
 this.displayedText = operator;
 this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
 this.ContentType = (ContentType ? ContentType : this.OPERATOR);

 //the component is an internal svg
 this.container = svgDocument.createElement('svg');
 //set the component's location / size
 this.container.setAttribute('width', DEFAULT_TEXTELEMENT_WIDTH);
 this.container.setAttribute('height', DEFAULT_TEXTELEMENT_HEIGHT);

 //create the component outer frame
 this.frame = svgDocument.createElement('rect');
 this.frame.setAttribute('width', '100%');
 this.frame.setAttribute('height', '100%');

 //set the component status to idle
 this.frame.setAttribute('class', 'idle');

 //create the component's text element
 this.text = svgDocument.createElement('text');
 this.text.setAttribute('baseline-shift', '-80%');
 this.text.setAttribute('class', 'Operator');
 if(!this.IsPrime){
  this.text.setAttribute('x', MARGIN);
 }
 this.text.setAttribute('y', MARGIN);
 if((this.displayedText == '&ApplyFunction;') || (this.displayedText == '&#x02061;') ||
    (this.displayedText == '&InvisibleTimes;') || (this.displayedText == '&#x02062;')){
   this.innerText = svgDocument.createTextNode('');
   this.IsInvisible = true;
 }
 else if((this.displayedText == '&ThinSpace;') || (this.displayedText == '&#x02009;') ||
    (this.displayedText == '&VeryThinSpace;') || (this.displayedText == '&#x0200A;')){
  this.IsSpace = true;
 }
 else if((this.displayedText == '&NegativeThinSpace;') || (this.displayedText == '&#x0200B;') ||
    (this.displayedText == '&NegativeThickSpace;') || (this.displayedText == '&NegativeMediumSpace;')){
  this.IsNegativeSpace = true;
 }
 else if((this.displayedText == '&prime;') || (this.displayedText == '&#02032;') ||
    (this.displayedText == '&Prime;') || (this.displayedText == '&#02033;')){
  this.IsPrime = true;
  this.innerText = svgDocument.createTextNode(GetUnicode(GetEncoding(this.displayedText)));
 }
 else{
   this.innerText = svgDocument.createTextNode(GetUnicode(GetEncoding(this.displayedText)));
 }
 this.text.appendChild(this.innerText);
 this.container.appendChild(this.text);
 this.childrenObjects = new Array();

 //insert the frame in the component
 this.container.appendChild(this.frame);

 //set the mouse / key event handlers
 this.container.setAttribute('onkeypress', 'eq.eqKeyPress(evt)');
 this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
 this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');

 this.UpdatePositions();

 this.MMLP_Content = svgDocument.createTextNode(this.ExportPresentationalMathML(''));
 this.MMLP_Preview = MakeTSpan();
 this.MMLP_Preview.appendChild(this.MMLP_Content);

  this.TeX_Preview = MakeTSpan(true);
    this.TeX_Content = svgDocument.createTextNode(this.ExportLaTeX());
  this.TeX_Preview.appendChild(this.TeX_Content);
}

//----------------------------------------------------
//     This component takes the place of an existing
//    component and incorporates it
//----------------------------------------------------
StaticLabel.prototype.ReplaceChild = function(replaced){
 this.parentObject = replaced.parentObject;
 this.ScriptLevelModifier = replaced.ScriptLevelModifier;
 this.parentObject.ReplaceChildWith(replaced, this);
 eq.setFocusTo(this);
 this.UpdatePositions();
}

//----------------------------------------------------
//     Replace the first child with the given component
//----------------------------------------------------
StaticLabel.prototype.ReplaceFirst = function(Replacer){
  this.UpdatePositions();
  if (this.parentObject) eq.setFocusTo(this.parentObject);
  else eq.setFocusTo(this);
}

//----------------------------------------------------
//     Enter this component from the end
//----------------------------------------------------
StaticLabel.prototype.EnterFromEnd = function(){
  this.parentObject.SetCursorBefore(this);
}

//----------------------------------------------------
//     Enter this component from the begining
//----------------------------------------------------
StaticLabel.prototype.EnterFromBegin = function(){
  this.parentObject.SetCursorAfter(this);
}

//----------------------------------------------------
//    Update component layout
//----------------------------------------------------
StaticLabel.prototype.UpdatePositions = function(){
  if (this.IsInvisible){
    this.text.setAttribute('y', MARGIN);
    this.container.setAttribute('width', 0);
    this.container.setAttribute('height', this.Scale(DEFAULT_TEXTELEMENT_HEIGHT));
    this.container.setAttribute('viewBox', '0 0 0 ' + DEFAULT_TEXTELEMENT_HEIGHT);
    if(this.parentObject != null){
      this.parentObject.UpdatePositions();
    }
    return;
  }
  if (this.IsSpace){
    this.text.setAttribute('y', MARGIN);
    this.container.setAttribute('width', 3);
    this.container.setAttribute('height', this.Scale(DEFAULT_TEXTELEMENT_HEIGHT));
    this.container.setAttribute('viewBox', '0 0 3 ' + DEFAULT_TEXTELEMENT_HEIGHT);
    if(this.parentObject != null){
      this.parentObject.UpdatePositions();
    }
    return;
  }
  if (this.IsNegativeSpace){
    this.text.setAttribute('y', MARGIN);
//    this.container.setAttribute('width', 0);
    this.container.setAttribute('width', '-3');
    this.container.setAttribute('height', this.Scale(DEFAULT_TEXTELEMENT_HEIGHT));
    this.container.setAttribute('viewBox', '0 0 0 ' + DEFAULT_TEXTELEMENT_HEIGHT);
    if(this.parentObject != null){
      this.parentObject.UpdatePositions();
    }
    return;
  }
  this.text.setAttribute('y', MARGIN);
  var size = this.text.getBBox();
  if(this.IsPrime){
    var width = this.text.getComputedTextLength() + MARGIN;
  }
  else{
    var width = this.text.getComputedTextLength() + 2*MARGIN;
  }
  if(width < DEFAULT_TEXTELEMENT_WIDTH){
    width = DEFAULT_TEXTELEMENT_WIDTH;
  }

  var height = Math.abs(size.y) + size.height + MARGIN;
  if(height < DEFAULT_TEXTELEMENT_HEIGHT){
    height = DEFAULT_TEXTELEMENT_HEIGHT;
  }
  if (size.y < 0){
    this.text.setAttribute('y', Math.abs(size.y) + MARGIN);
  }

  this.text.setAttribute('y', MARGIN);
  this.container.setAttribute('width', this.Scale(width));
  this.container.setAttribute('height', this.Scale(height));
  this.container.setAttribute('viewBox', '0 0 ' + width + ' ' + height);

  if(this.parentObject != null){
    this.parentObject.UpdatePositions();
  }
}

//----------------------------------------------------
//    Get component midline
//----------------------------------------------------
StaticLabel.prototype.GetMidlineY = function() {
 var MeasuredMinu = svgDocument.createTextNode('-');
 var MeasuredMinus = svgDocument.createElement('text');
 MeasuredMinus.appendChild(MeasuredMinu);
 MeasuredMinus.setAttribute('opacity', 0);
 MeasuredMinus.setAttribute('baseline-shift', '-80%');
 MeasuredMinus.setAttribute('y', this.text.getAttribute('y'));
 MeasuredMinus.setAttribute('class', this.text.getAttribute('class'));
 this.container.appendChild(MeasuredMinus);
 var size = MeasuredMinus.getBBox();
 this.container.removeChild(MeasuredMinus);
 delete MeasuredMinu;
 delete MeasuredMinus;
 var MidlineY = size.y + size.height/2;
 delete size;
 return this.Scale(parseFloat(MidlineY));
}

//----------------------------------------------------
//    Export the label as Presentational MathML (<mo>, <mi> or <mn>)
//----------------------------------------------------
StaticLabel.prototype.ExportPresentationalMathML = function(indent){
  if(this.ContentType == this.OPERATOR){
    return indent + '<mo>' + this.displayedText + '</mo>\n';
  }
  else if((this.ContentType == this.IDENTIFIER) || (this.ContentType == this.FUNCTION)){
    return indent + '<mi>' + this.displayedText + '</mi>\n';
  }
  else if(this.ContentType == this.MTEXT){
    return indent + '<mtext>' + this.displayedText + '</mtext>\n';
  }
}

//----------------------------------------------------
//    Export the label as LaTeX
//----------------------------------------------------
StaticLabel.prototype.ExportLaTeX = function(){
//  if (this.innerText.nodeValue.length == 0) return "{}";
  if(this.ContentType == this.FUNCTION){
    return '\\' + this.displayedText;
  }
  return GetLaTeX(this.displayedText);
}

//----------------------------------------------------
//    Export label as SVG image
//----------------------------------------------------
StaticLabel.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += indent + '  ' + printNode(this.text);
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
StaticLabel.prototype.CreateInstance = function(){
  var copy = new StaticLabel(null, this.ScriptLevelModifier, this.displayedText);
  copy.OperatorType = this.OperatorType;
  copy.text.setAttribute('class', this.text.getAttribute('class'));
  copy.ContentType = this.ContentType;
  return copy;
}