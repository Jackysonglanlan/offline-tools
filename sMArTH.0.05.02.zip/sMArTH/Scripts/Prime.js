/**********************************************
Prime
***********************************************/

Prime.prototype = new Component();
Prime.prototype.constructor = Prime;
//children components indexes 
Prime.prototype.ARGUMENT = 0;

function Prime(parentObject, scriptLevelModifier, Type){
  this.Midline = 0;
  this.Locked = false;
  this.ScriptLevelModifier = (scriptLevelModifier ? scriptLevelModifier : 0);
  this.Type = Type;

  // When created, this component notifies the component manager
  this.hWnd = eq.registerWindow(this);
  // The object should remember its parent
  this.parentObject = parentObject;

  this.MMLP_Content = MakeTSpan();
  this.MMLP_Preview = MakeTSpan();
  this.MMLP_Preview.appendChild(this.MMLP_Content);
  this.MMLP_Prime = MakeTSpan();
  this.MMLP_Prime.appendChild(document.createTextNode('<mo>' + this.Type + '</mo>'));
  this.MMLP_Preview.appendChild(this.MMLP_Prime);

  this.TeX_Preview = MakeTSpan(true);
  this.TeX_Content = MakeTSpan(true);
  this.TeX_Preview.appendChild(this.TeX_Content);

  this.TeXPrime = MakeTSpan(true);
  this.TeXPrime.appendChild(document.createTextNode(GetLaTeX(this.Type) + ' '));
  this.TeX_Preview.appendChild(this.TeXPrime);

  this.container = svgDocument.createElement('svg');

  //create the component outer frame
  this.frame = svgDocument.createElement('rect');
  this.frame.setAttribute('width', '100%');
  this.frame.setAttribute('height', '100%');

  //set the component status to idle
  this.frame.setAttribute('class', 'idle');

  //insert the frame in the component
  this.container.appendChild(this.frame);

  //Draw the symbol
  this.PrimeSymbol = svgDocument.createElement('text');
  this.PrimeSymbol.setAttribute('class', 'numelt');
  this.PrimeSymbol.appendChild(svgDocument.createTextNode(GetUnicode(GetEncoding(this.Type))));
  this.PrimeSymbol.setAttribute('baseline-shift', '-80%');

  //insert the Prime symbol in the component
  this.container.appendChild(this.PrimeSymbol);

  //create children components
  this.childrenObjects = new Array();
  this.appendChild(new Row(this), this.ARGUMENT, true);

  this.childrenObjects[this.ARGUMENT].appendChild(new EditableLabel(this.childrenObjects[this.BASE]), 0, true);
  this.container.setAttribute('onclick', 'eq.eqMouseClick(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseover', 'eq.eqMouseOver(evt, ' + this.hWnd + ')');
  this.container.setAttribute('onmouseout', 'eq.eqMouseOut(evt, ' + this.hWnd + ')');

  this.MMLP_Content.appendChild(this.childrenObjects[this.ARGUMENT].MMLP_Preview);
}

//----------------------------------------------------
//     Update component layout
//----------------------------------------------------
Prime.prototype.UpdatePositions = function(){
  if(this.childrenObjects.length < 1) return;
  var base_size = this.childrenObjects[this.ARGUMENT].GetSize();
  this.PrimeSymbol.setAttribute('x', base_size.x);
  var Width = base_size.x + this.PrimeSymbol.getBBox().width + MARGIN;
  var Height = base_size.y;

  this.container.setAttribute ('width', this.Scale(Width));
  this.container.setAttribute ('height', this.Scale(Height));
  this.container.setAttribute('viewBox', '0 0 ' + Width + ' ' + Height);

  this.Midline = this.childrenObjects[this.ARGUMENT].GetMidlineY();

  if(this.parentObject != null){
    this.parentObject.UpdatePositions();
  }
}

//----------------------------------------------------
//    Export the Prime as Presentational MathML (<mPrime>)
//----------------------------------------------------
Prime.prototype.ExportPresentationalMathML = function(indent){
  var Result = this.childrenObjects[this.ARGUMENT].ExportPresentationalMathML(indent);
  Result += indent + '<mo>' + this.Type + '</mo>\n';
  return Result;
}

//----------------------------------------------------
//    Export the Prime as LaTeX
//----------------------------------------------------
Prime.prototype.ExportLaTeX = function(){
  var Result = this.childrenObjects[this.ARGUMENT].ExportLaTeX();
  Result += GetLaTeX(this.Type) + ' ';
  return Result;
}

//----------------------------------------------------
//    Export Prime as SVG image
//----------------------------------------------------
Prime.prototype.ExportSVGNode = function(indent){
  var Result = this.ExportSVGNodeBeginTag(indent);
  Result += this.childrenObjects[this.ARGUMENT].ExportSVGNode(indent);
  Result += indent + printNode(this.PrimeSymbol);
  Result += indent + '</svg>\n';
  return Result;
}

//----------------------------------------------------
//    Create a new instance
//----------------------------------------------------
Prime.prototype.CreateInstance = function(){
  return new Prime(null, this.ScriptLevelModifier, this.Type);
}
