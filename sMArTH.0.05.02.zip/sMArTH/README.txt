sMArTH 0.05

Sergiu Dumitriu <sdumitriu@infoiasi.ro>
Marta Girdea <marta@infoiasi.ro>
Catalin Hritcu <donald@infoiasi.ro>

sMArTH is an equation editor for MathML and LaTeX built on open Web
standards. The editor itself uses a SVG interface and the application
logic is implemented in ECMAScript using the DOM. Both MathML and LaTeX
are supported as exporting formats in addition to the SVG format. The
most important mathematical content from both LaTeX and MathML is
already provided. The graphical user interface allows even the most
complex equations to be built with simple 'Point and Click' techniques
instead of writing convoluted typesetting code.

System Requirements
You will need a SVG Viewer and a Unicode Font to be able to run sMArTH
properly. Because it is a web application based on a collection of open
standards, sMArTH is not tied to one particular implementation, vendor
or authoring tool. However, not all standards we employ are in
widespread use at this time, so we recommend you the tools that work
best with our application:

Recommended SVG Viewer: Adobe SVG Viewer (freeware)
Link:  http://www.adobe.com/svg/viewer/install/main.html

Recommended Unicode Font: Code2000 (shareware)
Link: http://home.att.net/~jameskass/CODE2000.ZIP

Although sMArTH is a Web application you can also run it on your own
machine. However, in order for this to work you will need to access it
through a Web server with support for PHP. We recommend you the
well-known open source Apache HTTP Server. If you are using Apache HTTP,
once you have transferred sMArTH to your local machine you will only
need to extract it to your htdocs directory and than access
http://localhost/sMArTH.svg. If you try to run sMArTH locally but this
prerequisite is not fulfilled you will not be able to save your
equations.

For additional documentation please consult the user manual in the "doc"
directory or on the sMArTH website: http://smarth.sourceforge.net


Copyright (C) 2004-2005

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.
