/*************************************
Toolbar loader
**************************************/

//----------------------------------------------------
//     Make a HTTP request for the XML file in which
//  the toolbars are defined
//----------------------------------------------------
function loadToolbars(){
  // Retrieve the XML definition of the toolbars
  getURL('Toolbars/toolbars.xml', buildToolbars);
}

//----------------------------------------------------
//     When the XML file content is available,
//  parse the file and build the toolbars
//----------------------------------------------------
function buildToolbars(data){
  // An error could have occured, so first we have to check
  // if the request was succesful
  if (data.success){
    // Parse the XML content and build a DOM tree
    var ToolbarsDefinitionRoot = parseXML(data.content, document).childNodes.item(0);
    // Append the DOM tree to the document, so that getElementById can be called
    svgDocument.appendChild(ToolbarsDefinitionRoot);

    // The toolbar will be inserted in this SVGSVGElement
    var ToolbarSVGElement = document.getElementById('Toolbar');

    // The file consists of more toolbars (button groups).
    // Retrieve all theese toolbars in a NodeList 
    var ToolbarItems = ToolbarsDefinitionRoot.getElementsByTagName('toolbar');
    // The number of toolbars
    var ToolbarCount = ToolbarItems.length;
    // For some strange reason, Adobe SVGViewer sometimes returns null
    // when working directly with the NodeList, so we make a copy of it
    var ToolbarItemsArray = new Array();
    for(var i = 0; i < ToolbarCount; i++){
      ToolbarItemsArray[i] = ToolbarItems.item(i);
    }

    // Toolbar layout
    var ToolbarAreaHeight = TOOLBAR_AREA_HEIGHT; // Total height of the toolbar area
    var ToolbarWidth = 116; // The width of the toolbar
    var ActivatorHeight = 26; // The height of each activator
    var ToolbarDistance = ActivatorHeight + 2; // The distance between two collapsed activators
    var SlideDuration = 0.3; // The duration of a sliding
    var HighlightDuration = 0.1; // The duration of a highlight
    var ButtonAreaHeight = ToolbarAreaHeight - ToolbarCount * ToolbarDistance; // The height of the button area
    var ToolbarHeight = ToolbarAreaHeight - (ToolbarCount - 1) * ToolbarDistance; // The height of an expanded toolbar
    // Button layout
/*    var ButtonWidth = 28; // The width of each button
    var ButtonHeight = 25; // The height of each button
    var ButtonsPerRow = 4; // The number of buttons on each row
*/
    var ButtonWidth = 38; // The width of each button
    var ButtonHeight = 30; // The height of each button
    var ButtonsPerRow = 3; // The number of buttons on each row

    // The default opened toolbar
    var DefaultActiveToolbar = 0;
    eq.SetCrtActionStatus(
      ToolbarItemsArray[DefaultActiveToolbar].getElementsByTagName('description').item(0).childNodes.item(0).nodeValue
    );

    // Parse each toolbar
    for(var i = 0; i < ToolbarCount; i++){
      // The <toolbar> element in the XML file
      var ToolbarDefinition = ToolbarItemsArray[i];

      // The unique ID of the toolbar
      var ToolbarID = ToolbarDefinition.getAttribute('id');
      var PreviousToolbarID = (i > 0) ? ToolbarItemsArray[i-1].getAttribute('id') : '';
      var NextToolbarID = (i < ToolbarCount - 1) ? ToolbarItemsArray[i+1].getAttribute('id') : '';

      // Each toolbar is represented as a SVGSVGElement
      var Toolbar = svgDocument.createElement('svg');
      // Set the various attributes of this element
      Toolbar.setAttribute('id', ToolbarID);
      Toolbar.setAttribute('width', ToolbarWidth);
      Toolbar.setAttribute('height', ToolbarHeight);
      if(i <= DefaultActiveToolbar){
        Toolbar.setAttribute('y', i * ToolbarDistance);
      }
      else{
        Toolbar.setAttribute('y', ToolbarAreaHeight - (ToolbarCount - i) * ToolbarDistance);
      }
      Toolbar.setAttribute('x', 0);

      // Create SlideUp and SlideDown <animate> elements.
      if(i > 0){
        // The first toolbar activator never slides

        /*
        // For another strange reason, adding the <animate> elements
        // using DOM doesn't activate the onbegin attribute
        var SlideDownAnimate = svgDocument.createElement('animate');
        ToolbarActivator.appendChild(SlideDownAnimate);
        SlideDownAnimate.setAttribute('id', ToolbarID + 'SlideDown');
        SlideDownAnimate.setAttribute('attributeName', 'y');
        SlideDownAnimate.setAttribute('begin', PreviousToolbarID + 'Activator.click;' + PreviousToolbarID + 'SlideDown.begin');
        SlideDownAnimate.setAttribute('to', 646 - (ToolbarCount - i) * 32);
        SlideDownAnimate.setAttribute('fill', 'freeze');
        SlideDownAnimate.setAttribute('dur', '0.3');
        SlideDownAnimate.setAttribute('onbegin', "onSlideDown('" + ToolbarID + "')");
        */

        // SlideDown -> moves the toolbar element down
        var SlideDownstr = "<set id='" + ToolbarID + "SlideDown' ";
        // The animated attribute is y, because we only need to move the element down
        SlideDownstr += "attributeName='y' ";
        // The toolbar moves down
        // when it is up and when the previous toolbar is expanding or
        // when it is up and the previous toolbar is also sliding down
        if(i <= DefaultActiveToolbar){
          SlideDownstr += "begin='" + PreviousToolbarID + "MouseEventSensor.click;" + PreviousToolbarID + "SlideDown.begin' ";
        }
        else{
          SlideDownstr += "begin='indefinite' ";
        }
        // The Down position
        SlideDownstr += "to='" + (ToolbarAreaHeight - (ToolbarCount - i) * ToolbarDistance) + "' ";
        SlideDownstr += "fill='freeze' dur='" + SlideDuration + "' ";
        // When the sliding begins, disable the slide down animation and enable the slide up animation
        SlideDownstr += "onbegin='onSlideDown(\"" + ToolbarID + "\", " + i + ((i < ToolbarCount - 1) ? ", \"" + NextToolbarID + "\"" : "") + ")' />";
        // Parse the string and append the resulting <animate> element to the toolbar
        var SlideDownAnimate = parseXML(SlideDownstr, svgDocument);
        Toolbar.appendChild(SlideDownAnimate);

        // SlideUp -> moves the toolbar element up
        var SlideUpstr = "<set id='" + ToolbarID + "SlideUp' ";
        // The animated attribute is y, because we only need to move the element up
        SlideUpstr += "attributeName='y' ";
        // The toolbar moves up
        // when it is down and when the toolbar is expanding or
        // when it is down and the next toolbar is also sliding up
        if(i > DefaultActiveToolbar){
          SlideUpstr += "begin='" + ToolbarID + "MouseEventSensor.click";
          if(i < ToolbarCount - 1){
            SlideUpstr += ";" + NextToolbarID + "SlideUp.begin";
          }
          SlideUpstr += "' "; 
        }
        else{
          SlideUpstr += "begin='indefinite' ";
        }
        // The Up position
        SlideUpstr += "to='" + (i * ToolbarDistance) + "' ";
        SlideUpstr += "fill='freeze' dur='" + SlideDuration + "' ";
        // When the sliding begins, disable the slide up animation and enable the slide down animation
        SlideUpstr += "onbegin='onSlideUp(\"" + ToolbarID + "\", " + i + ", \"" + PreviousToolbarID + "\")' />";
        // Parse the string and append the resulting <animate> element to the toolbar
        var SlideUpAnimate = parseXML(SlideUpstr, svgDocument);
        Toolbar.appendChild(SlideUpAnimate);
      }

      // Each toolbar has an Activator (button) which opens the button area
      var Activator = svgDocument.createElement('svg');
      Activator.setAttribute('id', ToolbarID + 'Activator');
      Activator.setAttribute('width', ToolbarWidth);
      Activator.setAttribute('height', ActivatorHeight);
      Activator.setAttribute('x', 0);
      Activator.setAttribute('y', 0);

      // Create a highlight effect when the mouse moves over this activator
      // by modifying the opacity of a white background
      var Background = svgDocument.createElement('rect');
      Background.setAttribute('width', '116');
      Background.setAttribute('height', '30');
      Background.setAttribute('class', 'ActivatorBackground');
      Background.setAttribute('opacity', '0');

      // Increase the opacity of the background when the mouse enters the activator area
      var UnfadeAnimate = svgDocument.createElement('set');
      UnfadeAnimate.setAttribute('attributeName', 'opacity');
      UnfadeAnimate.setAttribute('begin', ToolbarID + 'MouseEventSensor.mouseover');
      UnfadeAnimate.setAttribute('to', '0.3');
      UnfadeAnimate.setAttribute('fill', 'freeze');
      UnfadeAnimate.setAttribute('dur', HighlightDuration);
      Background.appendChild(UnfadeAnimate);
      // Decrease the opacity of the background when the mouse leaves the activator area
      var FadeAnimate = svgDocument.createElement('set');
      FadeAnimate.setAttribute('attributeName', 'opacity');
      FadeAnimate.setAttribute('begin', ToolbarID + 'MouseEventSensor.mouseout');
      FadeAnimate.setAttribute('to', '0');
      FadeAnimate.setAttribute('fill', 'freeze');
      FadeAnimate.setAttribute('dur', HighlightDuration);
      Background.appendChild(FadeAnimate);

      // Add the background to the activator
      Activator.appendChild(Background);

      // Create a 3D effect with two paths on the border
      var TopLeftBorder = svgDocument.createElement('path');
      TopLeftBorder.setAttribute('d', 'M 0 ' + ActivatorHeight + ' v -' + ActivatorHeight + ' h ' + ToolbarWidth);
      TopLeftBorder.setAttribute('class', 'RaisedBorderTopLeft');
      Activator.appendChild(TopLeftBorder);
      var BottomRightBorder = svgDocument.createElement('path');
      BottomRightBorder.setAttribute('d', 'M 0 ' + ActivatorHeight + ' h ' + ToolbarWidth + ' v -' + ActivatorHeight);
      BottomRightBorder.setAttribute('class', 'RaisedBorderBottomRight');
      Activator.appendChild(BottomRightBorder);

      // Add the image on the activator of this toolbar

      /*
      // Another flaw: cannot create an <image> using DOM
      var ActivatorImage = svgDocument.createElement('image');
      ActivatorImage.setAttributeNS('xlink', 'xlink:href', toolbar.getElementsByTagName('image').item(0).childNodes.item(0).nodeValue);
      ActivatorImage.setAttribute('width', ToolbarWidth);
      ActivatorImage.setAttribute('height', ActivatorHeight);
      */

      var ImageElements = ToolbarDefinition.getElementsByTagName('image');
      var ImageDefinition = 'ActivatorImages/DefaultImage.svg';
      if(ImageElements.length > 0){
        ImageDefinition = ImageElements.item(0).childNodes.item(0).nodeValue;
      }
      var ActivatorImagestr = "<image xlink:href='" + ImageDefinition + "' ";
      ActivatorImagestr += "width='" + ToolbarWidth + "' height='" + ActivatorHeight + "' />"
      var ActivatorImage = parseXML(ActivatorImagestr, svgDocument);
      Activator.appendChild(ActivatorImage);

      // Create an invisible rect that receives the mouse events;
      // if the svg itself receives this events, a lot of mouseover/mouseout events
      // will be genereated when the mouse moves from one inner element to another.
      var MouseEventSensor = svgDocument.createElement('rect');
      MouseEventSensor.setAttribute('id', ToolbarID + 'MouseEventSensor');
      MouseEventSensor.setAttribute('width', ToolbarWidth);
      MouseEventSensor.setAttribute('height', ActivatorHeight);
      MouseEventSensor.setAttribute('class', 'MouseEventSensor');
      MouseEventSensor.setAttribute('onmouseover', 
        'eq.SetToolTipStatus("' + ToolbarDefinition.getElementsByTagName('tooltip').item(0).childNodes.item(0).nodeValue + '");');
      MouseEventSensor.setAttribute('onclick', 
        'eq.SetCrtActionStatus("' + ToolbarDefinition.getElementsByTagName('description').item(0).childNodes.item(0).nodeValue + '");');
      MouseEventSensor.setAttribute('onmouseout', 'eq.RestoreStatus()');
      Activator.appendChild(MouseEventSensor);

      // Add the activator to the toolbar SVGSVGElement
      Toolbar.appendChild(Activator);

      /////////////////////////////////////////////////////
      // Create the button area
      var ToolbarButtons = svgDocument.createElement('svg');
      ToolbarButtons.setAttribute('id', ToolbarID + 'ButtonArea');
      ToolbarButtons.setAttribute('width', ToolbarWidth);
      // The opened toolbar is expanded, the ButtonArea has its normal height
      if(i == DefaultActiveToolbar){
        ToolbarButtons.setAttribute('height', ButtonAreaHeight);
      }
      // Closed toolbars just hide the ButtonArea by setting the height to 0
      else{
        ToolbarButtons.setAttribute('height', 0);
      }
      ToolbarButtons.setAttribute('x', 0);
      ToolbarButtons.setAttribute('y', (ToolbarDistance + ActivatorHeight)/2);

      // Create a 3D effect with two paths on the border
      var TopLeftButtonBorder = svgDocument.createElement('path');
      TopLeftButtonBorder.setAttribute('d', 'M 0 ' + ButtonAreaHeight + ' v -' + ButtonAreaHeight + ' h ' + ToolbarWidth);
      TopLeftButtonBorder.setAttribute('class', 'SunkenBorderTopLeft');
      ToolbarButtons.appendChild(TopLeftButtonBorder);
      var BottomRightButtonBorder = svgDocument.createElement('path');
      BottomRightButtonBorder.setAttribute('d', 'M 0 ' + ButtonAreaHeight + ' h ' + ToolbarWidth + ' v -' + ButtonAreaHeight);
      BottomRightButtonBorder.setAttribute('class', 'SunkenBorderBottomRight');
      ToolbarButtons.appendChild(BottomRightButtonBorder);

      // Expanding and collapsing the button area is done by animating the height of the SVGSVGElement
      var ShowButtonsstr = "<set id='" + ToolbarID + "ShowButtons' ";
      ShowButtonsstr += "attributeName='height' ";
      // The Button area expands when the user clicks the Activator
      ShowButtonsstr += "begin='" + ToolbarID + "MouseEventSensor.click' ";
      ShowButtonsstr += "to='" + (ButtonAreaHeight) + "' ";
      ShowButtonsstr += "fill='freeze' dur='" + SlideDuration + "' ";
      ShowButtonsstr += "onbegin='onShowButtons(\"" + ToolbarID + ((i < ToolbarCount - 1) ? "\", \"" + NextToolbarID + "\")'/>" : "\")'/>");
      var ShowButtonsAnimate = parseXML(ShowButtonsstr, svgDocument);
      ToolbarButtons.appendChild(ShowButtonsAnimate);

      var HideButtonsstr = "<set id='" + ToolbarID + "HideButtons' ";
      HideButtonsstr += "attributeName='height' ";
      // The Button area collapses when
      // the button area is expanded and the toolbar starts sliding down or when
      // the button area is expanded and the following toolbar is sliding up
      if(i == DefaultActiveToolbar){
        HideButtonsstr += "begin='" + ToolbarID + "SlideDown.begin";
        if(i < ToolbarCount - 1){
          HideButtonsstr += ";" + NextToolbarID + "SlideUp.begin";
        }
      }
      else{
        HideButtonsstr += "begin='indefinite";
      }
      HideButtonsstr += "' to='0' ";
      HideButtonsstr += "fill='freeze' dur='" + SlideDuration + "' ";
      HideButtonsstr += "onbegin='onHideButtons(\"" + ToolbarID + "\")'/>";
      var HideButtonsAnimate = parseXML(HideButtonsstr, svgDocument);
      ToolbarButtons.appendChild(HideButtonsAnimate);

      // Parse each button reference and add the button to the buton area
      var ButtonDefinitions = ToolbarDefinition.getElementsByTagName('buttonRef');
      for(var j = 0; j < ButtonDefinitions.length; j++){
        // The Button ID in the XML file
        var ButtonRefID = ButtonDefinitions.item(j).getAttribute('idref');
        // The resulting Button ID is obtained by prefixing the Button ID with the parent Toolbar ID
        var ButtonID = ToolbarID + ButtonRefID;
        // The <buttonDef> element in the XML file
        var ButtonDefinition = document.getElementById(ButtonRefID);

        // Each button is represented as a SVGGElement
        var Button = svgDocument.createElement('g');
        Button.setAttribute('id', ButtonID);
        // Move the button to the right position in a grid, filled left to right and top to bottom
        Button.setAttribute('transform', 'translate(' + (2+(j%ButtonsPerRow)*ButtonWidth) + 
            ', ' + (2+Math.floor(j/ButtonsPerRow)*ButtonHeight) + ')');

        // Create a 3D effect with two paths on the border
        ButtonBorder = svgDocument.createElement('g');
        ButtonBorder.setAttribute('id', ButtonID + 'Border');
        ButtonBorder.setAttribute('opacity', 0);
        ButtonBorder.setAttribute('fill', 'none');

        var ButtonTopLeft = svgDocument.createElement('path');
        ButtonTopLeft.setAttribute('d', "M 0 " + (ButtonHeight-1) + " v -" + (ButtonHeight-1) + " h " + (ButtonWidth-1));
        ButtonTopLeft.setAttribute('class', 'RaisedBorderTopLeft');
        // Add the path to the border
        ButtonBorder.appendChild(ButtonTopLeft);

        var ButtonBottomRight = svgDocument.createElement('path');
        ButtonBottomRight.setAttribute('d', "M -0.5 " + (ButtonHeight) + " h " + (ButtonWidth+0.5) + " v -" + (ButtonHeight+0.5));
        ButtonBottomRight.setAttribute('class', 'RaisedBorderBottomRight');
        // Add the path to the border
        ButtonBorder.appendChild(ButtonBottomRight);

        // Create a highlight effect when the mouse moves over this button
        // by modifying the opacity of the border
        // Show the border when the mouse enters the button
        var ShowBorderStr = "<set id='" + ButtonID + "ShowBorder' attributeName='opacity' begin='" + 
          ButtonID + "MouseSensor.mouseover' to='1' fill='freeze'/>";
        ButtonBorder.appendChild(parseXML(ShowBorderStr, svgDocument));
        // Hide the border when the mouse leaves the button
        var HideBorderStr = "<set id='" + ButtonID + "HideBorder' attributeName='opacity' begin='" + 
          ButtonID + "MouseSensor.mouseout' to='0' fill='freeze'/>";
        ButtonBorder.appendChild(parseXML(HideBorderStr, svgDocument));

        // Add the border to the button
        Button.appendChild(ButtonBorder);

        // Add the image on the button
        var ButtonImage = parseXML("<image xlink:href='" + ButtonDefinition.getElementsByTagName('image').item(0).childNodes.item(0).nodeValue +
            "' width='" + ButtonWidth + "' height='" + ButtonHeight + "' />", svgDocument);
        Button.appendChild(ButtonImage);

        // Create an invisible rect that receives the mouse events
        var MouseSensor = svgDocument.createElement('rect');
        MouseSensor.setAttribute('width', ButtonWidth);
        MouseSensor.setAttribute('height', ButtonHeight);
        MouseSensor.setAttribute('id', ButtonID + 'MouseSensor');
        MouseSensor.setAttribute('class', 'MouseEventSensor');
        // When the user clicks the button, execute the code in the <action> element
        MouseSensor.setAttribute('onclick', ButtonDefinition.getElementsByTagName('action').item(0).childNodes.item(0).nodeValue);
        MouseSensor.setAttribute('onmouseover', 
          'eq.SetToolTipStatus("' + ButtonDefinition.getElementsByTagName('tooltip').item(0).childNodes.item(0).nodeValue + '");');
        MouseSensor.setAttribute('onmouseout', 'eq.RestoreStatus()');
        Button.appendChild(MouseSensor);

        // Add the button to the button area
        ToolbarButtons.appendChild(Button);
      }

      // Add the button area to the toolbar
      Toolbar.appendChild(ToolbarButtons);
      
      // Add the toolbar to the toolbar area in the SVG
      ToolbarSVGElement.appendChild(Toolbar);
    }
    // Remove the XML DOM tree from the SVGDocument
    svgDocument.removeChild(ToolbarsDefinitionRoot);
  }
  else{
    // An error occured
    alert('Failed to load toolbars');
  }
}

// When the slide down begins, disable the slide down animation and enable the slide up animation 
function onSlideDown(ToolbarID, Position, NextToolbarID){
 var Animate = document.getElementById(ToolbarID + 'SlideDown');
 Animate.setAttribute('begin', 'indefinite');
 Animate = document.getElementById(ToolbarID + 'SlideUp');
 if(arguments.length == 3){
   Animate.setAttribute('begin', ToolbarID + "MouseEventSensor.click;" + NextToolbarID + "SlideUp.begin");
 }
 else{
   Animate.setAttribute('begin', ToolbarID + "MouseEventSensor.click");
 }
}

// When the slide up begins, disable the slide up animation and enable the slide down animation
function onSlideUp(ToolbarID, Position, PreviousToolbarID){
 var Animate = document.getElementById(ToolbarID + 'SlideUp');
 Animate.setAttribute('begin', 'indefinite');
 Animate = document.getElementById(ToolbarID + 'SlideDown');
 Animate.setAttribute('begin', PreviousToolbarID + "MouseEventSensor.click;" + PreviousToolbarID + "SlideDown.begin");
}

// When the button area is expanded, disable the expand animation and enable the collapse animation
function onShowButtons(ToolbarID, NextToolbarID){
 var Animate = document.getElementById(ToolbarID + 'ShowButtons');
 Animate.setAttribute('begin', 'indefinite');
 Animate = document.getElementById(ToolbarID + 'HideButtons');
 if(arguments.length == 2){
    Animate.setAttribute('begin', ToolbarID + "SlideDown.begin;" + NextToolbarID + "SlideUp.begin");
 }
 else{
    Animate.setAttribute('begin', ToolbarID + "SlideDown.begin");
 }
}

// When the button area is collapsed, disable the collapse animation and enable the expand animation
function onHideButtons(ToolbarID){
 var Animate = document.getElementById(ToolbarID + 'HideButtons');
 Animate.setAttribute('begin', 'indefinite');
 Animate = document.getElementById(ToolbarID + 'ShowButtons');
 Animate.setAttribute('begin', ToolbarID + "MouseEventSensor.click");
}