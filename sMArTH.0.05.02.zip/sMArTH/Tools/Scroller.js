/***********************************************
Scroller
Handles workspace scrolling
************************************************/

function Scroller(GlobalName, Target, WIDTH, HEIGHT, ContainerID){
 this.GlobalName = GlobalName;
 this.Target = Target;
 this.TargetWidth = WIDTH;
 this.TargetHeight = HEIGHT;
 this.FocusCursor = false;
 // Generate Scrollbars
 

 // VERTICAL SCROLLBAR

 this.vScroll = svgDocument.createElement('g');
 this.vScroll.setAttribute('transform', 'translate(' + (this.TargetWidth - SCROLLBAR_WIDTH) + ', 0)');
 this.vScroll.setAttribute('id', 'vScroll');
 this.vScroll.setAttribute('display', 'none');
 
 this.UpBtn = svgDocument.createElement('g');
 this.UpBtnBk = svgDocument.createElement('rect');
 this.UpBtnBk.setAttribute('class', 'ScrollBt');
 this.UpBtnBk.setAttribute('width', SCROLLBAR_WIDTH);
 this.UpBtnBk.setAttribute('y', 0.5);
 this.UpBtnBk.setAttribute('height', SCROLLBAR_WIDTH-1);
 this.UpBtn.appendChild(this.UpBtnBk);
 this.UpBtnTopLeft = svgDocument.createElement('path');
 this.UpBtnTopLeft.setAttribute('class', 'RaisedBorderTopLeft');
 this.UpBtnTopLeft.setAttribute('d', "M 0 " + (SCROLLBAR_WIDTH-1) + " V 0.5 h " + SCROLLBAR_WIDTH);
 this.UpBtn.appendChild(this.UpBtnTopLeft);
 this.UpBtnBottomRight = svgDocument.createElement('path');
 this.UpBtnBottomRight.setAttribute('class', 'RaisedBorderBottomRight');
 this.UpBtnBottomRight.setAttribute('d', "M 0 " + (SCROLLBAR_WIDTH-1) + " h " + SCROLLBAR_WIDTH + " V 0.5");
 this.UpBtn.appendChild(this.UpBtnBottomRight);
 this.UpBtn.setAttribute('onmousedown', this.GlobalName+'.UpBtnMouseDown()');
 var UpArr = svgDocument.createElement('path');
 UpArr.setAttribute('class', 'ScrollArr');
 UpArr.setAttribute('d', 'M ' + SCROLLBAR_WIDTH/2 + ' ' + SCROLLBAR_WIDTH/4 + ' l ' + (-SCROLLBAR_WIDTH/4) + ' ' + SCROLLBAR_WIDTH/2 +
  ' h ' +  SCROLLBAR_WIDTH/2 + ' z');
 this.UpBtn.appendChild(UpArr);
 
 this.DownBtn = svgDocument.createElement('g');
 this.DownBtn.setAttribute('transform', 'translate(0, ' + (this.TargetHeight - SCROLLBAR_WIDTH) + ')');
 this.DownBtnBk = svgDocument.createElement('rect');
 this.DownBtnBk.setAttribute('class', 'ScrollBt');
 this.DownBtnBk.setAttribute('width', SCROLLBAR_WIDTH);
 this.DownBtnBk.setAttribute('y', 0.5);
 this.DownBtnBk.setAttribute('height', SCROLLBAR_WIDTH-1);
 this.DownBtn.appendChild(this.DownBtnBk);
 this.DownBtnTopLeft = svgDocument.createElement('path');
 this.DownBtnTopLeft.setAttribute('class', 'RaisedBorderTopLeft');
 this.DownBtnTopLeft.setAttribute('d', "M 0 " + (SCROLLBAR_WIDTH-1) + " V 0.5 h " + SCROLLBAR_WIDTH);
 this.DownBtn.appendChild(this.DownBtnTopLeft);
 this.DownBtnBottomRight = svgDocument.createElement('path');
 this.DownBtnBottomRight.setAttribute('class', 'RaisedBorderBottomRight');
 this.DownBtnBottomRight.setAttribute('d', "M 0 " + (SCROLLBAR_WIDTH-1) + " h " + SCROLLBAR_WIDTH + " V 0.5");
 this.DownBtn.appendChild(this.DownBtnBottomRight);
 this.DownBtn.setAttribute('onmousedown', this.GlobalName+'.DownBtnMouseDown()');
 var DownArr = svgDocument.createElement('path');
 DownArr.setAttribute('class', 'ScrollArr');
 DownArr.setAttribute('d', 'M ' + SCROLLBAR_WIDTH/2 + ' ' + 3*SCROLLBAR_WIDTH/4 + ' l ' + (-SCROLLBAR_WIDTH/4) + ' ' + (-SCROLLBAR_WIDTH/2) +
  ' h ' +  SCROLLBAR_WIDTH/2 + ' z');
 this.DownBtn.appendChild(DownArr);

 this.vScrollB = svgDocument.createElement('g');
 this.vScrollB.setAttribute('transform', 'translate(0, ' + SCROLLBAR_WIDTH + ')');
 this.vScroll.appendChild(this.vScrollB);
 
 this.vScrollBk = svgDocument.createElement('rect');
 this.vScrollBk.setAttribute('id', 'vScrollBk');
 this.vScrollBk.setAttribute('class', 'ScrollBk');
 this.vScrollBk.setAttribute('width', SCROLLBAR_WIDTH);
 this.vScrollBk.setAttribute('height', this.TargetHeight - SCROLLBAR_WIDTH);
 this.vScrollB.appendChild(this.vScrollBk);

 this.vScrollBt = svgDocument.createElement('g');

 this.vScrollBtBk = svgDocument.createElement('rect');
 this.vScrollBtBk.setAttribute('class', 'ScrollBt');
 this.vScrollBtBk.setAttribute('width', SCROLLBAR_WIDTH);
 this.vScrollBtBk.setAttribute('height', SCROLLBAR_MIN_LENGTH);
 
 this.vScrollBtTopLeft = svgDocument.createElement('path');
 this.vScrollBtTopLeft.setAttribute('class', 'RaisedBorderTopLeft');
 this.vScrollBtTopLeft.setAttribute('d', "M 0 " + SCROLLBAR_MIN_LENGTH + " v " + (-SCROLLBAR_MIN_LENGTH) + " h " + SCROLLBAR_WIDTH);

 this.vScrollBtBottomRight = svgDocument.createElement('path');
 this.vScrollBtBottomRight.setAttribute('class', 'RaisedBorderBottomRight');
 this.vScrollBtBottomRight.setAttribute('d', "M 0 " + SCROLLBAR_MIN_LENGTH + " h " + SCROLLBAR_WIDTH + " v " + (-SCROLLBAR_MIN_LENGTH));
 
 this.vScrollBt.appendChild(this.vScrollBtBk);
 this.vScrollBt.appendChild(this.vScrollBtTopLeft);
 this.vScrollBt.appendChild(this.vScrollBtBottomRight);

 this.vScrollB.appendChild(this.vScrollBt);
 this.vScroll.appendChild(this.UpBtn);
 this.vScroll.appendChild(this.DownBtn);
 this.vScrollBt.setAttribute('onmousedown', this.GlobalName+'.vScrollBtMouseDown(evt)');

 this.workspace = svgDocument.getElementById('eqContainerGroup');
 this.workspace.appendChild(this.vScroll);
 
 // HORIZONTAL SCROLLBAR

 this.hScroll = svgDocument.createElement('g');
 this.hScroll.setAttribute('transform', 'translate(0, ' + (this.TargetHeight - SCROLLBAR_WIDTH) + ')');
 this.hScroll.setAttribute('id', 'hScroll');
 this.hScroll.setAttribute('display', 'none');
 
 this.LeftBtn = svgDocument.createElement('g');
 this.LeftBtnBk = svgDocument.createElement('rect');
 this.LeftBtnBk.setAttribute('class', 'ScrollBt');
 this.LeftBtnBk.setAttribute('x', 0.5);
 this.LeftBtnBk.setAttribute('width', SCROLLBAR_WIDTH-1);
 this.LeftBtnBk.setAttribute('height', SCROLLBAR_WIDTH);
 this.LeftBtn.appendChild(this.LeftBtnBk);
 this.LeftBtnTopLeft = svgDocument.createElement('path');
 this.LeftBtnTopLeft.setAttribute('class', 'RaisedBorderTopLeft');
 this.LeftBtnTopLeft.setAttribute('d', "M 0.5 " + SCROLLBAR_WIDTH + " V 0 h " + (SCROLLBAR_WIDTH-1));
 this.LeftBtn.appendChild(this.LeftBtnTopLeft);
 this.LeftBtnBottomRight = svgDocument.createElement('path');
 this.LeftBtnBottomRight.setAttribute('class', 'RaisedBorderBottomRight');
 this.LeftBtnBottomRight.setAttribute('d', "M 0.5 " + SCROLLBAR_WIDTH + " h " + (SCROLLBAR_WIDTH-1) + " V 0");
 this.LeftBtn.appendChild(this.LeftBtnBottomRight);
 this.LeftBtn.setAttribute('onmousedown', this.GlobalName+'.LeftBtnMouseDown()');
 var LeftArr = svgDocument.createElement('path');
 LeftArr.setAttribute('class', 'ScrollArr');
 LeftArr.setAttribute('d', 'M ' + SCROLLBAR_WIDTH/4 + ' ' + SCROLLBAR_WIDTH/2 + ' l ' + SCROLLBAR_WIDTH/2 + ' ' +(-SCROLLBAR_WIDTH/4) +
  ' v ' +  SCROLLBAR_WIDTH/2 + ' z');
 this.LeftBtn.appendChild(LeftArr);

 this.RightBtn = svgDocument.createElement('g');
 this.RightBtn.setAttribute('transform', 'translate(' + (this.TargetWidth - SCROLLBAR_WIDTH) + ', 0)');
 this.RightBtnBk = svgDocument.createElement('rect');
 this.RightBtnBk.setAttribute('class', 'ScrollBt');
 this.RightBtnBk.setAttribute('x', 0.5);
 this.RightBtnBk.setAttribute('width', SCROLLBAR_WIDTH-1);
 this.RightBtnBk.setAttribute('height', SCROLLBAR_WIDTH);
 this.RightBtn.appendChild(this.RightBtnBk);
 this.RightBtnTopLeft = svgDocument.createElement('path');
 this.RightBtnTopLeft.setAttribute('class', 'RaisedBorderTopLeft');
 this.RightBtnTopLeft.setAttribute('d', "M 0.5 " + SCROLLBAR_WIDTH + " V 0 h " + (SCROLLBAR_WIDTH-1));
 this.RightBtn.appendChild(this.RightBtnTopLeft);
 this.RightBtnBottomRight = svgDocument.createElement('path');
 this.RightBtnBottomRight.setAttribute('class', 'RaisedBorderBottomRight');
 this.RightBtnBottomRight.setAttribute('d', "M 0.5 " + SCROLLBAR_WIDTH + " h " + (SCROLLBAR_WIDTH-1) + " V 0");
 this.RightBtn.appendChild(this.RightBtnBottomRight);
 this.RightBtn.setAttribute('onmousedown', this.GlobalName+'.RightBtnMouseDown()');
 var RightArr = svgDocument.createElement('path');
 RightArr.setAttribute('class', 'ScrollArr');
 RightArr.setAttribute('d', 'M ' + 3*SCROLLBAR_WIDTH/4 + ' ' + SCROLLBAR_WIDTH/2 + ' l ' + (-SCROLLBAR_WIDTH/2) + ' ' +(-SCROLLBAR_WIDTH/4) +
  ' v ' +  SCROLLBAR_WIDTH/2 + ' z');
 this.RightBtn.appendChild(RightArr);
 
 this.hScrollB = svgDocument.createElement('g');
 this.hScrollB.setAttribute('transform', 'translate(' + SCROLLBAR_WIDTH + ', 0)');
 this.hScroll.appendChild(this.hScrollB);
 
 this.hScrollBk = svgDocument.createElement('rect');
 this.hScrollBk.setAttribute('id', 'hScrollBk');
 this.hScrollBk.setAttribute('class', 'ScrollBk');
 this.hScrollBk.setAttribute('width', this.TargetWidth - SCROLLBAR_WIDTH);
 this.hScrollBk.setAttribute('height', SCROLLBAR_WIDTH);
 this.hScrollB.appendChild(this.hScrollBk);
 
 this.hScrollBt = svgDocument.createElement('g');
 
 this.hScrollBtBk = svgDocument.createElement('rect');
 this.hScrollBtBk.setAttribute('class', 'ScrollBt');
 this.hScrollBtBk.setAttribute('width', SCROLLBAR_MIN_LENGTH);
 this.hScrollBtBk.setAttribute('height', SCROLLBAR_WIDTH);
 
 this.hScrollBtTopLeft = svgDocument.createElement('path');
 this.hScrollBtTopLeft.setAttribute('class', 'RaisedBorderTopLeft');
 this.hScrollBtTopLeft.setAttribute('d', "M 0 " + SCROLLBAR_WIDTH + " v " + (-SCROLLBAR_WIDTH) + " h " + SCROLLBAR_MIN_LENGTH);

 this.hScrollBtBottomRight = svgDocument.createElement('path');
 this.hScrollBtBottomRight.setAttribute('class', 'RaisedBorderBottomRight');
 this.hScrollBtBottomRight.setAttribute('d', "M 0 " + SCROLLBAR_WIDTH + " h " + SCROLLBAR_MIN_LENGTH + " v " + (-SCROLLBAR_WIDTH));
 
 this.hScrollBt.appendChild(this.hScrollBtBk);
 this.hScrollBt.appendChild(this.hScrollBtTopLeft);
 this.hScrollBt.appendChild(this.hScrollBtBottomRight);

 this.hScrollB.appendChild(this.hScrollBt);
 this.hScroll.appendChild(this.LeftBtn);
 this.hScroll.appendChild(this.RightBtn);
 this.hScrollBt.setAttribute('onmousedown', this.GlobalName+'.hScrollBtMouseDown(evt)');

 this.MeetRect = svgDocument.createElement('rect');
 this.MeetRect.setAttribute('class', 'ScrollBk');
 this.MeetRect.setAttribute('width', SCROLLBAR_WIDTH);
 this.MeetRect.setAttribute('height', SCROLLBAR_WIDTH);
 this.MeetRect.setAttribute('x', this.TargetWidth-SCROLLBAR_WIDTH);
 this.MeetRect.setAttribute('y', this.TargetHeight-SCROLLBAR_WIDTH);
 this.MeetRect.setAttribute('display', 'none');

 this.hScroll.setAttribute('onclick', 'evt.stopPropagation()');
 this.vScroll.setAttribute('onclick', 'evt.stopPropagation()');
 this.workspace = svgDocument.getElementById(ContainerID);
 this.workspace.appendChild(this.hScroll);
 this.workspace.appendChild(this.vScroll);
 this.workspace.appendChild(this.MeetRect);
}

//----------------------------------------------------
//    The user presses the mouse button on the horizontal scroll button
//----------------------------------------------------
Scroller.prototype.hScrollBtMouseDown = function(evt){
  this.clickX = ScreenToClient(this.hScrollBt, evt).x
  eq.Dragging = this;
  this.scrolling = 'h';
  evt.stopPropagation();
}

//----------------------------------------------------
//    The user presses the mouse button on the vertical scroll button
//----------------------------------------------------
Scroller.prototype.vScrollBtMouseDown = function(evt){
  this.clickY = ScreenToClient(this.vScrollBt, evt).y
  eq.Dragging = this;
  this.scrolling = 'v';
  evt.stopPropagation();
}

//----------------------------------------------------
//    Mouse dragging
//----------------------------------------------------
Scroller.prototype.MouseMove = function (evt){
  if(this.scrolling == 'h'){
    var newx = ScreenToClient(this.hScroll, evt).x;
    var btnx = Maximum(0, newx - this.clickX);
    btnx = Minimum(btnx, parseFloat(this.hScrollBk.getAttribute('width')) - parseFloat(this.hScrollBtBk.getAttribute('width')));
    this.hScrollBt.setAttribute('transform', 'translate(' + btnx + ', 0)');
    this.TranslateViewBoxX(btnx / parseFloat(this.hScrollBk.getAttribute('width')));
  }
  else if(this.scrolling == 'v'){
    var newy = ScreenToClient(this.vScroll, evt).y;
    var btny = Maximum(0, newy - this.clickY);
    btny = Minimum(btny, parseFloat(this.vScrollBk.getAttribute('height')) - parseFloat(this.vScrollBtBk.getAttribute('height')));
    this.vScrollBt.setAttribute('transform', 'translate(0, ' + btny + ')');
    this.TranslateViewBoxY(btny / parseFloat(this.vScrollBk.getAttribute('height')));
  }
  evt.stopPropagation();
}

//----------------------------------------------------
//    The user presses the scroll left arrow
//----------------------------------------------------
Scroller.prototype.LeftBtnMouseDown = function(){
  var transform = this.hScrollBt.getAttribute('transform');
  var btnx = parseFloat(transform.substring(transform.indexOf('(')+1, transform.indexOf(',')));
  var newx = Maximum(0, btnx - SCROLL_DELTA);
  this.hScrollBt.setAttribute('transform', 'translate(' + newx + ', 0)');
  this.TranslateViewBoxX(newx / parseFloat(this.hScrollBk.getAttribute('width')));
}

//----------------------------------------------------
//    The user presses the scroll right arrow
//----------------------------------------------------
Scroller.prototype.RightBtnMouseDown = function(){
  var transform = this.hScrollBt.getAttribute('transform');
  var btnx = parseFloat(transform.substring(transform.indexOf('(')+1, transform.indexOf(',')));
  var newx = Minimum(btnx + SCROLL_DELTA,
      parseFloat(this.hScrollBk.getAttribute('width')) - parseFloat(this.hScrollBtBk.getAttribute('width')));
  this.hScrollBt.setAttribute('transform', 'translate(' + newx + ', 0)');
  this.TranslateViewBoxX(newx / parseFloat(this.hScrollBk.getAttribute('width')));
}

//----------------------------------------------------
//    The user presses the scroll up arrow
//----------------------------------------------------
Scroller.prototype.UpBtnMouseDown = function(){
  var transform = this.vScrollBt.getAttribute('transform');
  var btny = parseFloat(transform.substring(transform.indexOf(' ')+1, transform.indexOf(')')));
  var newy = Maximum(0, btny - SCROLL_DELTA);
  this.vScrollBt.setAttribute('transform', 'translate(0, ' + newy + ')');
  this.TranslateViewBoxY(newy / parseFloat(this.vScrollBk.getAttribute('height')));
}

//----------------------------------------------------
//    The user presses the scroll down arrow
//----------------------------------------------------
Scroller.prototype.DownBtnMouseDown = function(){
  var transform = this.vScrollBt.getAttribute('transform');
  var btny = parseFloat(transform.substring(transform.indexOf(' ')+1, transform.indexOf(')')));
  var newy = Minimum(btny + SCROLL_DELTA,
      parseFloat(this.vScrollBk.getAttribute('height')) - parseFloat(this.vScrollBtBk.getAttribute('height')));
  this.vScrollBt.setAttribute('transform', 'translate(0, ' + newy + ')');
  this.TranslateViewBoxY(newy / parseFloat(this.vScrollBk.getAttribute('height')));
}

//----------------------------------------------------
//    Update scrollbar
//----------------------------------------------------
Scroller.prototype.UpdateScrollbars = function (workareaBBox, viewBox){
  this.PutInside(viewBox, workareaBBox);
  if(this.FocusCursor){
    var Point1 = svgDocument.documentElement.createSVGPoint();
    Point1.x = -1;
    if(eq.getFocusedElement() && eq.getFocusedElement().Cursor){
      Point1.x = parseFloat(eq.getFocusedElement().Cursor.getAttribute('x'));
      Point1.y = 0;
      var Point2 = svgDocument.documentElement.createSVGPoint();
      Point2.x = Point1.x;
      Point2.y = Point1.y + parseFloat(eq.getFocusedElement().container.getAttribute('height'));
      Point1 = ClientToScreen(eq.getFocusedElement().container, Point1);
      Point2 = ClientToScreen(eq.getFocusedElement().container, Point2);
    }
    if(Point1.x != -1){
      viewBox = this.EnsureVisible(Point1, Point2);
    }
  }
/*  else{
  document.getElementById('newmenu').childNodes.item(0).nodeValue = ('wa: ' + workareaBBox.x + " " + workareaBBox.y + " " + workareaBBox.width + " " + workareaBBox.height + " " +
    'vb: ' + viewBox.x + " " + viewBox.y + " " + viewBox.width + " " + viewBox.height);
  }*/
  if(((workareaBBox.width > (viewBox.width - SCROLLBAR_WIDTH)) && (workareaBBox.height > (viewBox.height - SCROLLBAR_WIDTH))) ||
     (workareaBBox.width > viewBox.width)){
   if (workareaBBox.height > viewBox.height - SCROLLBAR_WIDTH){
     var bkwidth = viewBox.width - 3*SCROLLBAR_WIDTH
     this.hScrollBk.setAttribute('width', bkwidth);
     this.RightBtn.setAttribute('transform', 'translate(' + (this.TargetWidth - 2*SCROLLBAR_WIDTH) + ', 0)');
     var hScrollWidth = Maximum(SCROLLBAR_MIN_LENGTH,
        ((viewBox.width-SCROLLBAR_WIDTH) * bkwidth / workareaBBox.width));
     var hScrollX = (viewBox.x * bkwidth / workareaBBox.width);
     this.hScrollBtBk.setAttribute('width', hScrollWidth);
     this.hScrollBtTopLeft.setAttribute('d', "M 0 " + SCROLLBAR_WIDTH + " v " + (-SCROLLBAR_WIDTH) + " h " + hScrollWidth);
     this.hScrollBtBottomRight.setAttribute('d', "M 0 " + SCROLLBAR_WIDTH + " h " + hScrollWidth + " v " + (-SCROLLBAR_WIDTH));
     this.hScrollBt.setAttribute('transform', 'translate(' + hScrollX + ', 0)');
     this.hScroll.setAttribute('display', 'inline');

     var bkheight = viewBox.height - 3*SCROLLBAR_WIDTH;
     this.vScrollBk.setAttribute('height', bkheight);
     this.DownBtn.setAttribute('transform', 'translate(0, ' + (this.TargetHeight - 2*SCROLLBAR_WIDTH) + ')');
     var vScrollHeight = Maximum(SCROLLBAR_MIN_LENGTH,
        ((viewBox.height - SCROLLBAR_WIDTH) * bkheight / workareaBBox.height));
     var vScrollY = (viewBox.y * bkheight / workareaBBox.height);
     this.vScrollBtBk.setAttribute('height', vScrollHeight);
     this.vScrollBtTopLeft.setAttribute('d', "M 0 " + vScrollHeight + " v " + (-vScrollHeight) + " h " + SCROLLBAR_WIDTH);
     this.vScrollBtBottomRight.setAttribute('d', "M 0 " + vScrollHeight + " h " + SCROLLBAR_WIDTH + " v " + (-vScrollHeight));
     this.vScrollBt.setAttribute('transform', 'translate(0, ' + vScrollY + ')');
     this.vScroll.setAttribute('display', 'inline');

      this.MeetRect.setAttribute('display', 'inline');
      return;
   }
   else{
     var bkwidth = viewBox.width - 2* SCROLLBAR_WIDTH;
     this.hScrollBk.setAttribute('width', bkwidth);
     this.RightBtn.setAttribute('transform', 'translate(' + (this.TargetWidth - SCROLLBAR_WIDTH) + ', 0)');
     var hScrollWidth = Maximum(SCROLLBAR_MIN_LENGTH,
        (viewBox.width * bkwidth / workareaBBox.width));
     var hScrollX = (viewBox.x * bkwidth / workareaBBox.width);
     this.hScrollBtBk.setAttribute('width', hScrollWidth);
     this.hScrollBtTopLeft.setAttribute('d', "M 0 " + SCROLLBAR_WIDTH + " v " + (-SCROLLBAR_WIDTH) + " h " + hScrollWidth);
     this.hScrollBtBottomRight.setAttribute('d', "M 0 " + SCROLLBAR_WIDTH + " h " + hScrollWidth + " v " + (-SCROLLBAR_WIDTH));
     this.hScrollBt.setAttribute('transform', 'translate(' + hScrollX + ', 0)');
     this.hScroll.setAttribute('display', 'inline');
   }
  }
  else{
    this.hScroll.setAttribute('display', 'none');
  }
  if (workareaBBox.height > viewBox.height){
    var bkheight = viewBox.height - 2*SCROLLBAR_WIDTH;
    this.DownBtn.setAttribute('transform', 'translate(0, ' + (this.TargetHeight - SCROLLBAR_WIDTH) + ')');
    this.vScrollBk.setAttribute('height', bkheight);
    var vScrollHeight = Maximum(SCROLLBAR_MIN_LENGTH,
       (viewBox.height * bkheight / workareaBBox.height));
    var vScrollY = (viewBox.y * bkheight / workareaBBox.height);
    this.vScrollBtBk.setAttribute('height', vScrollHeight);
    this.vScrollBtTopLeft.setAttribute('d', "M 0 " + vScrollHeight + " v " + (-vScrollHeight) + " h " + SCROLLBAR_WIDTH);
    this.vScrollBtBottomRight.setAttribute('d', "M 0 " + vScrollHeight + " h " + SCROLLBAR_WIDTH + " v " + (-vScrollHeight));
    this.vScrollBt.setAttribute('transform', 'translate(0, ' + vScrollY + ')');
    this.vScroll.setAttribute('display', 'inline');
  }
  else{
    this.vScroll.setAttribute('display', 'none');
  }
  this.MeetRect.setAttribute('display', 'none');
}

//----------------------------------------------------
//    Mouse Up
//----------------------------------------------------
Scroller.prototype.MouseUp = function (evt){
  eq.Dragging = null;
  evt.stopPropagation();
}



//----------------------------------------------------
//    Translate the viewbox so that the cursor is visible
//----------------------------------------------------
Scroller.prototype.EnsureVisible = function(Up, Down){
  var viewBox = this.Target.getAttribute('viewBox');
  var viewBoxParams = viewBox.split(/\s*,\s*|\s+/);
  var viewRect = svgDocument.documentElement.createSVGRect();
  viewRect.x = parseFloat(viewBoxParams[0]);
  viewRect.y = parseFloat(viewBoxParams[1]);
  viewRect.width = parseFloat(viewBoxParams[2]);
  viewRect.height = parseFloat(viewBoxParams[3]);

  var workareaHeight = this.Target.getBBox().height + ROW_OFFSET;
  var workareaWidth = this.Target.getBBox().width + ROW_OFFSET;
  // Check if the x position of the cursor is after the right margin of the viewbox
  if(Down.x > (viewRect.x + viewRect.width - ROW_OFFSET)){
    // Compute the x position
    viewRect.x = Down.x - viewRect.width + ROW_OFFSET*2;
  }
  // Check if the x position of the cursor is before the left margin of the viewbox
  if(Down.x < (viewRect.x + ROW_OFFSET)){
    // Compute the x position
    viewRect.x = Up.x - ROW_OFFSET*2;
  }
  viewRect.x = Minimum(viewRect.x, workareaWidth - viewRect.width);
  viewRect.x = Maximum(0, viewRect.x);

  // Check if the y position of the cursor is after the bottom margin of the viewbox
  if(Down.y > (viewRect.y + viewRect.height - ROW_OFFSET)){
    // Compute the y position
    viewRect.y = Down.y - viewRect.height + ROW_OFFSET;
  }
  // Check if the y position of the cursor is before the top margin of the viewbox
  if(Down.y < (viewRect.y + MARGIN)){
    // Compute the x position
    viewRect.x = Up.y - MARGIN;
  }
  viewRect.y = Minimum(viewRect.y, workareaHeight - viewRect.height);
  viewRect.y = Maximum(0, viewRect.y);

  this.Target.setAttribute('viewBox', viewRect.x + ' ' + viewRect.y + ' ' + viewRect.width + ' ' + viewRect.height);
  return viewRect;
}

//----------------------------------------------------
//    Translate the viewbox on the X axis
//----------------------------------------------------
Scroller.prototype.TranslateViewBoxX = function(newX){
  var viewBox = this.Target.getAttribute('viewBox');
  var viewBoxParams = viewBox.split(/\s*,\s*|\s+/);
  var workareaHeight = this.Target.getBBox().height + ROW_OFFSET;
  var workareaWidth = this.Target.getBBox().width + ROW_OFFSET;
  var newX = newX * workareaWidth;

  this.Target.setAttribute('viewBox', newX + ' ' + viewBoxParams[1] + ' ' + viewBoxParams[2] + ' ' + viewBoxParams[3]);
}

//----------------------------------------------------
//    Translate the viewbox on the Y axis
//----------------------------------------------------
Scroller.prototype.TranslateViewBoxY = function(newY){
  var viewBox = this.Target.getAttribute('viewBox');
  var viewBoxParams = viewBox.split(/\s*,\s*|\s+/);
  var workareaHeight = this.Target.getBBox().height + ROW_OFFSET;
  var workareaWidth = this.Target.getBBox().width + ROW_OFFSET;
  var newY = newY * workareaHeight;

  this.Target.setAttribute('viewBox', viewBoxParams[0] + ' ' + newY + ' ' + viewBoxParams[2] + ' ' + viewBoxParams[3]);
}

//----------------------------------------------------
//    Translate the viewbox so that the viewbox doesn't get out of the bbox
//----------------------------------------------------
Scroller.prototype.PutInside = function(viewRect, bbox){
  var Modified = false;
  if(((viewRect.x + viewRect.width) > bbox.width) && (viewRect.x != 0)){
    if (bbox.height > viewRect.height){
      viewRect.x = Maximum(0, bbox.width - viewRect.width + SCROLLBAR_WIDTH);
    }
    else{
      viewRect.x = Maximum(0, bbox.width - viewRect.width);
    }
    Modified = true;
  }
  if(((viewRect.y + viewRect.height) > bbox.height) && (viewRect.y != 0)){
    if (bbox.width > viewRect.width){
      viewRect.y = Maximum(0, bbox.height - viewRect.height + SCROLLBAR_WIDTH);
    }
    else{
      viewRect.y = Maximum(0, bbox.height - viewRect.height);
    }
    Modified = true;
  }
  if(Modified == true){
    this.Target.setAttribute('viewBox', viewRect.x + ' ' + viewRect.y + ' ' + viewRect.width + ' ' + viewRect.height);
  }
}