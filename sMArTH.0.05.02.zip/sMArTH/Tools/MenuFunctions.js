var savedest = 'file';
var index = 0;
function SaveAs(){
  TmpSave = new Object();
  for (var SaveType in eq.Save){
    TmpSave[SaveType] = eq.Save[SaveType];
    svgDocument.getElementById('ck' + SaveType).setAttribute('display', (TmpSave[SaveType] ? 'inline' : 'none'));
  }
  svgDocument.getElementById('save').setAttribute('display', 'inline');
}

function New(){
  if(confirm('This is a single document application.\nCreating a new document will cause\nthe loss of the previous equation.\nContinue?')){
    var root = eq.getRootElement();
    while(root.childrenObjects.length > 1){
      root.DeleteChild(root.childrenObjects[0]);
    }
    root.DeleteChild(root.childrenObjects[0]);
    eq.setFocusTo(eq.getRootElement().childrenObjects[0].childrenObjects[0]);
    eq.UndoVector.splice(2, eq.UndoVector.length-2);
    eq.UndoPointer = 1;
    this.Save = new Object();
    this.Save['MMLP'] = false;
    this.Save['LaTeX'] = false;
    this.Save['SVG'] = false;
    this.IsSaved = false;
    this.IsUpToDate = false;
    document.getElementById('downloadMMLP').setAttribute('display', 'none');
    document.getElementById('notsavedMMLP').setAttribute('display', 'inline');
    document.getElementById('downloadLaTeX').setAttribute('display', 'none');
    document.getElementById('notsavedLaTeX').setAttribute('display', 'inline');
    document.getElementById('downloadSVG').setAttribute('display', 'none');
    document.getElementById('notsavedSVG').setAttribute('display', 'inline');
    svgDocument.getElementById('modified').setAttribute('display', 'none');
  }
}

//------------------------------------------------------
//  "Modal results" from the save dialog
//------------------------------------------------------
function OkSave(){
  document.getElementById('save').setAttribute('display', 'none');
  for (var SaveType in eq.Save){
    eq.Save[SaveType] = TmpSave[SaveType];
  }
  Save();
}

function CancelSave(){
  document.getElementById('save').setAttribute('display', 'none');
}

//------------------------------------------------------
//  Download the saved files
//------------------------------------------------------
function Download(){
  for(var SaveType in eq.Save){
    if(eq.Save[SaveType] == true){
//      window.open('Saves/download.php?filename=test&type=' + SaveType);
      window.open('http://localhost/sMArTH/logo.svg');
//      document.getElementById('aboutmenu').click();
    }
  }
}
