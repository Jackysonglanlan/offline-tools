/*************************************
Preview loader
**************************************/

//----------------------------------------------------
//     Make a HTTP request for the XML file in which
//  the previews are defined
//----------------------------------------------------
function loadPreviews(){
  // Retrieve the XML definition of the previews
  getURL('Previews/previews.xml', buildPreviews);
}

//----------------------------------------------------
//     When the XML file content is available,
//  parse the file and build the previews
//----------------------------------------------------
function buildPreviews(data){
  // An error could have occured, so first we have to check
  // if the request was succesful
  if (data.success){
    // Parse the XML content and build a DOM tree
    var PreviewsDefinitionRoot = parseXML(data.content, document).childNodes.item(0);
    // Append the DOM tree to the document, so that getElementById can be called
    svgDocument.appendChild(PreviewsDefinitionRoot);

    // The preview will be inserted in this SVGSVGElement
    var PreviewSVGElement = document.getElementById('Previews');

    // The file consists of more Previews (xml trees).
    // Retrieve all theese Preview types in a NodeList 
    var PreviewItems = PreviewsDefinitionRoot.getElementsByTagName('preview');
    // The number of preview
    var PreviewCount = PreviewItems.length;
    // For some strange reason, Adobe SVGViewer sometimes returns null
    // when working directly with the NodeList, so we make a copy of it
    var PreviewItemsArray = new Array();
    for(var i = 0; i < PreviewCount; i++){
      PreviewItemsArray[i] = PreviewItems.item(i);
    }

    // Preview layout
    var PreviewAreaHeight = PREVIEW_AREA_HEIGHT; // Total height of the preview area
    var PreviewWidth = PREVIEW_AREA_WIDTH; // The width of the preview
    var ActivatorHeight = 26; // The height of each activator
    var PreviewDistance = ActivatorHeight + 2; // The distance between two collapsed activators
    var SlideDuration = 0.3; // The duration of a sliding
    var HighlightDuration = 0.1; // The duration of a highlight
    var FileAreaHeight = PreviewAreaHeight - PreviewCount * PreviewDistance; // The height of the button area
    var PreviewHeight = PreviewAreaHeight - (PreviewCount - 1) * PreviewDistance; // The height of an expanded preview

    // The default active preview
    var DefaultActivePreview = 0;

    // Parse each preview
    for(var i = 0; i < PreviewCount; i++){
      // The <preview> element in the XML file
      var PreviewDefinition = PreviewItemsArray[i];

      // The unique ID of the Preview
      var PreviewID = PreviewDefinition.getAttribute('id');
      var PreviousPreviewID = (i > 0) ? PreviewItemsArray[i-1].getAttribute('id') : '';
      var NextPreviewID = (i < PreviewCount - 1) ? PreviewItemsArray[i+1].getAttribute('id') : '';

      // Each preview is represented as a SVGSVGElement
      var Preview = svgDocument.createElement('svg');
      // Set the various attributes of this element
      Preview.setAttribute('id', PreviewID);
      Preview.setAttribute('width', PreviewWidth);
      Preview.setAttribute('height', PreviewHeight);
      if(i <= DefaultActivePreview){
        Preview.setAttribute('y', i * PreviewDistance);
      }
      else{
        Preview.setAttribute('y', PreviewAreaHeight - (PreviewCount - i) * PreviewDistance);
      }
      Preview.setAttribute('x', 0);

      // Create SlideUp and SlideDown <animate> elements.
      if(i > 0){
        // The first preview activator never slides

        // SlideDown -> moves the preview element down
        var SlideDownstr = "<set id='" + PreviewID + "SlideDown' ";
        // The animated attribute is y, because we only need to move the element down
        SlideDownstr += "attributeName='y' ";
        // The preview moves down
        // when it is up and when the previous preview is expanding or
        // when it is up and the previous preview is also sliding down
        if(i <= DefaultActivePreview){
          SlideDownstr += "begin='" + PreviousPreviewID + "MouseEventSensor.click;" + PreviousPreviewID + "SlideDown.begin' ";
        }
        else{
          SlideDownstr += "begin='indefinite' ";
        }
        // The Down position
        SlideDownstr += "to='" + (PreviewAreaHeight - (PreviewCount - i) * PreviewDistance) + "' ";
        SlideDownstr += "fill='freeze' dur='" + SlideDuration + "' ";
        // When the sliding begins, disable the slide down animation and enable the slide up animation
        SlideDownstr += "onbegin='onSlideDown(\"" + PreviewID + "\", " + i + ((i < PreviewCount - 1) ? ", \"" + NextPreviewID + "\"" : "") + ")' />";
        // Parse the string and append the resulting <animate> element to the preview
        var SlideDownAnimate = parseXML(SlideDownstr, svgDocument);
        Preview.appendChild(SlideDownAnimate);

        // SlideUp -> moves the preview element up
        var SlideUpstr = "<set id='" + PreviewID + "SlideUp' ";
        // The animated attribute is y, because we only need to move the element up
        SlideUpstr += "attributeName='y' ";
        // The preview moves up
        // when it is down and when the preview is expanding or
        // when it is down and the next preview is also sliding up
        if(i > DefaultActivePreview){
          SlideUpstr += "begin='" + PreviewID + "MouseEventSensor.click";
          if(i < PreviewCount - 1){
            SlideUpstr += ";" + NextPreviewID + "SlideUp.begin";
          }
          SlideUpstr += "' "; 
        }
        else{
          SlideUpstr += "begin='indefinite' ";
        }
        // The Up position
        SlideUpstr += "to='" + (i * PreviewDistance) + "' ";
        SlideUpstr += "fill='freeze' dur='" + SlideDuration + "' ";
        // When the sliding begins, disable the slide up animation and enable the slide down animation
        SlideUpstr += "onbegin='onSlideUp(\"" + PreviewID + "\", " + i + ", \"" + PreviousPreviewID + "\")' />";
        // Parse the string and append the resulting <animate> element to the preview
        var SlideUpAnimate = parseXML(SlideUpstr, svgDocument);
        Preview.appendChild(SlideUpAnimate);
      }

      // Each preview has an Activator (button) which opens the button area
      var Activator = svgDocument.createElement('svg');
      Activator.setAttribute('id', PreviewID + 'Activator');
      Activator.setAttribute('width', PreviewWidth);
      Activator.setAttribute('height', ActivatorHeight);
      Activator.setAttribute('x', 0);
      Activator.setAttribute('y', 0);

      // Create a highlight effect when the mouse moves over this activator
      // by modifying the opacity of a white background
      var Background = svgDocument.createElement('rect');
      Background.setAttribute('width', PreviewWidth);
      Background.setAttribute('height', ActivatorHeight);
      Background.setAttribute('class', 'ActivatorBackground');
      Background.setAttribute('opacity', '0');

      // Increase the opacity of the background when the mouse enters the activator area
      var UnfadeAnimate = svgDocument.createElement('set');
      UnfadeAnimate.setAttribute('attributeName', 'opacity');
      UnfadeAnimate.setAttribute('begin', PreviewID + 'MouseEventSensor.mouseover');
      UnfadeAnimate.setAttribute('to', '0.3');
      UnfadeAnimate.setAttribute('fill', 'freeze');
      UnfadeAnimate.setAttribute('dur', HighlightDuration);
      Background.appendChild(UnfadeAnimate);
      // Decrease the opacity of the background when the mouse leaves the activator area
      var FadeAnimate = svgDocument.createElement('set');
      FadeAnimate.setAttribute('attributeName', 'opacity');
      FadeAnimate.setAttribute('begin', PreviewID + 'MouseEventSensor.mouseout');
      FadeAnimate.setAttribute('to', '0');
      FadeAnimate.setAttribute('fill', 'freeze');
      FadeAnimate.setAttribute('dur', HighlightDuration);
      Background.appendChild(FadeAnimate);

      // Add the background to the activator
      Activator.appendChild(Background);

      // Create a 3D effect with two paths on the border
      var TopLeftBorder = svgDocument.createElement('path');
      TopLeftBorder.setAttribute('d', 'M 0 ' + ActivatorHeight + ' v -' + ActivatorHeight + ' h ' + PreviewWidth);
      TopLeftBorder.setAttribute('class', 'RaisedBorderTopLeft');
      Activator.appendChild(TopLeftBorder);
      var BottomRightBorder = svgDocument.createElement('path');
      BottomRightBorder.setAttribute('d', 'M 0 ' + ActivatorHeight + ' h ' + PreviewWidth + ' v -' + ActivatorHeight);
      BottomRightBorder.setAttribute('class', 'RaisedBorderBottomRight');
      Activator.appendChild(BottomRightBorder);

      // Add the image on the activator of this preview

      /*
      // Another flaw: cannot create an <image> using DOM
      var ActivatorImage = svgDocument.createElement('image');
      ActivatorImage.setAttributeNS('xlink', 'xlink:href', preview.getElementsByTagName('image').item(0).childNodes.item(0).nodeValue);
      ActivatorImage.setAttribute('width', PreviewWidth);
      ActivatorImage.setAttribute('height', ActivatorHeight);
      */

      var TitleElements = PreviewDefinition.getElementsByTagName('title');
      var TitleDefinition = 'Preview';
      if(TitleElements.length > 0){
        TitleDefinition = TitleElements.item(0).childNodes.item(0).nodeValue;
      }
      var ActivatorTitlestr = "<text class='slidertext' x='" + (PreviewWidth / 2) + "' y='" + (3*ActivatorHeight/4) + "'>" + TitleDefinition + "</text>";
      var ActivatorTitle = parseXML(ActivatorTitlestr, svgDocument);
      Activator.appendChild(ActivatorTitle);

      // Create an invisible rect that receives the mouse events;
      // if the svg itself receives this events, a lot of mouseover/mouseout events
      // will be genereated when the mouse moves from one inner element to another.
      var MouseEventSensor = svgDocument.createElement('rect');
      MouseEventSensor.setAttribute('id', PreviewID + 'MouseEventSensor');
      MouseEventSensor.setAttribute('width', PreviewWidth);
      MouseEventSensor.setAttribute('height', ActivatorHeight);
      MouseEventSensor.setAttribute('class', 'MouseEventSensor');
      Activator.appendChild(MouseEventSensor);

      // Add the activator to the preview SVGSVGElement
      Preview.appendChild(Activator);

      /////////////////////////////////////////////////////
      // Create the preview text area
      var PreviewFileGroup = svgDocument.createElement('g');
      PreviewFileGroup.setAttribute('transform', 'translate(0, ' + (PreviewDistance + ActivatorHeight)/2 + ')');
      PreviewFileGroup.setAttribute('id', PreviewID + 'FileAreaGroup');
      var PreviewFile = svgDocument.createElement('svg');
      PreviewFile.setAttribute('id', PreviewID + 'FileArea');
      PreviewFile.setAttribute('width', PreviewWidth);
      // The opened preview is expanded, the FileArea has its normal height
      if(i == DefaultActivePreview){
        PreviewFile.setAttribute('height', FileAreaHeight);
      }
      // Closed previews just hide the FileArea by setting the height to 0
      else{
        PreviewFile.setAttribute('height', FileAreaHeight);
//        PreviewFile.setAttribute('height', 0);
      }
      PreviewFile.setAttribute('viewBox', '0 0 ' + PreviewWidth + ' ' + FileAreaHeight);
      PreviewFile.setAttribute('x', 0);
      PreviewFile.setAttribute('y', 0);
      // Create file area origin
      var FileOrigin = svgDocument.createElement('rect');
      FileOrigin.setAttribute('width', 1);
      FileOrigin.setAttribute('height', 1);
      FileOrigin.setAttribute('class', 'MouseEventSensor');
      PreviewFile.appendChild(FileOrigin);

      if(i != DefaultActivePreview){
        PreviewFileGroup.setAttribute('display', 'none');
      }
      
      // Create file text background
      var FileBk = svgDocument.createElement('rect');
      FileBk.setAttribute('width', PreviewWidth);
      FileBk.setAttribute('height', FileAreaHeight);
      FileBk.setAttribute('fill', 'white');
      if(i != DefaultActivePreview){
        PreviewFileGroup.setAttribute('display', 'none');
      }
      PreviewFileGroup.appendChild(FileBk);

      // Create a 3D effect with two paths on the border
      var TopLeftFileBorder = svgDocument.createElement('path');
      TopLeftFileBorder.setAttribute('d', 'M 0 ' + FileAreaHeight + ' v -' + FileAreaHeight + ' h ' + PreviewWidth);
      TopLeftFileBorder.setAttribute('class', 'SunkenBorderTopLeft');
      PreviewFileGroup.appendChild(TopLeftFileBorder);
      var BottomRightFileBorder = svgDocument.createElement('path');
      BottomRightFileBorder.setAttribute('d', 'M 0 ' + FileAreaHeight + ' h ' + PreviewWidth + ' v -' + FileAreaHeight);
      BottomRightFileBorder.setAttribute('class', 'SunkenBorderBottomRight');
      PreviewFileGroup.appendChild(BottomRightFileBorder);

      // Expanding and collapsing the button area is done by animating the height of the SVGSVGElement
      var ShowFilesstr = "<set id='" + PreviewID + "ShowFiles' ";
      ShowFilesstr += "attributeName='display' ";
      // The File area expands when the user clicks the Activator
      ShowFilesstr += "begin='" + PreviewID + "MouseEventSensor.click' ";
      ShowFilesstr += "to='inline' ";//" + (FileAreaHeight) + "' ";
      ShowFilesstr += "fill='freeze' dur='" + SlideDuration + "' ";
      ShowFilesstr += "onbegin='onShowFiles(\"" + PreviewID + ((i < PreviewCount - 1) ? "\", \"" + NextPreviewID + "\")'/>" : "\")'/>");
      var ShowFilesAnimate = parseXML(ShowFilesstr, svgDocument);
      PreviewFileGroup.appendChild(ShowFilesAnimate);

      var HideFilesstr = "<set id='" + PreviewID + "HideFiles' ";
      HideFilesstr += "attributeName='display' ";
      // The File area collapses when
      // the button area is expanded and the preview starts sliding down or when
      // the button area is expanded and the following preview is sliding up
      if(i == DefaultActivePreview){
        HideFilesstr += "begin='" + PreviewID + "SlideDown.begin";
        if(i < PreviewCount - 1){
          HideFilesstr += ";" + NextPreviewID + "SlideUp.begin";
        }
      }
      else{
        HideFilesstr += "begin='indefinite";
      }
      HideFilesstr += "' to='none' ";
      HideFilesstr += "fill='freeze' dur='" + SlideDuration + "' ";
      HideFilesstr += "onbegin='onHideFiles(\"" + PreviewID + "\")'/>";
      var HideFilesAnimate = parseXML(HideFilesstr, svgDocument);
      PreviewFileGroup.appendChild(HideFilesAnimate);

      var PreviewTextElement = svgDocument.createElement('text');
      PreviewTextElement.setAttribute('id', PreviewID + 'TextElement');
      PreviewTextElement.setAttribute('class', 'PreviewText');
//      PreviewTextElement.setAttribute('y', PREVIEW_TSPAN_DY);

      PreviewFile.appendChild(PreviewTextElement);

      // Add the button area to the preview
      PreviewFileGroup.appendChild(PreviewFile);
      Preview.appendChild(PreviewFileGroup);
      
      // Add the preview to the preview area in the SVG
      PreviewSVGElement.appendChild(Preview);
    }
    // Remove the XML DOM tree from the SVGDocument
    svgDocument.removeChild(PreviewsDefinitionRoot);

    // Add the equation tspans to the text area

    svgDocument.getElementById('mmlpTextElement').appendChild(eq.getRootElement().MMLP_Preview);
    svgDocument.getElementById('latexTextElement').appendChild(eq.getRootElement().TeX_Preview);
    MMLPPreViewScroller = new Scroller('MMLPPreViewScroller', svgDocument.getElementById('mmlpFileArea'), PreviewWidth, FileAreaHeight, 'mmlpFileAreaGroup');
    LaTeXPreViewScroller = new Scroller('LaTeXPreViewScroller', svgDocument.getElementById('latexFileArea'), PreviewWidth, FileAreaHeight, 'latexFileAreaGroup');
  }
  else{
    // An error occured
    alert('Failed to load previews');
  }
}

// When the slide down begins, disable the slide down animation and enable the slide up animation 
function onSlideDown(PreviewID, Position, NextPreviewID){
 var Animate = document.getElementById(PreviewID + 'SlideDown');
 Animate.setAttribute('begin', 'indefinite');
 Animate = document.getElementById(PreviewID + 'SlideUp');
 if(arguments.length == 3){
   Animate.setAttribute('begin', PreviewID + "MouseEventSensor.click;" + NextPreviewID + "SlideUp.begin");
 }
 else{
   Animate.setAttribute('begin', PreviewID + "MouseEventSensor.click");
 }
}

// When the slide up begins, disable the slide up animation and enable the slide down animation
function onSlideUp(PreviewID, Position, PreviousPreviewID){
 var Animate = document.getElementById(PreviewID + 'SlideUp');
 Animate.setAttribute('begin', 'indefinite');
 Animate = document.getElementById(PreviewID + 'SlideDown');
 Animate.setAttribute('begin', PreviousPreviewID + "MouseEventSensor.click;" + PreviousPreviewID + "SlideDown.begin");
}

// When the button area is expanded, disable the expand animation and enable the collapse animation
function onShowFiles(PreviewID, NextPreviewID){
 var Animate = document.getElementById(PreviewID + 'ShowFiles');
 Animate.setAttribute('begin', 'indefinite');
 Animate = document.getElementById(PreviewID + 'HideFiles');
 if(arguments.length == 2){
    Animate.setAttribute('begin', PreviewID + "SlideDown.begin;" + NextPreviewID + "SlideUp.begin");
 }
 else{
    Animate.setAttribute('begin', PreviewID + "SlideDown.begin");
 }
}

// When the button area is collapsed, disable the collapse animation and enable the expand animation
function onHideFiles(PreviewID){
 var Animate = document.getElementById(PreviewID + 'HideFiles');
 Animate.setAttribute('begin', 'indefinite');
 Animate = document.getElementById(PreviewID + 'ShowFiles');
 Animate.setAttribute('begin', PreviewID + "MouseEventSensor.click");
}