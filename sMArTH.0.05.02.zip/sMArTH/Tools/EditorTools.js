/*************************************
Editor tools
Save, Cut Copy Paste, Undo Redo
**************************************/
function Save(){
  if((eq.Save['MMLP'] == false) && (eq.Save['LaTeX'] == false) && (eq.Save['SVG'] == false)){
    SaveAs();
    return;
  }
  if(eq.Save['MMLP'] == true){
    var str = eq.getRootElement().ExportPresentationalMathML();
    postURL("Saves/saver.php?filename=sMArTHeq&type=MMLP", str, getMMLPResult);
  }
  else{
    document.getElementById('downloadMMLP').setAttribute('display', 'none');
    document.getElementById('notsavedMMLP').setAttribute('display', 'inline');
  }
  if(eq.Save['LaTeX'] == true){
    var str = eq.getRootElement().ExportLaTeX();
    postURL("Saves/saver.php?filename=sMArTHeq&type=LaTeX", str, getLaTeXResult);
  }
  else{
    document.getElementById('downloadLaTeX').setAttribute('display', 'none');
    document.getElementById('notsavedLaTeX').setAttribute('display', 'inline');
  }
  if(eq.Save['SVG'] == true){
    var str = eq.getRootElement().ExportSVGNode();
    postURL("Saves/saver.php?filename=sMArTHeq&type=SVG", str, getSVGResult);
  }
  else{
    document.getElementById('downloadSVG').setAttribute('display', 'none');
    document.getElementById('notsavedSVG').setAttribute('display', 'inline');
  }
}

function getMMLPResult(data){
  if(data.success && data.content == 'succes'){
    document.getElementById('notsavedMMLP').setAttribute('display', 'none');
    document.getElementById('downloadMMLP').setAttribute('display', 'inline');
    eq.IsUpToDate = true;
    svgDocument.getElementById('modified').setAttribute('display', 'none');
    eq.IsSaved = true;
  }
  else{
    alert('Saving the MathML file on the server failed. We are sorry for this inconvenience.\nYou can still save the MathML content by copying it from the preview.');
  }
}

function getLaTeXResult(data){
  if(data.success && data.content == 'succes'){
    document.getElementById('notsavedLaTeX').setAttribute('display', 'none');
    document.getElementById('downloadLaTeX').setAttribute('display', 'inline');
    eq.IsUpToDate = true;
    svgDocument.getElementById('modified').setAttribute('display', 'none');
    eq.IsSaved = true;
  }
  else{
    alert('Saving LaTeX file on the server failed. We are sorry for this inconvenience.\nYou can still save the LaTeX content by copying it from the preview.');
  }
}

function getSVGResult(data){
  if(data.success && data.content == 'succes'){
    document.getElementById('notsavedSVG').setAttribute('display', 'none');
    document.getElementById('downloadSVG').setAttribute('display', 'inline');
    eq.IsUpToDate = true;
    svgDocument.getElementById('modified').setAttribute('display', 'none');
    eq.IsSaved = true;
  }
  else{
    alert('Saving the SVG file on the server failed. We are sorry for this inconvenience.');
  }
}

function Cut(){
  if(eq.getFocusedElement() == eq.getRootElement()){
    return;
  }
  if(eq.Clipboard){
    delete eq.Clipboard;
  }
  eq.BeginUndoSequence();
  var Focused = eq.getFocusedElement();
  while(Focused.IsLocked()){
    Focused = Focused.parentObject;
  }
  eq.Clipboard = Focused.Clone();
  Focused.parentObject.DeleteChild(Focused);
}

function Copy(){
  if(eq.getFocusedElement() == eq.getRootElement()){
    return;
  }
  if(eq.Clipboard){
    delete eq.Clipboard;
  }
  var Focused = eq.getFocusedElement();
  while(Focused.IsLocked()){
    Focused = Focused.parentObject;
  }
  eq.Clipboard = Focused.Clone();
}

function Paste(){
  if(eq.Clipboard){
    var Focused = eq.getFocusedElement();
    if(Focused == eq.getRootElement()){
      return;
    }
    eq.BeginUndoSequence();
    while(Focused.IsLocked()){
      Focused = Focused.parentObject;
    }
    Focused.InsertRange(eq.Clipboard.Clone().Explode(), true);
    Focused.UpdatePositions();
  }
}

function Undo(){
  eq.Undo();
}

function Redo(){
 eq.Redo();
}

//-------------------------------------------------
//  Check/uncheck and memorize oputput format options
//-------------------------------------------------
function CkeckSaveMMLP(){
 if (TmpSave['MMLP'] == true){
  TmpSave['MMLP'] = false;
  svgDocument.getElementById('ckMMLP').setAttribute('display', 'none');
 }
 else{
  TmpSave['MMLP'] = true;
  svgDocument.getElementById('ckMMLP').setAttribute('display', 'inline');
 }
}
function CkeckSaveLaTeX(){
 if (TmpSave['LaTeX'] == true){
  TmpSave['LaTeX'] = false;
  svgDocument.getElementById('ckLaTeX').setAttribute('display', 'none');
 }
 else{
  TmpSave['LaTeX'] = true;
  svgDocument.getElementById('ckLaTeX').setAttribute('display', 'inline');
 }
}
function CkeckSaveSVG(){
 if (TmpSave['SVG'] == true){
  TmpSave['SVG'] = false;
  svgDocument.getElementById('ckSVG').setAttribute('display', 'none');
 }
 else{
  TmpSave['SVG'] = true;
  svgDocument.getElementById('ckSVG').setAttribute('display', 'inline');
 }
}

//-------------------------------------------------
//  Check if the PHP server is available
//-------------------------------------------------
function CheckPHP(){
  getURL('Saves/SessionStart.php', ServerStatus);
}

function ServerStatus(data){
  if(!(data.success && (data.content == 'server ok'))){
    alert("Cannot connect to PHP server. You won't be able to save files.");
  }
}