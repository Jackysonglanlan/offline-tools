<?php
  session_start();
  $data = $HTTP_RAW_POST_DATA;
  if($_GET['type'] == 'MMLP'){
    $myFile = fopen(session_id().$_GET['filename'].'.mml', "w+");
  }
  else if($_GET['type'] == 'LaTeX'){
    $myFile = fopen(session_id().$_GET['filename'].'.tex', "w+");
  }
  else if($_GET['type'] == 'SVG'){
    $myFile = fopen(session_id().$_GET['filename'].'.svg', "w+");
  }
  fputs($myFile, $data);
  fclose($myFile);
  echo('succes');
?>