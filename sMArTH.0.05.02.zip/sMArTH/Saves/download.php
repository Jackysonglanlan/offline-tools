<?php
  session_start();
  header("Content-type: application/x-download");
  header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
  if($_GET['type'] == 'MMLP'){
    $Target = $_GET['filename'].'.mml';
  }
  else if($_GET['type'] == 'LaTeX'){
    $Target = $_GET['filename'].'.tex';
  }
  else if($_GET['type'] == 'SVG'){
    $Target = $_GET['filename'].'.svg';
  }
  header("Content-Disposition: attachment; filename=".$Target."");
  $Source = session_id().$Target;
  header("Content-Length: " . filesize($Source));
  readfile($Source, "w+");
?>