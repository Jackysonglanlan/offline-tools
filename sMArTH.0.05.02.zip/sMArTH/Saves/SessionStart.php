<?php
  session_start();
  echo('server ok');
?>